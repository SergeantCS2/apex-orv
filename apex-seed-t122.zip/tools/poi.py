#!/usr/bin/env python3
"""Places you can ride TO.

A110. The map has always been line: trails to ride along. It has never shown a
destination — where you park, where you camp, where you put a boat in, where you
buy fuel. Jacob asked for pins you can tap, "almost like Google Maps".

Two rules decide what reaches the phone.

NAMED ONLY. There are 206 parking areas inside this region and four of them have
names. The four are trailheads — "Bull Gap Trailhead", "Bull Gap Hill Climb
Trailhead" — and the other 202 are gravel pull-offs OSM happens to know about.
Shipping all of them would be clutter, and clutter is how a map stops being
trusted. An unnamed pin says "something is here" and nothing more, which is not
worth the space it takes.

EXCEPT WHERE ABSENCE IS THE POINT. A beach has no name in OSM and is still a
destination — the beach at Island Lake sits 6 m from the named day-use area and
is exactly what Jacob asked for. So `natural=beach` ships unnamed, labelled by
kind rather than by name. That is an exception with a reason, written down here
so the next person does not "fix" it.

Fuel closes a loop: the app has costed routes against a fuel range since take 36
and has never once shown the rider where fuel actually is.
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from region import R

# kind -> (tag, values, ships-unnamed). Order matters: the first match wins, so
# a campground with a shop tag is a campground.
KINDS = [
    ("trailhead", "amenity",  ["parking"],                          False),
    # take 121: unnamed ships, exactly as for beaches below. Jacob asked why
    # Waterford's kayak drops were missing: of 81 slipways there, 66 carry no
    # name in OSM and were being dropped. A place you may put a boat in is a
    # destination whether or not somebody typed a name on it; "Boat launch" is
    # honest, and silence is not (A146).
    ("launch",    "leisure",  ["slipway"],                          True),
    ("camp",      "tourism",  ["camp_site"],                        False),
    ("beach",     "natural",  ["beach"],                            True),
    ("dayuse",    "tourism",  ["picnic_site"],                      False),
    ("view",      "tourism",  ["viewpoint"],                        False),
    ("fuel",      "amenity",  ["fuel"],                             False),
    ("store",     "shop",     ["convenience", "supermarket", "general"], False),
    ("food",      "amenity",  ["restaurant", "cafe"],               False),
    ("info",      "tourism",  ["information"],                      False),
    ("water",     "amenity",  ["drinking_water"],                   False),
    ("toilet",    "amenity",  ["toilets"],                          False),
    ("shelter",   "amenity",  ["shelter"],                          False),
]


def centre(e):
    """A node has lat/lon; a way has geometry. Overpass `nwr ... out geom`
    produces both shapes and osm_local.py matches it, so handle both here."""
    if e.get("type") == "node" and e.get("lon") is not None:
        return float(e["lon"]), float(e["lat"])
    g = e.get("geometry") or []
    if not g:
        return None
    xs = [float(p["lon"]) for p in g]
    ys = [float(p["lat"]) for p in g]
    return sum(xs) / len(xs), sum(ys) / len(ys)


def classify(t):
    for kind, key, vals, unnamed_ok in KINDS:
        if t.get(key) in vals:
            return kind, unnamed_ok
    return None, False


def main():
    if not os.path.exists("aoi.json"):
        print("poi: no aoi.json — OSM was unavailable at ingest. "
              "Skipping places; the bundle will be PARTIAL and the app "
              "will name it.")
        if os.path.exists("poi_payload.json"):
            os.remove("poi_payload.json")
            print("poi: removed a stale poi_payload.json from an earlier run")
        return
    W, S, E, N = R.bbox
    import aoi_stream
    els = aoi_stream.elements()   # generator — 542 MB statewide, never loaded
    seen, out = set(), []
    # A152 (take 122): a named car park is a TRAILHEAD only if a trail comes
    # to it. Statewide the old rule shipped 1,902 "trailheads" including ".",
    # "001", "1 hour/Handicapped" and "RMHA Pool Parking Lot" — every named
    # lot in every city. Trail vertices (OSM track/path/bridleway, plus every
    # agency line) go into a 200 m grid during the same stream; a parking POI
    # keeps its badge only if one lies within ~150 m. Everything else is a
    # place to leave a car, not a place to start a ride, and is dropped.
    TRAILWAYS = {"track", "path", "bridleway"}
    GC = 0.002
    tgrid = {}
    def _tadd(lon, lat):
        tgrid.setdefault((int(lon / GC), int(lat / GC)), []).append((lon, lat))
    def _near_trail(lon, lat, r=0.0015):
        cx, cy = int(lon / GC), int(lat / GC)
        r2 = r * r
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for px, py in tgrid.get((cx + dx, cy + dy), ()):
                    ddx = (px - lon) * 0.72
                    if ddx * ddx + (py - lat) ** 2 <= r2:
                        return True
        return False
    for e in els:
        tags = e.get("tags", {})
        if e.get("type") == "way" and tags.get("highway") in TRAILWAYS:
            for pt in e.get("geometry") or []:
                _tadd(pt["lon"], pt["lat"])
        kind, unnamed_ok = classify(tags)
        if not kind:
            continue
        nm = (e.get("tags", {}).get("name") or "").strip()
        if not nm and not unnamed_ok:
            continue
        c = centre(e)
        if not c or not (W <= c[0] <= E and S <= c[1] <= N):
            continue
        # OSM often carries the same place as a node AND a way. Two pins a few
        # metres apart with one name is the doubled-line problem in point form
        # (A60), so collapse on name + kind + rough position.
        key = (kind, nm.lower(), round(c[0], 3), round(c[1], 3))
        if key in seen:
            continue
        seen.add(key)
        out.append({"k": kind, "n": nm or None,
                    "p": [round(c[0], 5), round(c[1], 5)]})

    # agency lines count as trails too — a DNR hiking trailhead is real
    if os.path.exists("authoritative.json"):
        for f in json.load(open("authoritative.json")):
            g = f.get("geometry") or {}
            parts = g.get("coordinates") or []
            if g.get("type") == "LineString":
                parts = [parts]
            for part in parts if g.get("type") in ("LineString", "MultiLineString") else []:
                for pt in part:
                    _tadd(pt[0], pt[1])
    th_before = sum(1 for r in out if r["k"] == "trailhead")
    out = [r for r in out if r["k"] != "trailhead" or _near_trail(r["p"][0], r["p"][1])]
    th_after = sum(1 for r in out if r["k"] == "trailhead")
    if th_before != th_after:
        print(f"poi: trailheads — {th_before} named car parks, {th_after} within 150 m "
              f"of a trail kept, {th_before - th_after} dropped (A152)")

    if not out:
        print("poi: nothing named in this region")
        if os.path.exists("poi_payload.json"):
            os.remove("poi_payload.json")
        return

    # A156 (take 122): the Geofabrik extract is clipped with a BUFFER, so
    # Sault Ontario's fuel and Hurley Wisconsin's bars leaked in — 221 of
    # 25,893 places sat outside the state. A place you cannot ride to under
    # Michigan's rules is not a place on this map. Boundary-town survivors are
    # the ones whose point is actually inside the polygon.
    if R.bulk:
        import statemask
        before = len(out)
        out = [r for r in out if statemask.inside(r["p"][0], r["p"][1])]
        if before != len(out):
            print(f"poi: clip — {before - len(out)} place(s) outside {R.name} dropped")
    out.sort(key=lambda r: (r["k"], r["n"] or ""))
    blob = json.dumps({"bbox": list(R.bbox), "p": out}, separators=(",", ":"))
    open("poi_payload.json", "w").write(blob)

    from collections import Counter
    c = Counter(r["k"] for r in out)
    print(f"poi: {len(out)} places, {len(blob)/1024:.0f} KB")
    print("  " + " · ".join(f"{k} {v}" for k, v in c.most_common()))


if __name__ == "__main__":
    main()
