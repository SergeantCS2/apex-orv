# HANDOFF — through Take 153 · V2

## Take 153 — 2026-08-29 — v2 field report one (Jacob, t152 on the Fold)

Five fixes from one report and one self-test:
1. The HD chip had no per-id position — it sat ON the basemap chip in the
   left stack. Top right now, parallel to the elevation readout (Jacob's
   spec, twice: the sketch and the correction).
2. The hdCard's three buttons showed literal __IC_layers__/__IC_alert__ —
   the token pass substitutes STATIC markup only; runtime HTML must use
   ic(). The gauge and run buttons already did; only my HD sheet forgot.
3. Deleting saved HD mid-download raced the writer (his LAST ACTIONS:
   hd-del, then hd-stop, tiles still landing). Delete stops first.
4. offline-clean read "XX 478 remote requests" — every one of them his
   own legal HD save. The fetch wrapper now mirrors §8's in-app
   allowlist: user-tap traffic to the two declared hosts is counted and
   NAMED ("478 in-app · user taps") with the badge staying green; anything
   else stays a red badge and a failure. Offline remains proven, not
   promised — the count never hides.
5. snap read -1: the self-test routed as his KAYAK. The drill borrows a
   land machine, says which and why, and puts the boat back.

A170 opened: overlapping pins in dense areas (his Hess Lake shot) — real
distinct places, two prominence tiers both drawing. His ×N stack idea is
the design candidate; recorded for a design pass, not built blind.

SEAL: smoke 2 fast modes, render 195/0, gate PASSED. The gate refused
once first and was right: a combined "Takes 151–152" heading parses as
neither take, so the batch's own record was incomplete — split into two
entries. ci/RELEASE.md was written BEFORE this seal, closing the t152
miss where the notes still carried take 146 (landmine 96's shape, caught
by Jacob's own reading of the Releases tab). apex-seed-t153.zip sealed
(sha256 in chat).

---

## Takes 147–150 — 2026-08-28/29 — the tester batch (Jacob: "do not seal
## until all of these are hit... every mode should plan something")

Order of work, one at a time: 147 liveries into Water (A166, new ingest
tag amenity=boat_rental -> a real livery kind, not name-guessing);
148 self-test style-loaded settles before it measures (A161); 149 Water
plans on the water — boats as the machine (A165) and corridor routing
put-in to take-out with float time (A163), plus per-mode plan proof
(Off-road machine, Outdoors foot, Hunt foot, Water river); 150 live USGS
gauges on rivers under §8's in-app rules (A164). Single seal at the end;
suites run per milestone, gate last.

## Take 147 — liveries into Water (A166)

The tester's "canoe rentals show in Ride, vanish in Water": those pins
are camps and stores by classification (58 of 83 canoe-named places are
launches; the liveries landed as camp/food/store). amenity=boat_rental
joins POI_TAGS (tag-set stamp forces the honest re-ingest), poi.py
classifies livery ahead of camp so a rental-campground pins as the thing
a paddler needs, Water (and Outdoors) carry the kind.

## Take 148 — self-test settles the style flag (A161)

stRender is async now: style-loaded polls isStyleLoaded() up to 5 s and
reports its settle time, and every RENDER read downstream sees a settled
style. The self-test chain awaits it; nothing else moved.

## Take 149 — Water plans on the water (A163 + A165)

What existed: the whole run system — paddleCard's two-tap flow, runCard's
put-in/take-out with downstream flip, dams-as-portages, livery-calibrated
paddleHours. What the tester proved missing: reachability and pace. Now:
kayak/canoe/raft join MACHINE (ok:[] — a boat is legal on no land class;
Water never graph-routes), the chip cycles craft in Water and remembers
your boat like it remembers your machine, paddleHours and the run card
follow the craft, and a launch/livery/marina PIN within ~300 m of a
mapped river carries the same run actions — the tester tapped pins, and
pins now answer. Every mode plans: Off-road and MTB by machine on the
graph, Outdoors and Hunt on foot, Water by river runs.

## Take 150 — live USGS gauges (A164)

gauges.py ships the NWIS inventory (241 MI surface-water sites, 22 KB —
the tester's 04137500 Au Sable gauge among them); the river card offers
"River conditions (USGS, live)" when a gauge sits within 12 mi, and the
values are fetched ON TAP under §8's in-app rules (waterservices.usgs.gov
allowlisted, PROVISION declares both roles). Stale values are never
shipped — live or absent, nothing in between. First gauges.py run sent
stateCd=Michigan and got HTTP 400: NWIS wants the postal code, and the
region record carries prose — explicit map now, because a wrong guess
here is a silent empty inventory. A drill first shipped with a
tautological check (`? true : true`) — caught and made falsifiable
before it ever ran.

## Take 151 — 2026-08-29 — DNR boating access sites (A169)

Mid-batch field report two, half one: Jacob has dropped at ramps the app
never showed. DNR Boating Access Sites (1,325; the layer verified to
exist before anything was promised — landmine 190) merge into launches
(+280) and corridor candidates; the Rifle goes from 2 named accesses to
the DNR's seven, with nameless OSM twins adopting the DNR's names
(Moffatt Bridge exists because of that rule). The state-sponsored-only
limit — county and township ramps are in neither source — is written in
bas.py where it bites.

## Take 152 — 2026-08-29 — rivers findable by name (A168)

Half two: "rifle river" found a STREET and three trails, never the river.
Corridors are search rows now, ranked with the best hits; a river hit
fits the whole river on screen and opens its summary (miles, accesses,
dams), pointing at the run flow.

Smoke's two batch reds, closed with causes: the exposure block died at my
GAUGES line and took __ride down (exposures now come last, defensively —
order is not load-bearing); and stRender's promise chain structurally
cannot complete under a harness that pumps timers, never microtasks — it
is a setTimeout chain now, the pattern the file already used.

SEAL (the batch, takes 147–152 as one — Jacob: "do not seal until all of
these are hit"): smoke 5/5 modes, render 195/0 (184 + the water batch +
the Rifle pair), gate PASSED. The gauges artifact had to be taught to
THREE explicit maps (bundle manifest, IN_BUNDLE, the split loader's fetch
list) — a 404 at boot took the whole app down in the harness, which is
exactly the loud failure the offline-integrity check exists to make.
README.md rewritten for v2 in Jacob's own README voice — every capability,
stated honestly, limits included. Two more gate refusals answered on the
way: the HANDOFF title line, and NWIS missing from manifest.py — the
declaration of RECORD, not just PROVISION's prose (the gate knew the
difference; I didn't, briefly). And a CI ordering landmine caught at the
seal: bas/gauges sat after the stages that consume them — a fresh runner
would have built poi and corridor dataless. Moved before poi. apex-seed-t152.zip sealed (sha256 in
chat). This is v2's candidate build.

---

## Take 146 — 2026-08-28 — the Ride mode is called Off-road (A167)

Jacob's direct call from the first EXTERNAL tester session. Label, mode
subtitle context and guide only — the internal key 'ride' and the
recording verb ("Ride it", the Ride tab) deliberately stay: saved state
hangs off the key, and "go for a ride" is the activity, not the mode's
name. Three render matchers moved with the label (chip text, picker
labels, guide regex); smoke asserts from MODES data and followed for
free. Descriptive check prose still saying "Ride" sweeps later — text
matchers were the correctness surface.

SEAL: render 184/0 with the three moved matchers green. Gate PASSED.
apex-seed-t146.zip sealed (sha256 in chat).

The same session filed A161–A166 (self-test check timing, one first-
paint frame stall, paddle planning on the corridors, USGS gauge data,
boats as Water's machine, liveries into Water) — recorded, designs next.

---

## Take 145 — 2026-08-28 — the HD chip and "Save HD for this view"

The visible half of A160, built to Jacob's sketch: an HD chip in the
top-right stack (hidden entirely for non-sparse regions), a sheet that
quotes tiles and megabytes BEFORE a save button exists, progress in the
chip's own label ("HD 42%"), a Stop button, saved totals and a delete
under Tools too. Over 500 MB the save button refuses to exist — "zoom in"
is the only path. Nothing moves without a tap, ever.

The downloader plans z13–15 over the visible bounds, skips the bundle's
own boxes and everything already stored, and fetches sequentially from
the same USGS endpoint the pipeline uses. A stopped or killed save costs
nothing: landed tiles persist and the same save resumes for free.
fetchTile is a deliberate seam so the render drill proves the entire
loop — plan, save, progress, store growth, resolver serving the result —
with the network stubbed out. EST is measured, not guessed (22 KB/tile
from the 790 shipped patch tiles).

Process note, honestly: the UI landed before this entry did — §6 says
record first and this take slipped the order by one edit. Caught here.

Wrapped-app.js bit once more (take 127's lesson): HDDL and hdChip never
reached window until placed there explicitly — the drill said "hooks
missing" and was right.

The gate then refused twice, both correctly, and the first refusal was
governance: the USGS URL in app.js broke §8's "no remote origins" as
written. A160 moves provisioning INTO the app, so §8 itself was revised
(its second revision; the first was take 10) with a four-condition
in-app provisioning allowlist — PROVISION.md declares the host's in-app
role, the gate's allowlist cites the clause. Second refusal: MapStub was
missing getBounds() and triggerRepaint(); the stub-completeness check
did its job. A prematurely written seal paragraph claimed "Gate PASSED"
before the verdict — replaced by this one, written after.

SEAL: render 184/0 (178 + six save-loop checks). Gate PASSED on the
rerun. apex-seed-t145.zip sealed (sha256 in chat). This one is worth
building: the HD button is field-visible.

---

## Take 144 — 2026-08-28 — HD imagery arc opens: the saved store + resolver

A160 (Jacob's call after field report 24542): sharp-past-z12 comes from a
manual HD system — stream with signal, save areas by choice, NOTHING
automatic. This take ships the foundation alone and proves it before any
UI exists: an IndexedDB tile store (no plugin, survives restarts, the
harness can drive it) and the apexsat:// resolver learning a second
place to look — inside the bundle's boxes the bundle answers as always;
outside them the SAVED STORE answers before blank does. Writers (the
downloader take, the streaming cache take) arrive next and own LRU; the
read path ships first because everything else stands on it.

Drill: resolver called directly (exposed as __sat.resolve) — blank
outside every box, seeded store tile served after __hd.put, bundle still
winning inside its boxes, stats counting what clear removes.

SEAL: render 178/0 (173 + the five store checks). Gate PASSED.
apex-seed-t144.zip sealed (sha256 in chat). Field-invisible by design —
Jacob can skip building this take; 145 puts the chip on it.

---

## Take 143 — 2026-08-28 — z12 statewide imagery base

Field report 24493 (Onondaga at 1 mi, take-140 APK): Hybrid still reads
pixelated — the z11 base is 54 m/px stretched ~5x at that view. Jacob
made the z12 call and accepted the size for now ("work backwards and not
worry… 114 MB isn't bad"): the statewide base moves to z12 — 10,573
tiles, ~104 MB, 27 m/px, 2x sharper again — under the unchanged z12–15
riding-area patches. One-line change: the APEX_IMAGERY_BASE_Z default in
imagery.py, so CI builds it with no env plumbing. Elevation readout
confirmed good in the same report (take 140's text stroke did its job).

Size ledger, measured from Jacob's own t140 APK: 110.6 MB on the wire, of
which the Android shell is <8 MB — the bundle IS the APK. Expected next
APK ≈ 175–180 MB. The WebP re-encode measurement is queued as its own
arc to work back toward Jacob's sub-100 MB ideal.

Two catches on the way, both worth keeping:
1. A z12-ONLY base regresses the z11-11.9 band to the 234 m/px mosaic —
   a raster source cannot underzoom. The base is a PYRAMID now, z11 and
   z12 both shipped, each native at its band, overzoom past 12. Measured:
   14,058 tiles / 183 MB staged (z11 2,695 + z12 10,573 + patches).
2. bundle.py's manifest builder is an explicit key list and silently
   dropped the new "base" field — the app fell back to maxzoom 11 and the
   render check said "to z11". The check caught the wiring gap; the field
   rides in the manifest now. Expected APK ≈ 235 MB; the WebP arc is next
   for size.

SEAL: render 173/0 — the base check now reads "the statewide base (to
z12) is loaded and visible at z13 outside every patch". Palette and smoke
unchanged by this take (data-side + one source parameter); gate PASSED.
apex-seed-t143.zip sealed (sha256 in chat).

---

## Take 142 — 2026-08-28 — ski and snowboard hills

Jacob (24280): "add all ski resorts… pictures, descriptions, link to
website and what ski runs are available." Mt Holly and Pine Knob are the
archetypes. Plan of record: `landuse=winter_sports` polygons pin as a
`ski` kind in Outdoors; `piste:type=downhill` and `snow_park` ways whose
midpoint falls inside the polygon become the card's run list with
`piste:difficulty`; the `website` tag becomes a link; the Wikipedia pass
covers photo + description; summer-MTB hills share take 141's bike glyph
in Ride. Nordic ruled out (a groomed loop is not a resort). Piste ways
carry no highway tag, so graph.py's selector never admits them — no
routing or legality surface.

Ingest: the ski tags joined POI_EXTRA, which already feeds both the keep
predicate and the tag-set stamp, so the stamp forced the re-ingest
honestly ("aoi.json was built with a different tag set — rebuilding").

Shipped: **36 hills pinned, 609 named runs on their cards, 17 with a
Wikipedia photo** (19 without — honest absence, no placeholder). Mt.
Holly's card reads Bugs Bunny · Grant's Trail · Rabbit Ridge in green
before Grant's Gorge and Mozart in blue, website linked. The card reads
runs and website off the RECORD via properties.i — nested arrays do not
survive MapLibre's property serialisation. The render drill is
region-aware (the hill comes from the bundle's poi.json, landmine 197)
and proved itself by FAILING against the ski-less bundle first — a check
is trusted only after it is watched failing (AGENTS rule 2).

Photo pass surgery: photos.py main() rebuilds its index from scratch and
deletes orphan files, so a cold-cache budget run would have shipped ~40
photos and destroyed the other 568. Killed by PID (landmine 204 bit again
on the way — a grep for photos.py matched this shell's own command
line); the 36 ski lookups ran through photos.py's own lookup()/key()
(landmine 98: no second copy) and merged into the shipped index,
608 -> 625.

SEAL: render 173/0 (168 + the five ski checks; drill self-selected Alpine
Valley from the bundle), smoke 5 modes (this session, this data), palette
18, gate PASSED. Found and recorded on the way: build_app.py is what
syncs bundles/<region>/ into www/bundle/ — bundle.py staging alone leaves
www stale. apex-seed-t142.zip sealed (sha256 in chat).

---

## Take 141 — 2026-08-28 — Hunt as its own mode; MTB pins are bikes

Jacob: "split Hunt from the separate modes — there's going to be a lot of
squares for public land." MODES gains `hunt` (on foot; public land + county
lines + summits from z9 + the typed waypoints); Outdoors is the hiker's map
again (trail systems, hills, rivers — public land and counties OFF). The
typed waypoint row moved from Outdoors to Hunt. Guide teaches four modes.

MTB systems draw a hand-drawn bicycle glyph (rendered at 3.4× and real
size to check it reads — it does); ski resorts that flip to MTB in summer
will share it.

Render 168/0 with every Hunt assertion retargeted (public land at Allegan,
county lines at 8.6, summits from z9, the pin card's five types). A stale
render with the old harness produced six failures first — expected, and
the reason harness edits ride in the same change as the feature.

SEAL (this session): statewide rebuilt in a fresh sandbox from the t140
seed (sha verified) — 573,316 edges, 25,448 places, 76 corridors, 323
summits; bundle composition matches the sealed record. Smoke 5 modes,
render 168/0 (two starved runs first — landmine 54 and 207), palette 18,
gate PASSED. apex-seed-t141.zip sealed (sha256 in chat).

Session note: the first pass at this take died UNSEALED at a chat limit —
the sandbox reset ate the workspace, so the take was replayed from the
transcript onto the sealed t140 tree and re-proven here. Legal under
landmine 203: no seed t141 ever existed, so this is a first seal, not a
reseal.

---

## Take 140 — 2026-08-28 — the readout outline, and a statewide imagery base

Jacob's 138 self-test: PASS 47 / FAIL 0, dispatch 88 ms on the Fold (was
654 at take 119), imagery "tiles z12-z15 · 3.40 m/px", trail-names 4 for
25 segments. Two field notes:

**"The i's have two white dots behind the black; a white line above the
mileage."** The A150 outline was four ±1 px white text-shadows; at dpr 2.6
they separate into dots. The scale bar's `0 -1px 0 #fff` box-shadow was
the line above. A shadow is not an outline: `-webkit-text-stroke` +
`paint-order: stroke fill` (Chrome 152 in the WebView supports it) on the
readout and scale; the scale keeps only the shadow BELOW.

**"Map fidelity is still very bad for hybrid."** At 1 mi the screen is
~11 m/px; the 4096 px state mosaic is 234 m/px — 20× too coarse outside
the eight patches. The sparse pyramid now carries a STATEWIDE z11 BASE
(2,695 tiles, ~38 MB, 54 m/px, 4× the mosaic) under the z12–15 patches.
MapLibre detail that decides the design: a raster source overzooms only
from its own maxzoom, so the base is its own source (`satbase`, min = max =
11) and layer (`sat-base`, between mosaic and patches) — otherwise every
z12+ tile outside a patch answers blank and the base never shows past z11.
Render: at a point outside every box, on Satellite at z13, the base source
has loaded and the layer is visible. 168/0. Imagery 55.9 MB / 3,513 tiles.

**Jacob's call, with numbers:** z12 statewide is 10,573 tiles / 104 MB
(27 m/px, 9× the mosaic); z13 is 400 MB. `APEX_IMAGERY_BASE_Z=12` in
ci/bundle.sh is the one-line switch if he wants it.

Gate PASSED, smoke 5 modes. apex-seed-t140.zip sealed (sha256 in chat).
CI note: the z11 base is 2,695 USGS tiles fetched on the runner — the
USGS tile service has not throttled CI before (the box era fetched
5,000+), but if the imagery step stalls, that is landmine 205's shape
again and the tiles move into the seed like the photos did.

---

## Take 139 — 2026-08-27 — the address index diet

The 52 MB address index was ten decimal numbers per segment as text, 770k
segments. Every one carries house numbers (0 droppable), so the diet is
encoding: sorted by name then position, coordinates as delta integers at
1e-5° (1e-4 saved 2 MB more and cost fidelity — not taken), ranges as
from + span, zips as an index. **52 → 28 MB; bundle 142.7 → 118.8 MB.**
The app decodes v2 back into the same `segs` arrays on load (~100 ms), so
the fifteen consumers are untouched. `addressAt` walks a midpoint grid
(reach = cap + 2 cells) instead of all 770k — the last linear scan in the
dispatch card. bundle.py's empty-artifact guard learned the v2 count (it
correctly refused the first build as "EMPTY — not staged").

The reverse-geocode probe took `segs[0]`, which moved from the 1400-block
to the 4200-block of the same road when the file was sorted and read as a
changed answer; it now takes the first segment of the first street name.
A probe must not depend on file order.

Render 167/0: dispatch card 2 ms of scanning, every lookup on a grid. Gate
PASSED, smoke 5 modes. apex-seed-t139.zip sealed, photos inside (sha256 in
chat). **Next:** DMUs on Jacob's digest page; contours over public land as
patches; Jacob's 138 bug report.

---

## Take 138 — 2026-08-27 — two regressions from Jacob's 136 test, both mine

**Hybrid turned blue from z12 up, with "random white lines".** The
"blank" tile the apexsat:// protocol returns for anything outside a patch
was a base64 PNG typed from memory — decoded, it is RGBA (0,0,255,127): a
half-transparent BLUE pixel. From the patch source's minzoom (12) it painted
the whole state blue except inside the eight patches, and the residential
roads that fade in on satellite at z12 (warm white) read as random white
lines over it. Now generated by PIL as (0,0,0,0), and render DECODES it and
asserts alpha 0. A constant typed from memory is a claim, not a fact.

**The tab bar and drawer vanished on the Fold.** The take-133 guide rewrite
cut the old block at the first `  </div>` after the button — which is a
substring of the deeper `    </div>` — so two stray closes were left in
place. The HTML parser closed #shell early and #tabs fell out of the layout
grid, below the screen. Headless did not show it because 412×915 with no
system bar still had room; the Fold did not. Balanced now, and render
asserts #tabs sits inside the viewport below #stage with the same parent.

Render 167/0. Gate PASSED, smoke 5 modes. apex-seed-t138.zip sealed,
photos inside (sha256 in chat).

---

## Take 137 — 2026-08-27 — typed hunting waypoints

Transcribed from Jacob's onX Hunt screen (24280): tree stand, trail camera,
deer sign, water, gate. In Outdoors the dropped-pin card offers the five
beneath "Save as waypoint"; Ride's card is unchanged. A type is a colour
and a name prefix on the SAME waypoint record (`t`), so the Saved panel,
the map source and the region stamp needed no change. `WPTYPES` is the one
table; the circle paint expression is built from it (landmine 98: no second
copy). Render: Ride offers none, Outdoors offers the five in order, Stand
saves `t:'stand'` with a "Stand · " prefix, the map paints it — 165/0.

Harness lessons, both mine: a `var` table declared below the style object
is `undefined` when the style is built (hoisting) — moved above PAL; and a
synthetic long press (touchstart/touchend) without the trailing click leaves
the app's "long press already acted" flag set, which swallowed the NEXT
drill's tap. A real finger always sends the click; the drill does now.

Jacob's build #55 (t135) measured the CI throttle: 100 lookups in 1,251 s.
Recorded in landmine 205.

Gate PASSED, smoke 5 modes. apex-seed-t137.zip sealed, photos inside
(sha256 in chat). **Next:** DMU county layer on Jacob's digest page;
contours over public land as patches; address index diet.

---

## Take 136 — 2026-08-27 — CI never talks to Wikimedia

Take 135's budget was not enough: build #55 (t135) sat on "address:" for
36+ minutes with no progress line at all. Wikimedia rate-limits GitHub's
cloud runners far harder than this sandbox; with the 20-second 429 back-off
a lookup could take a minute, so the first "100 looked up" line never
printed. Landmine 205. The fix removes the dependency: the 608 photos are
fetched here, re-encoded to 320 px / q68 (18 → 9.6 MB), and ship IN THE
SEED (photos/ + photos_index.json, neither ignored, committed by the seed
job); `ci/bundle.sh` exports `APEX_PHOTO_BUDGET_S=0` and photos.py then
uses the shipped set as-is with one line of output. Seed ~12 MB — still a
phone upload. Future fetches save at the smaller size.

Jacob's builds: #53 (t131) timed out at 1h30; #54 cancelled by the next
upload; #55 (t135) will time out too — cancel it and upload t136.

Gate PASSED. apex-seed-t136.zip sealed with photos/ inside (sha256 in chat).

---

## Take 135 — 2026-08-27 — the photo step no longer holds CI hostage

Jacob's CI: two builds sat after `address:` with no output; one was
cancelled by the next upload, the second was heading for the 90-minute job
timeout. Cause: `photos.py` (take 131) on a runner with an EMPTY cache does
~2,940 Wikipedia lookups at ~59/min — ~50 minutes — and printed nothing
until the end. Landmine 32's spirit: a silent long step is indistinguishable
from a hung one.

Two rules in photos.py now: progress every 100 lookups; and a TIME BUDGET
(`APEX_PHOTO_BUDGET_S`, default 1,500 s = 25 min) after which the step
ships what it has and prints how many pins remain. Cached candidates are
processed first (instant), so a warm cache runs in seconds and a cold one
fills progressively across builds — the cache (img_cache/photos/) is in
CI's region cache list. Proven: warm cache 3 s with 608 photos; a 20-second
cold budget stopped, shipped 5, and reported 2,924 deferred.

Expect Jacob's next CI run: ~30 min to address, 25 min of photos (with a
line every ~2 min), then render + gate — under the 90. The run after that
gets the rest of the photos from cache.

Gate PASSED. apex-seed-t135.zip sealed (sha256 in chat).

---

## Take 133 — 2026-08-27 — the guide, rewritten and versioned

Jacob: "the tutorial still doesn't show up on app launch." Not a race with
the location prompt — `apex.guide.v1` survived every install since an early
take (A147). The guide is rewritten for the whole state and the three modes
(what each is for; a mode is a starting point, never a cage; public land,
photos, 76 rivers) and its key is now **`apex.guide.v2`**, so it shows once
on the next launch. Render asserts it teaches Ride / Outdoors / Water and
the state, not the old test box; one harness check had hardcoded `v1` and
now reads the key by prefix. 160/0.

## Take 134 — 2026-08-27 — hiking trails routable in Outdoors

Jacob's answer to the open question: hiking trails "should be added to
Outdoors and highlight the paths / start / end like we would for ORV."
`foot` leaves SHOW_ONLY in graph.py and becomes a routable class, legal for
the `walk` machine ONLY (the gate's class-legality check guards that no ORV
allow-list names it). A `foot` line layer draws from the net source, dashed
in the hiking green; it is in TRAIL_LAYERS (the activity chip governs it)
and HIT (tappable).

**The cost, measured.** First build: 476k → **1,100,431 edges** — every
unnamed OSM `path` in the state came along (sidewalks were already
excluded). Rule applied: DNR hiking routes and NAMED OSM paths route;
unnamed OSM paths stay drawn, not routed. Second build: **998,382 edges,
582,127 nodes, graph 75 MB, bundle 176 MB.** The named rule barely moved it
— the DNR hiking network itself (69,628 features, ~12,000 mi of wiggly
geometry) is the bulk, and it IS the feature. 96.2 % of the network routable
together (footpaths connect what two-track did not).

**And it broke routing, which the self-test caught.** `route()` gave up after
150,000 node expansions — a box-era cap for a 20k-node graph. Silver Lake →
Mio failed at the first profile. `ROUTE_CAP` scales with NODES (×1.2, floor
150k); 6/6 profiles again, smoke green.

**The doubling was never foot edges.** Measured by class: `track` 652,968
of 995k edges (65 %); foot not in the top eight. The 12,451 DNR hiking
features average 65 vertices, and a trail that RUNS ALONG a two-track shares
every snapped vertex with it — every shared vertex was a junction, so both
lines were chopped into confetti. Jacob's instinct ("455 routes sounds much
more reasonable") pointed at the right symptom; the cause was the noder.
Fix in graph.py: within a run of consecutive vertices shared with a foot
line, only the run's ENDS stay junctions (join the road, leave the road); a
single shared vertex — a true crossing — is a junction as before; non-foot
pairs untouched. Result: **576,597 edges, 421k nodes, graph 46.6 MB, bundle
142.7 MB**, hiking fully routable, 96 % connected. Dispatch card 3,445 →
**87 ms** (nearestJunction and nearestPavement joined nearestEdge on the
grid). Route cap scales with the graph. Render 161/0 — the summit block
that hung three times on the 75 MB graph completes on this one.

Ruled out: routing only the pinned systems' geometry (it would not have
cut the noding), harder RDP (already 10 m; not the cause).

**Gate refusal, and the law it protects.** `show-only classes also marked
ridable: ['foot']` — unnamed OSM paths were drawn from the show-only
payload under the same class the walk machine may route. Rather than teach
the gate an exception, the unnamed paths became class `path` (drawn dashed
in the hiking green, never routable), so "a class is routable OR show-only,
never both" holds unchanged. Gate PASSED, render 161 inside it.
apex-seed-t134.zip sha256 b1cdbaf0…0e9e, 85 files, carries take 133.

**Next:** typed hunting waypoints (stand / camera / sign / water / gate);
DMU county-based layer once Jacob sends the digest page; contours over
public land as patches; address index diet (the last ~900 ms of dispatch).


---

## Take 132 — 2026-08-27 — public land (the Hunt layer), photos finished, take 131 folded in

Take 131 was never sealed (three VM reboots across the photo run); its
content ships here. Bundle COMPLETE 138.8 MB.

**Public land — DNR "Managed Lands", layer 2 of DNRLOTSParcelsOPENDATA.**
136,026 parcels with ProjectUseType and ProjectName. `tools/publicland.py`
pages them (the server caps at 1,000 per page — the first run assumed 2,000,
got one page, and printed FIVE tracts for a state; fixed), dissolves per
project with shapely, simplifies to ~10 m, drops slivers under 2 acres:
**657 tracts, 4.70M acres** (Michigan's state land ≈ 4.6M — the dissolve is
honest). Forest units 22 (Shingleton 375k ac), game areas 116 (Allegan
49,716), parks/rec areas 109, rail trails 34, and **356 boating / water
access sites** — the DNR's named launches, arriving as a by-product. Type
strings were READ from the data ("State Park", "Recreational Areas",
"RAIL TRAILS"), not guessed; Undedicated / Military / Right-of-way skipped.
App: `pub-fill` wash by type under everything, `pub-line`, `pub-label` on
tracts ≥ 2,000 ac, "Public land" group ON in Outdoors, off in Ride and
Water, `pubCard` with type and acreage and a note to check DNR rules. Render:
at Allegan in Outdoors the wash and boundary draw, acreage in range, Ride
keeps it off.
- Ruled out: layer 13 "Project Boundary" — Forest Management Unit boxes
  (360k acres, private land inside), administrative not ownership.
- Ruled out: private parcels with owner names — county GIS, not free
  statewide. Stated, not faked.

**Photos: 608 of 2,940 major pins**, 18 MB — beaches 57, camps 144,
launches 82, lighthouses 80, marinas 113, MTB 22, systems 108, areas 2/8.
`build_app split` copied the imagery folder but not the photos folder, so
the first render fetched a 3-byte 404 body; fixed, re-render served
28,821 bytes.

Render 159/0, smoke 5 modes. Gate PASSED after four correct refusals (the
HANDOFF race; shapely missing from ci/bundle.sh; a GitHub URL in a
user-agent read as an undeclared host; upload.wikimedia.org declared but
never named as a URL — now a constant the tool ENFORCES). Two VM reboots
killed the gate mid-run; third run clean. apex-seed-t132.zip sha256
21fc76b0…df40, 85 files (the first zip lacked tools/photos.py — an `echo -e`
line in the seed list; caught by the manifest check before sending).

**DMUs: not published** (see DESIGN-modes.md). **Next:** typed waypoints;
contours over public land as patches; guide; Jacob's call on foot routes
in the router.

---

## Take 131 — 2026-08-27 — photos on major pins, A139 lighthouses, and two old landmines found alive

**Photos (Jacob's idea).** Measured first: OSM carries a photo link on
~2 % of destinations, so `tools/photos.py` goes to Wikipedia — geosearch
within 3 km, article matched on NAME (tokens minus stop words, ≥ 60 %
overlap), lead image as a 320 px thumbnail, Commons author + licence for
the card's caption. Google's photos are ruled out by licence (no caching
= no offline). Scope: camps, trail systems, riding areas, named beaches,
plus A139's lighthouses and marinas. First run: **56 of 1,538 matched**
(systems 26, camps 15, beaches 10, MTB 5) — state-forest campgrounds
rarely have articles, which is the honest shape of "major pins only".
Two corrections from reading the hits: town articles ("Luna Pier,
Michigan") matched beaches named after towns — rejected; and a FAILED
search was being cached as "no photo", which is how Silver Lake State
Park's article, 1,064 m from the riding area, was frozen out. Failed
searches are never cached now. A third bug: the script cleared its output
folder and then served cached hits without rewriting their files — it
would have deleted every photo on the second run. Orphans are pruned at
the end instead. Card shows the photo full-width above WHERE with a
hairline attribution; a pin with no photo gets no markup at all.

**A139 · Great Lakes destinations.** `man_made=lighthouse` and
`leisure=marina` added to both ingest paths (they were never in the tag
set — the state carried ONE lighthouse), kinds `lighthouse` (rank 0,
boosted in Water) and `marina`; both in Water, lighthouse also in
Outdoors; both are photo candidates — this is where the photo feature
should shine.

**Landmine 200, alive in ingest.** The "aoi.json present, skipping" check
did `json.load` on the 543 MB file to read ONE key — 3.9 GB, and the OOM
killer the moment swap was down. It reads 400 bytes now.

**Landmine 196, again.** aoi.json was sticky across a tag-set change: the
first A139 ingest "succeeded" in 4 minutes having done nothing, and the
state still had one lighthouse. The stream now stamps a hash of the tag set
into the file header; ingest rebuilds when it differs. Printed:
"aoi.json was built with a different tag set — rebuilding".

**Landmine 204** (pkill/pgrep matching the calling shell) is written; it
cost four calls this take.

**Jacob's reference (Google Maps place cards).** Photo carousel, rating,
one-line description, address, hours. Offline reality: photo + description
+ address ship; rating, reviews and hours are Google's and cannot. The
coverage he wants is beaches, launches, state parks / campgrounds, MTB
systems — most of which have no Wikipedia ARTICLE. So a second source: a
geotagged Wikimedia Commons photo within a per-kind radius of the pin
(launch 250 m … area 700 m), preferring a filename that shares the pin's
name. Plus the matched article's first sentence as `d` on the card, and
named launches join the candidates (~2,800 total). Hit rate on fresh
lookups went **3.5 % → ~20 %**.

**Throttled, then fixed.** Six workers earned a 429 from Wikimedia and a
9-second failure on every call; a user-agent WITH a contact URL (their
policy), 3 workers, a 0.35 s pause per call and a 20 s back-off on 429
runs at ~59 lookups/min with no refusals. The cache (img_cache/photos/,
carried by CI's region cache) makes it a one-time cost.

Two ingests, one honest: the first A139 ingest "succeeded" in 4 minutes
having skipped the OSM pass on a sticky aoi.json — the tag-set stamp fix
above came from that. After the real rebuild: **101 lighthouses, 322
marinas** in the state.

In progress at session end: the photo run (~2,800 candidates, ~35 min
left). Then bundle → build → suites → seal. Nothing sealed under 131 yet.

---

## Take 130 — 2026-08-26 — the mode picker

Jacob: "make the mode switcher pop out, let me select what mode I want
rather than it swapping between them." The chip now opens a picker built the
way the activity chip's is — three rows, each with the mode's name and a
one-line description of what it is FOR ("Beach, kayak, tube, boat —
launches and rivers, no trail lines"), so the choice is made from the
description rather than from remembering a cycle order. The three panels
(layers, activity, mode) close each other. Render: the chip opens three
rows in order, choosing Water selects it and closes the picker — 153/0.
Gate PASSED, smoke 5 modes. apex-seed-t130.zip sealed (sha256 in chat).

**Next, in order:** marina tag + DNR Boating Access Sites + A139 Great
Lakes destinations for Water; Hunt data (DNR public-land polygons, DMUs,
typed waypoints); guide (A147/A155). Jacob's open call: foot routes into
the routing graph.

---

## Take 129 — 2026-08-26 — three things transcribed from onX, built from held data

**Trail-system pins** (onX 24269). poi.py groups DNR foot / bike / horse
features by `n` (TrailNamePrimary), sums their length, and pins the
centroid: kind `system` (hiking) or `mtb` (biking, when half or more of the
features are the bike class). Statewide corridors — anything spanning more
than ~40 km (North Country Trail, Iron Belle, Shore To Shore) — and systems
under half a mile get no pin; 139 skipped. **343 hiking systems, 112 MTB
systems**, each carrying `mi`, which the card shows ("Black Mountain
Pathway · 93.8 mi of trail"). Rank 0. Outdoors shows both; Ride shows MTB
only. Glyph is the day-use tree for now — a dedicated system glyph is a
badge-sheet change for later.

**County lines and names** (onX 24276). The 83 county rings have been in
the context payload since take 100, used only by countyAt. Now `county-line`
(dashed, z5.5–13) and `county-label` (uppercase, letter-spaced, z7–11.5)
from a source filled in drawCoverage. A "County lines" layer group: on in
Outdoors, off in Ride and Water — a hunter thinks in counties, a rider in
trail systems.

**Summits from z9 in Outdoors** (onX 24276 shows them at regional zoom).
`MODES.peaksFrom` drives setLayerZoomRange on peak-dot / peak-label; Ride
and Water put them back to 10.6.

Render measures all three in Outdoors and their absence in Ride: 151/0.
Gate PASSED after one correct refusal (the stub lacked setLayerZoomRange).
apex-seed-t129.zip sealed; sha256 in chat.

---

## Take 128 — 2026-08-26 — the walking router, and Jacob's onX screens transcribed

**Transcribed, not invented (landmine 190).** Jacob sent four onX screens —
one MTB (Backcountry-style), three Hunt. DESIGN-modes.md now carries a
line-by-line transcription of each, paired with what we already hold and
what is missing. The two cheap, high-value things they reveal:
- **trail-SYSTEM pins** (24269): one pin per named system — "Ogemaw Hills
  Pathway", "Au Sable State Forest - North" — at regional zoom, not per
  segment. Derivable from DNR `TrailNamePrimary`; a poi.py pass.
- **county lines + labels and summits from z9** (24276): the county rings
  are already in the context payload, never drawn.
Hunt is now specified: DNR public-land polygons (state forest / game / rec
areas), Deer Management Units, typed waypoints (stand / camera / sign /
water / gate). Parcels with owner names and wind at a stand are out of
scope, stated.

**DESIGN-modes step 3 · a machine that walks.** `MACHINE.walk` — legal on
every class a person may stand on, 3 mph regardless of class via `spd()`,
which overrides the per-class SPEED table the three route-time sites used
to read directly. Outdoors sets `walk` on entry and hands the rider's
machine back on exit (`rideMachine`). Foot-only routes remain show-only:
a hiker is routed along two-track, forest road and ORV trail — honest about
what the graph holds, and the design says so. Render measures it: machine
becomes walk, an edge's time is its length at 3.00 mph, leaving Outdoors
restores sxs at 22 mph. 146/0. Gate PASSED, smoke 5 modes.
apex-seed-t128.zip sha256 f0591f14…41b2, 83 files.

**Next, in order:** trail-system pins from DNR TrailNamePrimary + county
lines/labels + summits from z9 in Outdoors (all from held data); marina tag
+ DNR Boating Access Sites + A139 for Water; Hunt data (DNR public-land
polygons, DMUs, typed waypoints); guide (A147/A155). Open decision for
Jacob: put the 69,628 foot routes INTO the routing graph (walkable, at a
graph-size cost) or keep them show-only.

---

## Take 127 — 2026-08-26 — A153 second half: crisp imagery where a rider rides

Statewide the z12+ pyramid was measured impossible at take 75 (8.6 GB at
z15). It is possible SPARSELY: `imagery.py` now fetches z12–z15 over every
DNR riding area's bbox + ~2.5 km — **818 tiles, 17.9 MB, 3.4 m/px** — on top
of the 4096 px statewide mosaic (~234 m/px) that stays underneath. 464 →
234 → 3.4 m/px across three takes, from the same USGS source.

The app keeps the mosaic on `sat` and adds `satpatch`, a raster source read
through an `apexsat://` protocol handler (the glyph pack's pattern). Two
rules make sparse tiles safe: a tile outside a declared box is never
requested — the box list ships in the manifest (`imagery_tiles.boxes`) —
and a requested-but-missing tile answers with a blank PNG, never an error,
because `map.on('error')` decides RENDER FAIL. `sat-patch` toggles with
`sat`; a zero-radius circle layer stands in when a bundle has no patches so
the id is stable for the toggle and the harness.

Smoke's box-era rule ("if the bundle carries tiles, `sat` is raster") was
taught the sparse shape. Render asserts, at the largest riding area on
Satellite, that the patch layer is a visible raster whose source LOADED,
and that out-of-box requests raise no error — 143/0. The first version of
that check silently skipped because it read `window.BUNDLE`, which does not
exist (app.js is wrapped; areaCard at 121 was the same lesson); it reads
`window.__sat` now. A count that goes up by 1 instead of 3 is a check that
took its skip branch — read the log, do not trust the total.

Bundle ~154 MB. Field: Hybrid over Silver Lake or St. Helen at street zoom
is a sharp photo; 3 km outside the polygon it drops back to the state
mosaic, by design.

Gate PASSED after one correct refusal: check_orphan_sources discovers source
names by the character after `name:` and did not admit `(` — the take-127
`sat:(TILES&&!SPARSE)?…` opens with one. Regex widened; the comment above
it already described the conditional case. apex-seed-t127.zip sha256
db816651…b82c, 83 files.

**Next:** `walk` machine + profile (DESIGN-modes step 3); marina tag + DNR
Boating Access Sites + A139 for Water; hunt/fish after Jacob's onX
screenshots; guide (A147/A155). Open from the field: 69,628 foot routes at
state zoom — Jacob's verdict pending.

---

## Take 126 — 2026-08-26 — Jacob's first field pass on modes

Three screenshots and a log. Every item below is his verdict, then the
cause, then what changed.

**"Outdoors just changes relief to on, which looks incredibly bad."** True
on both counts. At 5 mi the 69,628 hiking routes do not draw yet (show-only
minzoom), so relief was the only visible change — and the statewide
hillshade was an 850 px JPEG of 6400 px of z10 tiles, 7.5× downsampled,
then upscaled: grey blotches (24416). Outdoors now defaults relief OFF;
named hills and paddling carry the mode. Separately the hillshade is
rendered at 4096 px statewide (3.9 MB).

**"In Ride I see all beaches/boat launches."** The take-125 rule that Ride
must be today's map is overruled by the rider: a riding trip has no use for
launches. Ride's whitelist drops launch/beach, and store/food/info demote
to z13 — the wall of purple badges at 3000 ft (24412) was noise on a riding
map. The render drill that taps a pin now picks a trailhead, which every
mode draws. Water promotes launch/beach to rank 0 so they show from the
layer's first zoom — at 5 mi (24414) Water showed no launches at all.

**Filters, safely.** MapLibre allows a zoom `step` only at the TOP of a
filter (landmine 52). The base destination filter is such a step, so
`modeFilter()` applies the mode's kinds / boost / demote to each branch and
leaves the step on top, rather than wrapping it in `all`.

**"Roads still showing as white, looks really bad."** Half-opacity was not
enough at 5 mi. On imagery, minor roads now fade in from z12 (you only
need the residential grid when you are about to turn onto it) and highways
sit at 0.35. The Map basemap is untouched — Jacob: "the default white view
looks better."

**"Hybrid is super pixelated."** The statewide mosaic was 1500 px — about
464 m/px — from tiles that are 150 m/px. 4096 px is every GPU's texture
floor (the Fold reports 8192): ~234 m/px, 1.7 MB, from tiles already
cached. Bundle 136.5 MB. Real sharpness at riding zoom still needs the
per-area tile patches (A153 second half, not started).

**Three orange dots.** My ON-indicator broke the one-accent rule three
times on one screen (24414). Bone now.

**Self-test `trail-names` FAIL.** It ran while Jacob was in Outdoors, which
hides ORV lines, so it counted names over 0 segments. The check now
controls its layer state (act → all) as well as its viewport, and restores
both. Mio Δ30 "at the nearest node, 985 ft away" is now readable: the
anchor sits 300 m off the network.

Render 140/0 (+2 mode assertions), smoke 5 modes, gate PASSED.
apex-seed-t126.zip sha256 908aeb68…9e97, 83 files, bundle 136.5 MB.

**Next:** per-area imagery tiles (A153 second half — read the app's tile
source and imagery.py's budget machinery first; both are box-era); `walk`
machine + profile; marina + DNR Boating Access Sites + A139 for Water;
hunt/fish after Jacob's onX screenshots (landmine 190); guide (A147/A155).

---

## Take 125 — 2026-08-26 — Modes, step 1: Ride / Outdoors / Water

Jacob renamed "Trail" to **Outdoors**. Built exactly what DESIGN-modes.md
step 1 promised: a `MODES` table and a chip, each mode a preset over tables
that already existed — act, POI kinds, layer groups, basemap — applied
through the existing setters, persisted in `apex.mode`, restored on load
after `applyMachine` so legality paint survives.

- **Ride** — act `ride` (new: ORV + two-track + bike), every pin kind,
  riding areas on, hills/contours/relief off, Map. **Exactly today's map**;
  the first draft dropped launches and beaches from Ride's pins and the
  place-tap check caught it.
- **Outdoors** — act `foot` (69,628 hiking routes drawn, ORV lines hidden
  one tap away), camp/shelter/water/toilet/view/launch/beach/dayuse pins,
  named hills + contours + relief + paddling on, riding areas off.
- **Water** — act `none` (new: no trail lines), launch/beach/camp/dayuse
  pins, paddling on, Hybrid when satellite is available.
- `bike` admitted to the show-only whitelist (it fell through to the
  'other' colour; a palette row is step 2).
- Five render assertions measure each mode from RESOLVED style state, not
  the table, and put the mode back. Render 138/0.

Harness lesson: `#lyrpanel` hides via opacity, so building it while hidden
leaves rows the accent counter can see. `applyMode` rebuilds it only when
open.

Sealed: smoke 5 modes, gate PASSED with render 138 green inside it.
Two gate refusals on the way, both correct: the harness stub lacked
`getFilter` (added), and the "No trails" legend row used a hex literal
(landmine 98 — now PAL.showother). apex-seed-t125.zip sha256 6734abd3…aa4a,
83 files.

Still to build (DESIGN-modes.md steps 2–6): field-check 69,628 foot routes
at state zoom; `walk` machine + profile; marina + DNR Boating Access Sites +
A139; hunt/fish data after Jacob's onX screenshots (landmine 190); guide.

---

## Take 124 — 2026-08-26 — A153 and two self-test truths, before modes

Jacob's t123 log: dispatch 662 → **217 ms**, worst frame 16 ms, Bull Gap Δ3,
graph 468,940 edges after the clip. He is holding his remaining notes for a
later round and asked for A153 and the open checks to be closed before the
modes work begins.

**A153 · roads step back on satellite.** `minor`/`paved` are #FFFFFF by
take-113 design; statewide the 246,883 context ways painted the whole
suburban grid white over the photo (24319). On Satellite/Hybrid only:
opacity 0.5, warm `#F1EBDD`, ~40 % narrower; two-track and forest-road
casings dimmed. Designated-trail casing untouched — that is data. The Map
basemap is untouched. Roads remain exempt from the ORV selector, on purpose.
Imagery patches over the riding areas are NOT in this take (see below).

**Mio Δ27 explained and fixed.** `elevAt` sampled every 7th node. After the
take-122 clip re-noded the graph, the stride landed on a different node
~300 m into the Au Sable valley: 974 → 938 ft with no DEM change. It walks
the A96 grid now — exact nearest node — and the check prints how far that
node is, so a Δ reads as terrain or as distance.

**trail-names was vacuous for three takes.** It jumped to the 'site' anchor
(Silver Lake Dunes, an area with no trail lines by design) and passed on
"0 names for 0 segments" via `segs===0||tl>0` — landmine 85. It now finds
the designated trail edge nearest the region centre from the DATA, requires
both segments and names, and settles with a bounded poll instead of a
1.8 s nap.

Render 133/0, app self-test 41/0 inside it.

**Deferred, with reasons.** Riding-area imagery patches (the other half of
A153): a bounded z14–15 pyramid over 8 polygons is the right shape, but the
app's tile source and imagery.py's budget machinery are box-era and need
reading before a sparse pyramid is promised — a full take, not a tail.
A147/A155 (guide) waits for the modes design, which changes what the guide
must teach. A148 (compass) waits for a ride.

---

## Take 123 — 2026-08-26 — A151 / A151b: pins that stay put

Jacob's take-121 verdict: the pins "pop in/out like crazy". Measured cause
(DIAGNOSIS-t121): 670 destination badges in one 10-mile view handed to the
collision solver with overlap forbidden below z11.4, whose answer changed on
every pan; and badge and name split into two layers that collided
separately, so 24315 showed names with no badges and 24323 badges with no
names.

**Data thinned deterministically (poi.py).** Every place carries `pri`:
0 camps / trailheads / day-use / views, 1 named launches and beaches,
2 unnamed launches and beaches, 3 services. Unnamed launches within ~200 m
of any other launch are collapsed (79 statewide — fewer than expected; most
unnamed ramps are not clustered, which is an honest number). 24,567 places.

**Layers rewritten (app).** Two symbol layers instead of four: badge and
name share a layer with `text-optional:true`, so the badge always draws and
the name only when it fits — they cannot disagree. The destination layer
filters on `pri` per zoom (`step` on zoom at the filter's top level, the one
place MapLibre allows it): rank 0 from z9.2, rank 1 from z10.5, all from
z11.4. Overlap is allowed everywhere: once the data is thinned there is
nothing left to fight over, so a pin that is on stays on while you pan. Text
appears via a zoom `step` in `text-field` (services from z12.8, destinations
from z11). Render's POI and Layers-panel checks retargeted from the removed
label layers.

Render 133/0 with the merged layers; smoke 5 modes; gate PASSED (polygon
99.92% / 100%). apex-seed-t123.zip sha256 f33ce4bb…1158, 82 files.
Also retired render.mjs's "area layer queued (take 117)" note — it shipped
at 119.

**Next:** A153 (dim minor/paved on satellite; riding-area imagery patches),
A147+A155 (guide key + rewrite), A148 (compass, after a ride), then A139
Great Lakes POI, private MX parks, DNR Boating Access Sites.

---

## Take 122 — 2026-08-26 — the diagnosis, fact-checked and worked in order

Jacob asked for the take-121 diagnosis (docs/DIAGNOSIS-t121.md) to be
fact-checked before anything was built on it. Every claim held against the
tree except one mechanism: the A156 write-up said landcover clips to the
state polygon; its "outside" test is a BBOX test (landcover.py:148), and
foreign landcover is absent only because the Geofabrik extract is
state-clipped. Conclusion unchanged, attribution corrected in the document.

**A150 · one opaque control surface.** `.basebtn.on` was a 16 % cream tint
under cream text — invisible over satellite, and over the light map the pill
showed while the text vanished into it. Jacob asked whether the tint was
still needed: no. The label already says the state ("Hybrid", "ORV / dirt
bike"). Rule adopted: *every floating control is one opaque surface; state
lives in the label, never in the background.* ON = brighter border + accent
dot. The readout and scale are permanently dark ink with a hard 1 px white
outline (four offset shadows, not a blur — the blur is what read grey over
imagery). `body.satmode` and A145's swap are gone.

**A154 · panels anchored to the measured strip.** `--strip-h` is published
from `#tools.offsetHeight` on load and resize; diag and compass panels sit
`calc(var(--strip-h) + 8px)` above it instead of a hardcoded 64 px that A144
had quietly made wrong.

**A156 · clip to the state, not the bbox.** New `tools/statemask.py`:
Census 1:500k state polygon (context.py draws 1:20m — an outline, not a
keep/drop tool), rasterised with PIL at 0.004° and DILATED 3 px (~1 km).
The undilated first run dropped 82 DNR features that turned out to be
Michigan beach trails — Tawas Point, Hoffmaster, the NCT on the Porkies
shore — which is why the dilation exists and why it is written down.
Clip at ingest's single dump point, keep a feature if ANY vertex touches the
state (boundary-crossers whole, Geofabrik's rule), print drops per source
and class: **3,774 dropped, all USFS** (fsclosed 2,305, foot 862, fsroad 398,
nfsmoto 110, fstrail 99). POI clipped the same way: the Geofabrik buffer had
let 221 places in from Sault Ontario and Hurley Wisconsin.
`check_region_polygon` in the gate asks the question nobody asked for 118
takes — inside the POLYGON, not the bbox — and its negative control refused
the unclipped graph at 1.97 % outside.

**A152 · a trailhead needs a trail.** Trail vertices (OSM track / path /
bridleway during the same stream, plus every agency line) go into a 200 m
grid; a named car park keeps its trailhead badge only if one is within
~150 m. Statewide: **1,902 → 732 trailheads**; ".", "001", "RMHA Pool
Parking Lot" are gone, Pontiac Lake Rec Area stays.

Process lesson, paid twice this take: `pkill -f` with a pattern that appears
in the calling shell's own command line kills the call. Kill by pid.

**Sealed:** smoke 5 modes, render 133/0 inside the gate, gate PASSED with
`region polygon: 340,914 of 341,190 routable nodes inside Michigan (99.92%)`
and `24,646 of 24,646 places inside`. Bundle COMPLETE, 14 artifacts,
graph 37.9 MB. The gate also refused statemask.py's first self-test for
hardcoded coordinates (the take-14 law); it now derives its controls from
regions.json — every anchor inside, every bbox corner outside.
apex-seed-t122.zip sha256 4325e081…1bf7, 82 files.

**Next, in the diagnosis order:** A151/A151b (POI prominence rank, dedupe
unnamed launches within ~200 m, pair badge with name), A153 (dim roads on
satellite; riding-area imagery patches), A147+A155 (guide key + rewrite),
A148 (compass, after a real ride).

---

## Take 121 — 2026-08-26 — Jacob's field report, worked in his order

Nine items came off the Fold (A141–A149 in AGENDA, verbatim). Six are done.

**A141 withdrawn, and it matters.** First read was "CI served a stale cache,
landmine 196 again." Checked instead: the local bundle with the terrain
patches hashes 3509f18c, Jacob's build hashes 4d051023 — byte-identical to
his t119, which is exactly what the FIRST t120 zip (grid only) produces. He
built the pre-reseal zip. Two seals under one take number caused it;
landmine 203.

**A142 · the tan wash.** `state-fill` sat ABOVE landcover, water and the
network, so at 20-mile scale the whole peninsula was a flat tan sheet with
trails bleeding through — the single worst thing on the state map, and
invisible in the box era where you never sit at z7. Moved to the bottom of
the stack, directly on the background: land where there is no landcover,
forest/park/water on top where there is. Outline stays above; a line
orients without hiding.

**A143 · POI tiers.** Trailheads, campgrounds, launches, beaches, day-use
and viewpoints are DESTINATIONS (`d:1`): ~2× badge, from z9.2 (~10 mi), on
their own layer above the services, with labels from z11. Fuel/food/store/
info/water/toilet/shelter stay at z11.4 and small. Collision is allowed to
suppress destinations below z11.4 — 1,900 trailheads stacked is not a map.

**A144 · the sheet ate the buttons.** #rail is pulled up 14 px by design;
the Layers/Locate/Search strip sat inside that lip. 24 px bottom padding.

**A145 · readout.** Stack rises 22 px (the quick chips are gone), and the
elevation/scale take the colour of the ground: near-black with a bone halo
on the light map, white on satellite, via body.satmode. It was white-on-
white before — unreadable on exactly the basemap that ships by default.

**A146 · the missing kayak drops.** Jacob named Waterford. Of 81 slipways
there, 66 have no name in OSM and were dropped: beaches got the "absence is
the point" exception at take 89 and launches never did, for no stated
reason. Statewide 989 → 2,156 launches. The smoke rule moved with the
policy — beaches AND launches, no others.

**A149 · the Bull Gap teleport.** Not the app zeroing itself: stPerf jumps
to the region centre (-84.6, 44.62) to spin the camera for the fps
measurement and never put the view back. It now restores centre, zoom and
bearing after counting.

**The harness, four bugs in a row.** Sealing took four rounds, all of them
checks lying about a healthy map, all one law: *a check must control where it
looks, and a drill must put back what it moved.*
1. `icon-size` nested a zoom interpolate inside w() — MapLibre allows one and
   rejects the WHOLE style, so nothing drew at all. Landmine 52, documented
   six lines above the helper, walked into anyway.
2. `roads: 0 features` on a run drawing 22,782. Jumping to an anchor and
   counting same-tick failed too (a jump needs a frame; stRender is sync), so
   the check now NAMES the view it counted — which is what identified it.
3. That view was 47.035,-88.189 z15: the rail drill jumps to the first POI in
   the payload (Keweenaw) and never restored the camera. Restored. It also
   polled only `poi-dot`, which A143's split would have made time out
   whenever the first POI is a destination — fixed in the same edit.
4. `illegal line still DRAWN` read 31 for a side-by-side against 102 for a
   bike. Not legality: the block had no viewport either, so the two machines
   were sampled at different moments of one tile load. It picks a trail50 line
   out of the payload, jumps, settles once, then reads both. 149 = 149.

Sealed: gate PASSED, render 133/0, smoke 5 modes, palette 18, bundle
COMPLETE 132.4 MB. apex-seed-t121.zip sha256 41ea542f…e604.

Deferred with reasons: A147 (guide race on first launch — not reproduced
yet), A148 (compass phasing — needs sample smoothing, wants a real ride to
judge), and the DNR Boating Access Sites service (found: bravob_dnr
"DNR State Sponsored Developed Boating Access Sites" — authoritative
launches with names, the same shape as the scramble-area win; next take).

---

## Take 120 — 2026-08-26 — A96: the spatial grid. Box-era scans, state-era cost.

Jacob asked for every box lesson applied to the state. The largest unpaid
one was in the render log all along: `nearestEdge 304 ms` in desktop
headless. Three "nearest X" functions were linear scans — every tap that
drops a pin, every dispatch card, every Return Home snap decoded 1.4M
vertices from delta-encoded geometry. Instant over 20k box edges; seconds
on a phone over 474k.

One grid, 0.02° cells (~1.6 km), indexes every node and every geometry
vertex of every edge, built on first use in one decode pass and kept.
Lookups walk rings outward — perimeter only, the square-and-skip first draft
cost 440 ms 100 mi out in Superior — and stop when the next ring is farther
than the best hit. The claim is EXACTNESS: smoke asserts grid == linear scan
for nearestEdge and nearestNode at four probes read off the region bbox
(landmine 197), two of them offshore. Both linear versions stay as `_linear`
for that proof. `nearestEdgeTo` (the pin card's "nearest:" line) used to
scan START nodes only; it now gets the true nearest vertex, so it got more
accurate as it got faster.

Measured: land probes 0–13 ms where the linear scan took ~1 s in the node
vm; Chrome dispatch `nearestEdge` 304 → 41 ms INCLUDING the one-time build.
Next in that line (not done): nearestPavement 40 ms, addressAt/addressNear
41 ms each — the address index is the next scan to ring-walk.

### Riding-area terrain patches (same take)

The Fold's self-test read Bull Gap 49 ft high: statewide DEM is z10, the
box was z13, and a sand hill is what 150 m/px flattens. terrain.py now
patches z13 over every DNR scramble area's bbox + ~4 km (areas runs before
terrain in the pipeline now): 8 patches, 114 tiles, 4,850 nodes re-sampled.
Bull Gap anchor 1,115 → 1,066 ft against 1,070 surveyed; Mio and the Pink
Store unchanged (outside any area, already within 10 ft).

### And the stump (landmine 201 addendum, found by this)

Re-running contour after the terrain change gave 264 summits, not 323.
aoi.json was 935 KB: the take-119 `import ingest` accident had started
streaming a new file over the 543 MB one before the OOM killer stopped it.
Nothing downstream complained. Regenerated (ingest, 9 min); osm_local.py
now streams to .part and renames; gate has check_input_integrity (a bulk
aoi.json smaller than a tenth of its extract is refused). The t119/t120
seeds were NOT affected — their contour payload predates 23:07.

Sealed: render PASSED 133, smoke 5 modes green, gate PASSED.

---

## Take 119 — 2026-08-25 — Riding areas, summits without a mosaic, and the line that killed CI

### Jacob's GitHub build reached all of Michigan — and died one line later

Take 118's workflow paste worked: CI built the state in 1,637 s, 474,047
edges, 130 MB, five smoke modes green, `graph.json 01cdc37a60d5` byte-identical
to the same build in the sandbox. Then `ci/bundle.sh: line 12: APEX_REGION:
unbound variable` — take 118 deleted the pin from the workflow and left ONE
reader of it behind, in the script that runs under `set -u`. Landmine 199's
own corollary, the same take it was written. `bundle.sh` now asks region.py.

### Statewide summits — the diagnosis was wrong, the fix was removal

Take 117 blamed "peak-detection allocations at 45M px". The summit block does
a 5×5 window per peak; there are no candidate arrays. What it DID do was
`json.load(open("aoi.json"))` — the 542 MB statewide file, several GB as
Python objects — after assembling three 45M-px float32 arrays that summits
never needed. Bulk mode now streams peaks from `aoi_stream`, decodes only the
one z10 tile each sits on, ships `l: []`. **323 named summits, 17 KB, memory
flat** (landmine 200). Mount Arvon reads 1,972 ft against its official 1,979:
z10's ~150 m/px undersamples a peak by a few feet, recorded not fudged; Bull
Gap's four are within ±14 ft of the take-94 z13 figures. `bundle.py`'s contour
counter counts lines + peaks, or the take-76 empty-artifact guard would refuse
a payload of 323 real hills. First **COMPLETE** statewide bundle.

### A140 · Riding areas — the DNR draws Silver Lake as a polygon, and so do we

Jacob's take-117 call: Silver Lake Dunes is an open-riding AREA. The DNR
trails MapServer we have ingested for 118 takes holds only two short ACCESS
routes into it (1.1 mi, both open, 72"). The perimeter lives in a SEPARATE
service on ArcGIS Online — `DNR_ORV_Scramble_Areas`, MichiganDNR — eight
polygons statewide: St. Helen Motorsport Area 1,285 ac, **Silver Lake ORV
Area 447** (the DNR's published "450"), Holly Oaks 239, The Mounds 213, Black
Mountain 64, Gladwin 20, Rock Climb 10, and Bull Gap Hill Climb 3. Server
count 8 = 8 shipped. Jacob: draw every one — the small ones are how a rider
finds the hill. Private MX parks (Ogemaw Hills) are NOT in the designated
layer and belong to the POI pass, not a legal riding-area layer (open).

`tools/areas.py` is a pipeline step with its own cached, retried read —
because **importing ingest.py RUNS the statewide ingest** (no `__main__`
guard; 3.9 GB and the OOM killer on the first attempt; landmine 201).
Wired end to end: PROVISION host `services3.arcgis.com`, bundle artifact +
counter, both loader paths, `AREAS` decl, source, legal-green fill under the
network, dashed outline and centre label above the paddle layers, a "Riding
areas" Layers group ON by default, a tap card that yields to any trail under
the finger and says routing goes to the edge, never across. Seven smoke
assertions; render proves St. Helen draws as a polygon and is labelled.

### What the record must say plainly

The sandbox VM rebooted mid-session (swap dropped with it — re-enable before
landcover, which peaks at 3.9 GB flex_mem statewide). The seed carries no
data: the full statewide rebuild here was ingest 7 min, graph 7 min,
corridor 5 min, landcover 5 min, everything else under a minute each.

### Three render lines, all harness, all classified before the seal

1. Area card — the probe called `window.areaCard`; app functions are not
   globals, the bridge is `window.__areas.card` (landmine 54, made twice in
   one take: the smoke draft did the same).
2. Summits — Mount Arvon is the first peak and sits in a corner of the UP no
   earlier check had tiled; a fixed 2.4 s nap lost to the source worker and
   reported 0 of 323. Bounded poll (landmine 198).
3. Compass "bearing to home" — the perf block polled the panel for `PASS`,
   which the statewide report never contains ("39 passed, 5 failed"), gave up
   at 20 s with the self-test STILL RUNNING, and its teardown show() landed on
   the drill's pin card 60 lines later. The drill's own diagnostic (added this
   take) said it: pcHome false, panel = self-test report. Now waits on
   `__selfTestReport`. Whether this predates 119 is unknowable: CI never
   reached render.mjs (bundle.sh died first) and 117/118's render counts are
   box-era.

Environment lesson: one headless Chrome at a time on this box — a second
launch beside a running suite produced protocol timeouts, not failures.
Second lesson: the sandbox drops its swap file silently between calls
(swapon shows 0 with no reboot). The gate's in-process render then dies with
a puppeteer protocol error that looks like a product failure and is not —
`swapon /tmp/sw` and rerun. Check `free -m` before believing a render crash.

### After the seal: why t119 never reached CI (landmine 202)

Jacob uploaded t119 and CI kept saying 118. The take-118 workflow paste had
no `seed` job — the job that unpacks the zip was dropped when the file was
regenerated — and the zip was not in push.paths, so uploads no longer
triggered anything. Restored in ci/build.yml as Stage -1 (`seed`, with
`bundle: needs: seed`), zip added to the trigger paths. Seed resealed with
the corrected file. ONE manual step for Jacob again: paste ci/build.yml over
.github/workflows/build.yml.

### Verified

Smoke 5 modes, 0 real failures. Gate PASSED. **Render PASSED, 133 checks.**
Palette PASSED. Bundle COMPLETE, 132.4 MB.

---


## Take 118 — 2026-08-25 — The Great Lakes, and the audit of the statewide arc

### Michigan gets its namesakes

The way-only water reader can never see a multipolygon relation — so take 117
shipped the state lakeless of Superior, Michigan and Huron, and of every
island-holding inland lake. landcover.py's area handler (which assembles
relations natively) grew a `water` kind with one filter that matters:
**relation-assembled only** (`not a.from_way()`), because simple closed-way
lakes are already pack.py's. **738 water bodies**, landcover now 8,882 areas /
7.8 MB, drawn as `lc-water` seated directly beside the way-water fill — same
paint, one water. The state-overview screenshot is the milestone: the Mitten,
both peninsulas, the big three, Drummond in the St. Marys.

Jacob's direction recorded as **A139**: the big lakes get DESTINATION POI in a
future pass (major launches, lighthouses, famous grounds — Manistee the
archetype), never corridor treatment.

### The audit Jacob ordered ("you made a ton of changes")

Seventeen statewide-arc mechanisms verified present and correctly shaped in
one adversarial pass — HOME spec end to end, open-view, ME-at-centre, the
machine-keyed memo and its five clear sites, the expansion cap, the
length-filter-before-summarise layering, the terrain alignment guard and
absent-safe edgeProfile, the edge-aware dispatch budget, connector-only
residential, relation-only water, drills standing on land. Zero misses, zero
TODOs, temp instrumentation stripped from the harness. `__routeDbg` is KEPT
deliberately and documented as a bridge beside `__restrict` — it solved the
routing mystery once and costs bytes.

### The take-117 GitHub build shipped the box — root cause and cure

Jacob installed the michigan seed and got the test square wearing take 117,
same speed and size as ever. Root cause, found in the workflow's own words:
`.github/workflows/build.yml` — hand-pasted, un-updatable by the seed
(landmine 84) — still pinned `APEX_REGION: neml-bullgap`, and the env var
outranks regions.json by design. His field intuition was the only alarm that
fired (landmine 199).

Cure, defence in depth, none of it hand-synced: (1) **region authority lives
only in regions.json** — the corrected `ci/build.yml` derives its cache key
from the declared region and pins nothing (one hand-paste required, loudly
documented in the file header; timeout 25→90 min for statewide; auth_cache and
the stamp join the cache paths); (2) **ingest stamps every data run**
(`region_stamp.json`) and **bundle refuses foreign payloads** — negative
control fired correctly; a stale CI cache now fails with its remedy printed;
(3) **ci/bundle.sh** — which the seed CAN update — verifies the built manifest
names the declared region, rejects any lingering APEX_REGION pin by name, and
enforces a 90 MB floor on a michigan bundle that no box can fake. A region
switch also clears the old stamp (region.py DERIVED_EXTRA).

### Verified

Smoke 5/5 modes, render 124+ with the Great Lakes in frame, gate green with
the scaled stopwatch, the stamp guard's negative control fired and reset.
Sealed as `apex-seed-t118.zip`, hash in the message. **Jacob's one manual
action: paste ci/build.yml over .github/workflows/build.yml.**

---


## Take 117 — 2026-08-25 — ALL OF MICHIGAN. Built, routed, suites green, sealed.

The statewide arc, Jacob's call: "It's time to do all of Michigan." Region
`michigan` is now the default and the built bundle. The longest take in the
project by far — many sessions, four OOM battles, and a parade of box-era
premises expiring at state scale, each caught by the machinery built for
exactly that.

### The pipeline, statewide, measured

- **Ingest**: 731,310 elements streamed from the Geofabrik extract in ~370 s.
  The raw pull was 1,078 MB; the census said 64% was metro driveways, sidewalks
  and unnamed ditches. The bulk keep policy trimmed to **542 MB** of real
  content — 501k roads/trails, 12k rivers, 33k named streams, 80k inland lakes.
- **Authoritative**: the fetcher had NO pagination (the box never exceeded
  ArcGIS's 2000-record cap, so it never showed). Now: 1000-row pages, per-layer
  disk cache (restarts resume), politeness delays, and QUADRANT SPLITTING for
  any layer whose statewide envelope makes the server shed load — Jacob's
  staging idea, applied surgically. 1,399 edges statewide carry live DNR
  restrictions: A72's preparation met real data.
- **Graph**: **346,907 nodes / 473,674 edges, 38.5 MB payload** — 22x the box,
  inside A72's predicted 18–26x band. **Connector-only residential**: attempt 1
  (keep all) met the OOM killer; attempt 2 (drop all) severed a THIRD of nodes
  from the giant component — take 64's lesson at state scale; attempt 3
  union-finds the non-residential network and admits only bridging residential:
  **6,272 ways (2.4%) carry all the connectivity**, metro grids stay out.
- **Terrain** z10 (700 tiles), landcover 8,145 areas, 76 river corridors,
  address 770k segments (53.7 MB — tuning candidate), imagery underlay z10.
  Bundle **127 MB, PARTIAL as declared** (contours + z12+ pyramid honestly
  absent; statewide summits an open OOM item, absence named in-app).

### The 3 GB build box, beaten repeatedly

Disk-backed sparse node index · `aoi_stream.py` (all consumers stream, none
load) · noding drops each geometry the moment its noded copy exists · auth rows
freed · terrain float32 channel-wise decode · and finally **2 GB of swap**,
which the sandbox accepted. CI has 7 GB and never needed any of it proven — but
now it is.

### Routing at state scale — the whole detective story

Return Home statewide first said "no legal route" after 31–41 s. The chain, in
order, each step evidence-first: HOME was a phantom (first town anchor — Jacob's
spec landed: **unset until set, persisted, refuses politely**; open-view spec
with it). ME was Silver Lake Dunes, ninety miles from the map (now centre).
The graph WAS connected — the legal subgraph too — and the real wall was the
residential cut (fixed above). Then "Routing…" forever: **stale terrain vs the
re-emitted graph threw inside a timer, unheard** — artifacts that index each
other now VERIFY each other, and mismatch degrades loudly to absent (landmine
195). Then the legality memo (pure in machine x class x bundle) cut per-edge
string parsing; the debug bridge that mutates bundles now invalidates it
(landmine 196). An expansion cap (150k settles) bounds any profile's search;
an absurd-length filter runs BEFORE the expensive summary, not after. End
state: **six route cards, every profile 84–102 ms** on 473k edges.

### The suites: every failure judged on its merits

Smoke 5/5, render 124/124 — after separating product bugs from expired
premises from harness physics:

- REAL, fixed: draw-dedup could suppress a closure/designated line (now
  undroppable — the red line always draws); the memo/bridge staleness above.
- EXPIRED premises (landmine 197): the away drill's "far away" fix was Detroit
  — inside Michigan; its coordinates were the bbox midpoint — **the middle of
  Lake Michigan**, every pin snapping to one shoreline node; "no restrictions
  in this region" was box truth. Drills now stand where riders stand
  (manifest.centre), compute their own away point, and read manifest.bulk.
- HARNESS physics (landmine 198): statewide sources out-tile any fixed nap —
  the dam check, the drawer tap and the machine-count comparison all needed
  settle-then-measure. Third appearance in one take made it a law.
- Marker stub now re-registers on addTo, like real MapLibre. Waypoint drill
  asserts identity, not stub-fragile count. Dispatch-scan budget scales with
  edge count and prints its µs/edge (A96 owns the real fix).

### Still open, in Jacob's declared order

Great Lakes water polygons → tuning: riding-area polygon (Silver Lake), 
statewide summits OOM, address size, corridor box-prose, A96 typed arrays,
residential display layer. Then A136/A137: onX Backcountry + Hunt/Fish
references, the modes era.

---


## Take 116 — 2026-08-25 — The CI break was mine: bulk patches that never ran

Jacob's GitHub build died at terrain: `NameError: ROOT` — my take-114 bulk-mode
patch referenced a ROOT that terrain.py never defines, and imagery.py carried
the identical latent crash. The patches had been verified by PARSE ONLY; their
steps never executed locally because the payloads were cached. CI, the clean
runner, executed them first (landmine 194 — landmine 32 in tool form). His
installs of takes 114 and 115 were blocked by this; take 116 is the one to
build.

Fix is structural, not spot: **regions.json is now read by region.py alone** —
`R.bulk` is a first-class attribute and all five bulk-aware tools (ingest,
terrain, imagery, contour, landcover) ask R instead of re-deriving paths. The
three previously-unexecuted steps were then RUN for real (terrain 110 tiles,
contour, imagery full pyramid — all green), both regions' flag resolution
verified, full suite green. PROTOCOL gains the rule: touched steps run before
the seal.

Jacob's ordering confirmed for the statewide arc: **Michigan first, the Great
Lakes right after, then tuning** (A135 note updated).

---


## Take 115 — 2026-08-25 — Full adversarial audit of T1–T4, at Jacob's order

Jacob: confirm T1–T4 are real, find every loose end, and audit the landmines
themselves — trust to be re-earned by verification. Audited the SEALED ZIP
first, because the zip is what he gets (landmine 191's content corollary).

### T1–T4 presence: 16/18 on first pass, 18/18 after two real fixes

Every claimed mechanism verified inside `apex-seed-t114.zip`. The two misses
were genuine T1 gaps:

- **`.actrow.on` still glowed full orange** — the accent rule had been applied
  by sweep and held by memory, and memory decayed within two takes. Quieted to
  the same white tint as the basemap toggle, and the rule is now a COUNTER: the
  render suite counts accent-surfaced elements and fails above one per screen
  (landmine 192).
- **Coordinates were not last on the card** — T1's spec demoted them to the
  bottom; they had landed above the stats row. Filed correctly.

Also: **`fatal()` had dodged the one-face rule** — it lives in build_app's
loader template with `Roboto` split across string concatenation, exactly how
the take-113 sweep missed it. Barlow now, even on the worst screen.

### The wiring and loose-end sweep

40+ buttons cross-referenced; the "unwired" alarms were dynamic card buttons
bound after `show()` — probe error, not product error. Zero TODO/FIXME. Stale
files gone. Six ICONS entries currently unused (`stop, sat, target, phone,
check, truck`) — kept deliberately as inventory for upcoming cards, recorded
here so they are a decision rather than drift.

### The landmine audit — the ledger holds

**193 entries, zero gaps, zero duplicates, 49 cited inside live guards.** No
entry was found prescribing structure the redesign invalidated — stale mentions
are historical narration, which is what a ledger is for. One structural fault:
**entries 68 and 119 were filed out of numeric order**, invisible to the
set-completeness check. Relocated (content untouched), and the gate now asserts
strictly ascending file order so it cannot recur.

**Three of the audit's five alarms were the probe's own regexes** (landmine
193): a probe earns belief the same way a check does — against a known-true
case first. Protocol §0 now says so, alongside the delivery rule: verify what
is IN the outputs directory, named and hashed.

### Michigan and the third reference

Statewide prep re-verified dormant and intact (default region unchanged, bulk
paths inert, all patched tools parse). **onX Backcountry** joins as the third
reference — DESIGN.md §7 reserves the slot, A136 awaits Jacob's screenshots.
Transcribe, don't invent.

### Verified

Smoke 5 modes, 274 assertions. Render **132** (the accent counter is new).
Gate **31** including the new order check. Sealed as `apex-seed-t115.zip`,
hash in the message.

---


## Take 114 — 2026-08-24 — T4, a delivery failure, and Michigan parked at the door

### The take-113 seed never reached Jacob — and his report was the evidence

Jacob installed "the latest" and got take 112. Direct check: the deliverable in
the outputs directory WAS the take-112 zip (685,907 bytes, 18:51), despite the
take-113 seal having verified and listed the new file (844,951 bytes, 20:01) in
the same turn. The workspace held take 113 intact throughout; only the delivered
artifact reverted between sessions.

The in-turn verification was real and it was still not enough, because it
verified a filesystem that did not persist. Structural fix, landmine 191: **the
seed now carries its take number in its filename** (`apex-seed-t114.zip`) and
**its sha256 is printed in the message beside it**, so a stale artifact can
never impersonate a fresh one — and session start re-checks what is actually in
outputs before claiming anything about it.

### T4 · one typeface carries the whole app

The SDF glyph pack is now built from **Barlow SemiBold** — SemiBold because
Regular goes thin under SDF at trail-label sizes. The old face is deleted, not
retired: one face, one pack (A134's ruled-out held). Street-name labels re-tuned
for the light ground — quiet grey `#6E6B66`, halo `#F5F6F3` at 1.4 — instead of
the dark-on-tan values they had carried since the old basemap.

All label-placement checks passed untouched: trail names still place, water
names still place, the shield text renders in the new face.

### Michigan: fully prepped, deliberately parked

Jacob's call mid-preparation: the visual arc ships and gets judged FIRST, then
statewide. The preparation LANDED and sleeps in the tree, all of it dormant
while `neml-bullgap` stays default:

- `regions.json`: **michigan** declared — both peninsulas and Isle Royale,
  12 anchors all inside the bbox, `bulk: true`.
- Five tools grew a bulk mode, each with its reason printed: **ingest** goes
  straight to Geofabrik (a statewide Overpass query is abuse of a volunteer
  service) · **contour** skips (ruled out at take 75) · **imagery** ships the
  underlay, skips the z12+ pyramid (8.6 GB, measured) · **terrain** drops to
  z10 (~150 m/px — z13 statewide is ~38,000 tiles and a 50,000 px mosaic) ·
  **landcover** raises thresholds ~30× and simplifies at 50 m.
- The intelligence that de-risks it, from A72's own take-75 measurements:
  Michigan is **236× the box by area but only 18–26× by network** — the graph
  scales by network. And `corridor.py` already proved the statewide memory
  model in CI.

When Jacob says go: switch region, run, measure, tune. Multiple takes budgeted.

### Verified

Smoke 5 modes, 274 assertions. Render 131. Gate green. Sealed as
**apex-seed-t114.zip** with its hash in the message.

---


## Take 113 — 2026-08-24 — The reference redesign: audit, study, and T1–T3

The biggest single take in the project, run under the NEW WORKFLOW: checkpoints
during the work, one seal at the end. Jacob's brief: *"a love child of onX
Offroad and AllTrails, but Michigan only"* — hybrid reads like onX, the light
map reads like AllTrails, our ORV network on both.

### First, the audit that started it

Jacob asked whether the time was being spent well and whether a different AI
would design better. Honest answers, on the record: the stack (Capacitor +
MapLibre + the offline bundle) is RIGHT and stays; the presentation lagged
because I designed from first principles instead of references and because my
assertions catch broken, never ugly. Both fixed structurally: he sent five
reference screenshots (onX statewide satellite; AllTrails at four zooms
including OUR ground at Mio), the study is transcribed in **docs/DESIGN.md**,
and screenshots are now the review loop — `tools/probe.mjs` is a permanent
scaffold after ~30 takes of rewriting the same boilerplate.

### T1 · Chrome

- **Lucide** (ISC) replaces every hand-drawn icon — 24 icons inlined at build
  time from lucide-static; the renderer embeds full inner markup, not one path.
- **Barlow + Barlow Condensed** bundled offline (www/fonts, 128 KB latin);
  monospace demoted to coordinates only.
- **One control language**: dark near-opaque, white icons, 44 px, small radius.
  Cream pills, grey pills and the orange basemap toggle all died.
- **Accent reclaimed**: orange appears once per screen (the primary action).
  Tab underline gone; active is white-vs-grey like both references.
- **The sheet**: rounded top riding 14 px over the map, centred grabber, no
  standing text. Card hierarchy FLIPPED — the place name leads; coordinates sit
  last, small, in the one place monospace still lives.
- **The place strip folded into Search**: empty query offers all 8 anchors as
  jump chips. #chips stays in the DOM (HUD swap + self-test restore) but renders
  nothing.

### T2 · The ground

New extractor **tools/landcover.py** (pyosmium area handler — closed ways AND
multipolygon relations, so lakes stay punched out of forest; DP-simplified
~25 m): **276 areas, 285 KB** — forest 179, wetland 37, park 59, and one
`public` polygon that is the **Huron National Forest boundary**, washing federal
ground in the deeper tone AllTrails uses. Wired as bundle kind `ground`,
placeholder `__LAND__`, BOTH loader paths. Ground `#E4D7BC → #F2F3F0`; water to
`#A9D3E6`; lake names to a live blue. The tan that drew a national forest as a
desert is gone.

### T3 · The details that read as craft

- **White cased roads** (`minor`/`paved` white over `#C9C8C2` casings) — the
  AllTrails treatment, and white also reads over dimmed imagery, one value both
  styles.
- **Category badges** replace every dot: canvas-drawn circles, white glyphs,
  label in the category colour with white halo. Brown tent, green tree, blue
  boat, gold beach — the AllTrails POI system, drawn by hand at badge scale
  where a stroke sketch beats an imported path. Same system on paddle pins.
- **The Michigan trunkline diamond** for M-routes, upright regardless of road
  bearing; other refs keep the along-line badge.
- **Hybrid dimming**: `raster-saturation -0.35, brightness-max 0.82` — the onX
  inversion, dark ground so the network glows.
- Loose ends: empty stat cells hide; folded band slimmed to a grabber.

### What broke, and the pattern worth keeping

**131 render checks passed UNTOUCHED through the entire reskin, three times
over** — behaviour-and-structure assertions survive a redesign; pixel
assertions would have fought every step (landmine 178 vindicated at scale).

What did break was the harness meeting new browser surface: `MapStub.addImage`
(the gate's stub-API check caught it — working exactly as designed), a canvas
the stub cannot 2d-context, and `parentNode` absent on stub elements — the last
one turned cell-hiding polish into a loader fatal. The rule extracted:
**polish must never be the reason the map refuses to load**; every cosmetic
touch guards and bails.

### Verified

Smoke 5 modes, 274 assertions. Render 131. Gate green across 30, including
loader kinds with `ground`. Sealed as one take.

---


## Take 112 — 2026-08-24 — Four field findings from the take-110 session

Jacob rode the drawer build. PASS 42 / FAIL 1, and four findings — every one
real, and one of them a category of bug this project had not hit before.

### "A random string of test/error code" — twice

The drawer chevron was written as `\u25BE` **in the HTML markup**. That is a
JavaScript escape; in markup it is six literal characters. So the handle
rendered the text `\u25BE` — and the folded state's `rotate(180deg)` then
mirrored it into gibberish near the bar. Both of Jacob's "random strings" were
the same six characters, once upright and once upside down.

Now an HTML entity. The render check asserts the chevron is ONE glyph, so an
escape leaking into markup anywhere near it fails loudly.

**New category:** the escape languages differ per context — JS strings take
`\u`, markup takes `&#x...;` — and a string moved from one context to the other
carries its escapes as freight. Nothing errors; it just draws them.

### The XX in his report: buttons at 28 px

`tap-targets: btn-disp 28px · btn-retrace 28px · btn-steps 28px`. The pinned
action row sits in the folded drawer's clipped box, and flex-stretch inside a
`max-height:0` container squeezes children below their padding height.

`min-height:44px` on the buttons — min-height wins over the squeeze in every
state, and 44 is the glove number. Asserted in the folded state specifically,
because that is where his report measured 28.

### The drawer stood open under the first-run guide

He closed the tutorial and the drawer was already up behind it: the first GPS
fix had arrived mid-guide, `showAway()` called `show()`, and `show()` opens the
drawer — which is exactly what it is for, except that a status message is not a
card about a place the rider touched.

`showQuiet()`: fills the panel, puts a one-line summary on the peek strip
(**"135 mi away · planning mode"**), and leaves the fold alone. The full text is
one handle-tap away. The rule stays clean: cards open the drawer, status does
not.

### Relief was on by default, "it looks really bad" — agreed

The style ships hillshade visible, and over the flat vector basemap it reads as
dark blotches — his screenshots show it plainly. On Hybrid at low opacity it
earns its place, so it starts OFF and stays one tap away under Layers rather
than being removed.

### Verified

Smoke 5 modes, 274 assertions. Render **131 checks**, five new on the field
findings. Gate green.

---


## Take 111 — 2026-08-24 — Hardening: four checks that never ran, and two norths

Jacob: *"Harden and lock down this take, and we'll work out all bugs and
issues/loose ends."* No new features. What follows was already broken.

### The dead twin was still there, and it held three more checks

Take 109 found **two `function stLayout(){}`** in app.html and moved the
dispatch timing into the live one. It did not delete the dead one — so the trap
was still armed, and worse, the dead twin contained **three checks that had never
run at all**:

```
UI/machine-on-map     the map and the router agree about machine legality
UI/hud-matches-ride   the ride ribbon matches whether a ride is running
UI/map-has-room       the map still gets a real share of the screen
```

`machine-on-map` is the one that matters: it asserts the map and the router are
actually WIRED to the same legality rules rather than two lists that happen to
agree. It has been dead since take 80.

All three lifted into the live function, the twin deleted. Lifting them exposed
that `_hb`, `_hs` and `_rid` were defined earlier in the dead body — undefined
references that **threw**, killing every check after them. Defined properly.

**Self-test: 38 checks → 42.**

And the number worth having: `map-has-room: 825 of 915 px (90% of the screen)`.
Before the take-109 drawer the rail took nearly half. Now the map has ninety
percent, and there is a check that will notice if that ever regresses.

### Gated, so it cannot come back

`check_no_duplicate_defs` refuses a duplicate function name, a top-level var
assigned twice, or a duplicate id in the static markup. Three negative controls,
including the take-109 bug reproduced exactly. Baseline:
**163 functions, 102 top-level vars, 70 static ids, no duplicates.**

Nothing errors on this failure. The code reads as live and greps as present. It
is the only fault in the ledger that cost a whole function's worth of silence,
so it is checked mechanically rather than remembered.

### The compass was mixing two norths

Take 109 shipped a compass reading GPS course while moving and the magnetometer
while stopped. **Those are not the same north.** Course-over-ground is TRUE;
a magnetometer points at MAGNETIC, about **7° west** here.

So the same needle meant different things depending on whether the bike was
rolling — and every bearing in the list is computed from coordinates, therefore
true, so "Home WNW 300° · 109° left" was comparing a magnetic heading against a
true bearing and putting the turn figure out by seven degrees.

Everything is converted to true at the source. The rose now says **"42° true ·
compass"**, so one number means one thing and the screen says which.

`DECL_W = 7.0` is a constant, not a model: the WMM changes slowly and this app
covers one region of one state. An approximate correction applied consistently
beats an exact one applied to half the app.

### And the drawer handle was too small to press

At 20 px the open-state grab handle failed the 38 px minimum — a rule that exists
because Jacob wears gloves. The chevron still looks slim; the touchable area does
not.

### Verified

Smoke 5 modes, 274 assertions. Render 126 checks. Self-test **42 passed, 0 real
failures**. Gate green across 30 checks.

---


## Take 110 — 2026-08-24 — Card motion, and a guide for the first time you open it

### The cards move now

Take 109 gave the drawer a slide. Its **contents** still swapped between frames —
tap one pin, then another, and the text simply became different text. A card that
replaces itself with no motion reads as a redraw; one that rises reads as an
answer to what you just touched.

140 ms, transform and opacity only so it composites and costs no layout while the
map is drawing. The place name inside a card rises fractionally longer, so the
eye lands on WHAT you tapped before the detail under it.

**Restarting the animation needed care**: setting the class does nothing when it
is already there — a browser will not replay an animation for an unchanged class
— so it comes off, the layout is read to force the change to land, and it goes
back on.

### Three cards had no motion because they never used show()

Saved routes, route options and the step list wrote `panel.innerHTML` directly.
They got no animation and did not open the drawer. Everything goes through one
function now: **a card written any other way is a card that behaves differently
for no reason a rider could name.**

That refactor cost three syntax errors in a row — the step-list call was inside
an `addEventListener`, so replacing its tail needed `})` and I wrote `}`, then
`)`, then finally read the whole function instead of patching its edge.

### A129 · the first-run guide

Jacob asked for a short guide the first time the app opens, with the map blurred
behind it, reachable afterwards from Tools.

`backdrop-filter: blur(9px)` — the blur is the point, because the map staying
recognisable behind it makes the guide read as something ON the app rather than
a screen before it.

It covers the four destinations, tapping and long-pressing, layers, what the app
knows about legality and closures, the six rivers, and Dispatch. Everything in it
is a fact about what the app DOES. No marketing, and nothing it cannot back up —
including the line that Dispatch refuses to guess.

Dismissed with **Start riding** or by tapping the blurred backdrop, and the flag
goes in the same localStorage as waypoints and saved routes. If storage is
unavailable the guide shows every time rather than failing: an extra tap is a
smaller harm than a first-time rider getting no explanation at all.

Reachable afterwards from **Tools → How to use**.

### I made the same mistake as one take ago

My guide check left the overlay open, and the colour-variety check that runs
later saw a blurred sheet and called the map blank. **A check that mutates shared
state hands that state to every check after it** — landmine 177, written one take
ago, by me, about the device matrix.

### And a threshold that was measuring its edge

`map viewport has 171 distinct colours` failed a `> 200` check whose own message
says a blank map is 1–3. The drawer made the map ~210 px taller and changed the
sampled area. 171 is nowhere near blank, and the sibling check — busiest colour
under 90%, passing at 82.9% — is what actually distinguishes terrain and trails
from a flat sheet.

Widened to a margin that still catches the failure it was written for, with the
reasoning in the file. A threshold tuned so tightly that a layout change trips it
is measuring the edge (landmine 151).

### Verified

Smoke 5 modes, 274 assertions. Render **126 checks**, seven new: the guide opens,
blurs, explains, is remembered, reopens from Tools, closes on the backdrop, and
puts itself away. Gate green.

---


## Take 109 — 2026-08-24 — The drawer, and three bugs from the first real session

Jacob rode take 108 — **PASS 42, FAIL 0** — and reported three things. All three
were real, and one of them had been broken for sixteen takes without anyone
seeing it.

### "I don't think compass works" — correct

It read GPS course-over-ground, which does not exist standing still. Opening it
at a junction with the engine off showed a rose with no needle and a sentence
explaining why: a correct answer to a question nobody asked.

The Fold has a magnetometer and the WebView exposes it through
`deviceorientationabsolute` — **no Capacitor plugin**, which is why none of the
seven on his device mention it. Moving, GPS course still wins; a magnetometer
beside an engine is not to be trusted. Stopped, the compass takes over. Verified:
one reading at alpha 311 gives **`NE 49° · compass`**, with the source named.

### A self-test check that had never run, anywhere

`dispatch-scan` was added at take 93 and is absent from his report. There are
**two `stLayout()` functions** in the file; JavaScript keeps the second and
silently discards the first, and the block was in the first. Dead in his reports
*and* in the harness, for sixteen takes.

It also required `ME`, which is only set INSIDE the region — so it would have
skipped anyway at 135 mi away. Both fixed. **17–22 ms.** The take-93 worry was
unfounded and it took this long to find out because nobody notices a check that
produces no line.

### "The car doesn't look good" — a defect, not taste

The wheels were `a1.6 1.6 0 1 0 0 .1`, an arc too short to render as a circle.
**Eight icons** used that construction — `here`, `locate`, `info`, `clock`,
`target`, `pin`, `sat`, `loop`. All redrawn with real circles; the vehicle
redrawn as a silhouette with a cabin, bonnet and two round wheels.

### The drawer (A127)

Jacob's design, and his diagnosis of why the app felt cheap: the rail was always
there, taking nearly half a map app's screen.

**The rule: the card belongs to a place.** It opens when you touch something and
leaves when that thing does.

```
opens   any card — every one goes through show(), so one hook rather than a
        call at each site
folds   empty-map tap · panning until the subject leaves the screen · the handle
peeks   always — the strip carries distance to the truck and the handle back,
        so nothing is unreachable, only folded
```

It animates `max-height` rather than transform, because the rail is a grid row:
translating it would leave a hole the map does not fill, which is the "just
disappears" he did not want. Folding shrinks the row and the map grows into it.

### Two real bugs the drawer work exposed

**The action row scrolled away.** With a tall card — six route options, a
self-test report — the body hit its cap and Dispatch and Return home went below
the fold. Now pinned OUTSIDE the scrolling body. That would have bitten a rider.

**My device-matrix check leaked state.** It forced the drawer open to measure and
never put it back, so the self-test ran later against a permanently expanded rail
and reported four buttons off-screen. A check that changed the state it measured
and handed that state to the next check.

### What this cost, and what I should have done sooner

I spent four rounds guessing at a failure instead of reading it. The moment the
check reported its own geometry it said `railbody=549 vh=915 btn-home=973` and
the cause was one line. Then again for the second one.

The trap underneath: the check ran in the **same tick** as the `show()` that
opened the drawer, so the class already read open while the 260 ms transition had
not moved — `rail="" folded=false railbody=0`. A class name is an intention; a
rect is a fact, and mid-transition they disagree.

### And what I could not measure

In headless the drawer's measured height **lags its class by a step**:
`railSet(true)` reads `folded:false h:0`, then `railSet(false)` reads
`folded:true h:84`. I could not model that reliably.

So the checks assert what can be measured honestly — the state, and the
*structural* fact that the action row sits outside the scrolling body, which is
the property that was actually broken. Not the pixel mid-animation, which is the
animation. Six behaviours asserted, none of them a number I do not trust.

### Verified

Smoke 5 modes, 274 assertions. Render **119 checks**. All four device sizes
clean. Gate green.

---


## Take 108 — 2026-08-23 — Wiring audit before the ride

Jacob, before testing: *"Ensure all new features have buttons... ensure
everything is connected properly and tie up any loose ends."*

Done mechanically rather than by eye — every button in the source cross-checked
against every handler binding, in all four shapes this file uses.

```
buttons 40 · handlers 47
unwired buttons: none
handlers with no button: none
```

### Two loose ends, both real

**`I'm here` was in the wrong destination.** It arms *"tap the map to place where
you are"* — the twin of `Set home`. `syncArm()` literally treats them as one
gesture and sets both classNames together, and they were split across **Ride**
and **Plan**. Moved to Plan, beside its pair, and the render check now asserts
they share a destination rather than trusting me to keep them together.

**Two dead handler blocks.** `c-relief` and `c-labels` had their chips removed at
take 90 when the layers panel absorbed them, and their `addEventListener` blocks
survived behind `if(el(...))` guards — code that can never run and reads as live
wiring. Removed. `lyrSet`'s guarded writes to the same ids stay: those are
deliberate, so re-adding a chip needs no new code.

### Reachable is not the same as wired

A handler on a button nobody can find is a feature nobody has, so the check walks
all four destinations and confirms every action actually appears in one:

```
every action is reachable from a destination
Set home and I'm here are in the same destination (plan)
diagnostics reachable behind one entry (c-about, c-selftest, c-pan)
7 layer groups reachable from Map
action row always available: btn-disp, btn-retrace, btn-steps, btn-home
```

### Final shape

```
map     layers, locate, search
plan    machine, home, me, fuel, loop, saved
ride    ride, lost
tools   compass, mark this spot, diagnostics
always  Dispatch · Retrace · Directions · Return home
map     basemap cycle · activity filter (floating)
```

Ride holds two chips, which is correct: on a bike you press **Ride it** and
**Wrong turn**. Everything else is setup and belongs before you start.

### Verified

Smoke 5 modes, 274 assertions. Render **109 checks**, five new on reachability.
All four device sizes clean. Gate green across all 28 checks.

---


## Take 107 — 2026-08-23 — Full audit before Michigan

Jacob has not ridden since **take 82**. Twenty-four takes have landed since. He
asked for a full audit before committing to statewide, and set the scope:
Michigan only, permanently.

### What is actually in the build

**23 of 23 claimed app features present**, verified against `www/app.js` and
`www/index.html` rather than against the handoff. Nothing claimed that is not
there.

```
handoff    106 takes, no duplicates, no gaps
agenda     116 ids,   no duplicates
landmines  169,       no duplicates, no gaps
stamps     all 106
bundle     12 artifacts, 3.33 MB
self-test  59 checks across 10 sections
```

Destinations and what is in them:

```
map     layers, locate, search
plan    machine, home, fuel, loop, saved
ride    me, ride, lost
tools   compass, mark this spot, diagnostics
layers  Places · Lakes & rivers · Contours · Named hills · Rivers & paddling
        · Relief · All labels
```

### The audit found a real regression I had shipped without noticing

**The CI cache list is hand-written**, and it had drifted exactly as
`region.DERIVED` did before take 96 and `LBL` did before take 90. Missing:
`poi_payload.json` (take 89), `contour_payload.json` (91),
`corridor_payload.json` (102), and **`osm_cache`** — so every CI build was
re-downloading the 297 MB Michigan extract and re-running the ~285-second
corridor step for a result it already had.

**Fifth occurrence** of the same failure: a set copied by hand drifts from the
set it copies. Now expressed as `./*_payload.json` — the same convention
`region.py` clears by — and gated, with four negative controls.

### And my check matched its own comment. Again.

Two of three controls passed on a gutted cache list, because the check tested the
whole file and the words it was looking for were **in its own explanatory
comment**. Third time (takes 96, 98, 107).

The lesson is not "beware comments". It is **scan the structure, not the text**:
the check now parses the `path: |` block and strips comment lines before looking
at anything.

### What I could not verify, stated plainly

**I could not complete a cold clean run in this environment.** Ingest via
Geofabrik reads the 297 MB extract with an in-memory node index and exceeds a
tool window; `corridor` then reads it a second time.

That is a sandbox constraint rather than a CI one — CI reaches Overpass, so
ingest there is fast — but the corridor step's cost is real and it is mine: it
reads the whole state to build six rivers, on every uncached build. The cache fix
makes that once rather than every time. **A cold CI build is slower than it was
at take 96 and I have not measured by how much.**

### Michigan only, recorded as A123

The Geofabrik Michigan extract is now the permanent source rather than a
stepping stone. Statewide is the end goal, not a phase. Every place the code
could have been made state-agnostic should stay concrete instead.

### Verified

Smoke 5 modes, 274 assertions. Render 104 checks. Gate green, ledgers clean,
stamps consistent, 23/23 features present.

---


## Take 106 — 2026-08-23 — The apology was wrong, and how long the float takes

Take 102 shipped the river miles with an apology: they came out about 0.55x the
local outfitter's table, so every card said they ran short and only the ORDER
could be trusted.

I went to USGS NHD — the federal authoritative hydrography, an entirely
independent survey — expecting it to fix ours. **It agreed with OpenStreetMap to
within 4%:**

```
                     NHD    OSM   outfitter
Burtons  -> Wakeley   9.2    9.3     16
Wakeley  -> Camp Ten 26.2   26.3     50
Camp Ten -> Comins   11.1   10.7     15
```

Two independent surveys do not agree that closely and both come out 45% wrong.
**Our distances were right all along.** The outfitter's mileages run high, and
the app had been apologising for the correct number.

### Which is exactly what makes a time estimate possible

Jacob has paddled these floats and says the outfitter's HOURS are about right.
Both can be true, and together they settle the pace:

```
Burtons   -> Mio  38.5 mi / 15 hrs   = 2.57 mph
Stephan   -> Mio  33.7 mi / 13 hrs   = 2.59 mph
Wakeley   -> Mio  29.2 mi / 11.5 hrs = 2.54 mph
McMasters -> Mio  21.4 mi / 8.5 hrs  = 2.51 mph
```

**2.5 mph** — what a canoe does on a river with light current. Their own figures
imply 4.7, which nobody paddles. Generous miles, accurate hours.

The run card now reads *"Roughly 9 hr 45 min–14 hr 38 min of paddling at 2–3
mph"*, shown as a range because pace is the part being guessed at. The distance
is not.

Checked against two floats with published times, 8.5 hrs and 11.5 hrs — the
range brackets both.

### Their short trips are rounded, and that matters

```
Camp Ten  ->Mio   3.0 mi /  2 hr = 1.50 mph
Parmalee  ->Mio  12.5 mi /  6 hr = 2.08 mph
Mio->Comins       7.8 mi / 2.5hr = 3.10 mph
```

The long floats converge to within 0.08 mph. The short ones scatter across
1.5–3.1 — booking figures rounded to convenient numbers, not measurements. I
calibrated on the consistent ones and tested against those, rather than widening
the range until it swallowed the noise.

### Two checks had to be corrected because the product got better

`the card states once that the distances under-measure` asserted the apology I
had just disproved. `Mio to Comins brackets 2.5 hrs` tested against one of the
rounded short trips.

Both were right when written and wrong once the facts changed. A check encodes a
belief; when the belief is disproved the check has to move with it, and quietly
loosening the product to keep a check green would have been the other way round.

### Verified

Smoke 5 modes, 274 assertions. Render **104 checks**, five new on the estimate.
Gate green.

---


## Take 105 — 2026-08-23 — The Tools bucket gets tools

Take 101 made Tools a bucket by putting About, Self-test and Pan test behind one
Diagnostics entry. It has been nearly empty since. Jacob: *"additional tools to
the tools bucket, like compass"*.

### Compass

The ride HUD has carried a compass ribbon since take 78 — **only while a ride is
running.** Standing at a junction with the engine off, which is exactly when you
get the map out, the app had no heading and no bearing to anything but the truck.

```
[rose]
NE 49°
Home WNW 300° · 5.99 mi · 109° left
Bull Gap Hill Climb  you are here
```

A drawn rose that turns with you, the heading in words and degrees, and a
bearing to the truck, home and every waypoint — each with **which way to turn**,
which is the number you actually use.

It reads `HUD.hdg`, the same heading the ride ribbon does, so there is no second
source of truth and it updates on every fix.

**Standing still it says so**: *"no heading yet — a phone lying still has none;
start moving"*. Android reports `coords.heading` as null when stationary and the
crumb-trail fallback needs two fixes apart, so no-heading is the normal state at
a standstill. A needle pointing somewhere arbitrary would be worse than none.

### Mark this spot

One tap saves a waypoint where you are, rather than long-pressing a map you may
not be able to see in the sun. Same store and same auto-naming as take 92 — the
harness marked one and it came back **"Bull Gap Hill Climb"**.

### Reading the output caught the same bug in a new place

I printed the panel before writing any assertion. It read:

```
Bull Gap Hill Climb N 0° · 0.00 mi · 49° left
```

A bearing to where you are standing. True, would have passed every check I was
about to write, and noise — the identical shape to the 0.0 mi neighbour on the
paddle card two takes ago (landmine 164). Under ~100 ft the row now says **"you
are here"**.

Third take running where printing the thing a person reads found what the checks
could not have. The order — print, read, then assert — is now the habit.

### A check that had aged into being wrong

`Tools shows one entry, not three diagnostics` passed for four takes and failed
the moment tools were added. It asserted the bucket held exactly ONE chip, which
was true only while it was empty — and filling it was the entire point.

What it *meant* was that the three diagnostics sit behind one entry. That is what
it tests now. A check written against a temporary state will eventually accuse
the change that was the goal.

### Verified

Smoke 5 modes, 274 assertions. Render **98 checks**, seven new on the compass:
the rose, the no-heading state, reading a heading, bearing-and-turn to home, "you
are here", one-tap marking, and closing when you leave Tools. Gate green.

---


## Take 104 — 2026-08-23 — Two pins make a run

Take 103's card answers one hop. A shuttle needs the whole float, and all the
machinery for it was already there — ordered stops and dams between.

Tap a stop, **Plan a run from here**, tap another:

```
The run — Au Sable River
Put in  Burtons Landing
Take out  Wakeley Bridge Landing
About 9.3 mi of river between them
No dams between them.
3 other access points on the way: Canoe access, Keystone Landing, Stephan Landing
```

And one that crosses a dam — **tapped downstream-first on purpose**:

```
The run — Au Sable River
Put in  Camp Ten Bridge Boat Launch
Take out  Comins Flats Boat Access
About 10.7 mi of river between them
1 dam on the way — Mio Dam. You must take out and portage it.
7 other access points on the way
3 campgrounds: Paddle-In Group Camp, River Dune Campground, Meadow Springs
· Tapped in the other order — a river only runs one way, so this is the run.
```

**A river only runs one way, so tap order does not decide direction.** The
upstream stop is the put-in whichever was picked first, and the card says it
swapped them rather than refusing a perfectly reasonable gesture. The whole card
turns red when a dam is in the way.

### Read the output first, again

Take 103's lesson held: I printed both cards and read them before writing a
single assertion. The dam run and the backwards tap were both right first time
*because* the printing came first — the checks were written to lock in what I
had already seen work, which is the right order.

### The icon check caught me

`no emoji left in a control: pd-clear`. I put a bare `✕` on the new buttons
instead of the drawn set from take 99, five takes after building that set and
the check that guards it. Converted; the guard did its job on its author.

### Verified

Smoke 5 modes, 274 assertions. Render **92 checks**, five new: put-in and
take-out with a distance, a clear run saying so, a dam run naming the portage,
the upstream stop staying the put-in when tapped backwards, and the card
admitting the swap. Gate green, and **zero leaked temp directories** after a full
run — take 103's fix holds.

---


## Take 103 — 2026-08-23 — The pins answer the shuttle question

Take 102 drew the rivers. The pins did nothing when tapped, which is the part
Jacob actually asked for — *"drop offs, pickups and campgrounds in pins I can
click"*.

### A pin that says its own name answers nothing

What a two-car shuttle needs is what is **above**, what is **below**, and
whether a **dam** sits between. Jacob's description: drop the boats at a put-in,
drive both cars to the take-out, one car back. Get the order wrong and the trip
is wrong.

```
Klacking Creek Canoe Launch · Rifle River
Canoe access · about 8.7 mi down the river
Above: Boat launch · about 4.2 mi · no dam between
Below: Ogemaw County Fairgrounds Camping · about 5.8 mi · no dam between
```

A dam taps differently, in the closure colour:

```
Mio Dam · Au Sable River
DAM — you must take out and portage.
At the dam: Mio Pond T-Dock, Canoe access, Canoe access
Above: Canoe access · at the same spot · no dam between
Below: Boat launch · about 0.3 mi · no dam between
```

That last card **is** the portage: take out at the T-Dock, put in 0.3 miles
below. A dam is checked before a launch when both are under the finger, because
if both are there the hazard is the answer.

### Two bugs the printed output found that the checks did not

All four assertions passed while the Mio Dam card read **"Above: Canoe access ·
about 0.0 mi"** in both directions. A dam usually has an access on each bank,
and both project to the same river mile — so the nearest neighbour either way
was the same spot, and "0.0 mi" answers nothing.

The checks asked whether the card *said* what was above and below. It did. They
could not ask whether the answer was any use. Printing the card and reading it
took one command and found what four passing assertions could not.

Fixed twice over: neighbours within 0.06 mi are skipped so the row names a
genuinely different place, a gap under 0.1 mi reads "at the same spot" rather
than "about 0.0 mi", and a dam now lists what sits AT it — which is the take-out
you are looking for.

### The caveat travels with the number

Every card states once, in plain words, that the distances are measured along
the mapped line and run short of a real float, and that the ORDER is what to
trust. The honesty from take 102 is not in a document somewhere; it is on the
card a paddler reads.

### And the gate went red on something that was not this take

`render failed: net::ERR_INSUFFICIENT_RESOURCES` and a puppeteer crash. Not a
code fault — **the disk was at 100%, 19 MB free**.

`smoke-fatal` copies `www/` to a temp directory to corrupt its manifest and prove
the app refuses a broken bundle. The copy carries 45 MB of imagery and was never
deleted. **189 of them had accumulated, 11 GB.** The drill that proves the app is
safe had been quietly filling the machine since take 15, and it surfaced as a
rendering failure — landmine 101's corollary from a direction nobody watched.

It now sweeps stale copies before creating one and removes its own on exit, so a
run that dies still cleans up and the next run does not trust that the last one
did. Verified: zero left behind after a run.

### Verified

Smoke 5 modes, 274 assertions. Render **87 checks**, four of them on the card:
above and below, dam-between, take-out-and-portage, and the caveat. Gate green.

---


## Take 102 — 2026-08-23 — Rivers, chosen by evidence

Jacob wants to paddle. He named the Au Sable, Rifle, Black, Pine and others, and
then said the thing that shaped this take: *"this would get crazy for every
river. We need a filter."*

### The filter is derived, not typed

A hand-written list of famous rivers is opinion, it goes stale, and it does not
survive going statewide. **A river is paddled if people have built places to put
boats on it** — which is evidence, and it is already in the data.

Measured across Michigan: **574 named rivers, 2,645 boat and canoe access
points.** Score each river by access points within 500 m:

```
>= 3 access:  83 rivers, 5,139 mi        >= 8:  28 rivers, 2,872 mi
>= 5 access:  52 rivers, 4,162 mi        >=12:  17 rivers, 1,985 mi
```

The ranking falls out as Michigan's canonical paddling list with nobody choosing
it: Huron 78, Au Sable 54, Manistee 51, Grand 44, Clinton 40, Muskegon 33. Every
river Jacob named clears the threshold — Rifle 6, Black 9, Pine 15.

**Six corridors near this region, 390 river miles, 265 KB.** The Rifle came back
at rank four, unnamed by me, with The Ranch Canoe Launch at mile 0.2, Klacking
Creek at 8.7, and six campgrounds from 35.5 to 57.3 — the shuttle Jacob
described, on a river that has **zero points inside the region bbox**.

Extrapolated, all 83 paddled rivers statewide is roughly 3 MB.

### The gaps ARE the dams

Chaining left the Au Sable in 17 pieces and the longest was 86.6 of 123 miles. I
assumed a tolerance bug. It is not: the river way **stops at each impoundment and
resumes below it**, because a pond is a polygon and not a river. Fragment 0 ends
just above Alcona Dam; fragment 1 begins just below it. The same at Loud, Five
Channels, Cooke and Foote.

So a corridor is **reaches separated by portages**, which is what a paddler
actually does. Joining them would have drawn a river you cannot paddle. Five
reaches, four portages of 2.9–7.7 km, every break on a dam.

**A 200 km gap is not a portage.** Michigan reuses river names — one "Black
River" group spans 170 miles of several distinct rivers. Beyond 15 km the
reaches are split into separate rivers rather than joined by an invented
impoundment.

Every corridor runs east with **0 reversed joins**, so "above" and "below" mean
something — which is the whole basis of a shuttle.

### The distances under-measure, and they say so

Validated against the local outfitter's published table for nine access points:
ours runs about **0.53× theirs above Mio and 0.78× near it**. OSM's centreline is
drawn at 62 m point spacing and cannot hold the meanders of the upper river.

Not corrected by a factor — the shortfall is not constant, and a made-up
multiplier applied to a number someone plans a day around is exactly the
confident guess this app exists to refuse. The payload carries the caveat in its
own field so the app cannot forget it.

**What is exact: the order, and every dam.** That is what the shuttle needs.

USGS NHD is reachable and gave 11.2 mi where OSM gave 7.8 and the livery says 10
— markedly closer. It is a per-river web query where OSM is already on disk, so
it is a refinement for later, recorded rather than done.

### The hazard layer is not decoration

Seven dams sit on the Au Sable. A map drawing one blue line from Grayling to Lake
Huron without marking them is dangerous, and A112 makes that a ship-blocker.
They draw in the closure colour, above everything else the layer draws, never
thinned by zoom. Verified: **Mio Dam draws and is named**, 13 dams in the payload.

### The gate caught two things I would not have

`sources with no layer to draw them: padport` — I built a portage-midpoint source
and never drew it. Removed rather than given a layer: a portage pin a kilometre
from its dam is two pins for one hazard, and the dam is the one you must not miss.

`hardcoded coordinates outside regions.json: corridor.py:13` — a coordinate pair
in my own docstring. The check is right to be strict; the docstring was reworded
rather than the guard loosened.

### Verified

Smoke 5 modes, 274 assertions. Render **83 checks** including the corridor
drawing, the layer being off by default, and the dams named. Gate green.

---


## Take 101 — 2026-08-23 — Tools becomes a bucket

Jacob, on being told the Tools destination held About, Self-test and Pan test:
*"Add those under a different bucket, under tools. Under tools, there could be a
diagnostic button that opens another menu."*

Exactly right, and it took one entry. **Diagnostics** now opens a sub-menu
holding the three; the Tools tab has room for what a rider actually reaches for.

```
Tools shows one entry, not three diagnostics (c-diag)
diagnostics holds 3: c-about, c-selftest, c-pan
the diagnostics sub-menu starts closed
leaving Tools closes the sub-menu
```

The three buttons kept their **ids and handlers** and simply live somewhere
else, so nothing that clicks them — the smoke harness included — noticed. Same
discipline as the destination bar at take 98, and the reason 274 assertions
passed untouched again.

Leaving Tools closes the sub-menu. A panel left open across a destination switch
is how a UI starts feeling arbitrary.

### A check that was testing its own stale assumption

The destination check used `c-selftest` as its example of "a hidden chip that
still works". That chip **moved into the sub-panel** and no longer carries
`data-tab`, so the check failed on correct code. It now picks whichever chip is
genuinely in a closed destination rather than naming one that could move —
landmine 127's family: a check that hard-codes a specific thing tests the
hard-coding as much as the behaviour.

### Verified

Smoke 5 modes, 274 assertions. Render **78 checks**. Gate green.

---


## Take 100 — 2026-08-23 — Type scale and motion, and the overhaul closes

Third of three. The gap Jacob felt against onX, measured at take 98, is now shut:

| | take 98 | take 100 |
|---|---|---|
| controls on screen | 14 in one scroller | **≤5**, four destinations |
| icons | 38 emoji | **20 drawn, 0 emoji** |
| transitions | **1** in 3,667 lines | 6 + reduced-motion |
| font sizes | **16** | 6 |

### Type

Sixteen sizes across 44 declarations — 8, 8.5, 9, 9.5, 10, 10.5, 11, 11.5, 12,
12.5, 13, 14, 15, 17, 18, 30. That is not a scale, it is 44 separate decisions,
and it reads as one.

Six steps, every size moved to its **nearest** so nothing shifted more than a
pixel, and the four-device matrix could catch anything that did. 44 declarations
now reference the scale; **zero hard-coded sizes remain**.

Map label sizes are deliberately excluded. They are MapLibre `text-size`
expressions tuned against satellite imagery at take 57, and forcing them into a
CSS scale would quietly undo real measurement.

### Motion

One transition existed in the whole app. Panels appeared and vanished between
frames, which is most of what "feels cheap" actually is.

150 ms, ease-out, **transform and opacity only** — both composite on the GPU, so
this costs no layout work on a phone that is simultaneously drawing a map.
Nothing loops, nothing bounces, and nothing on the map moves: a rider glancing
down mid-trail does not want the interface animating.

`prefers-reduced-motion` is honoured. Someone who asked their phone to stop
animating had a reason, and on a bike in the sun that reason may be legibility.

### The risk that came with it, and the check for it

To animate, a hidden panel must stay in the layout — `display:block` with
`visibility:hidden`. That risks **invisible controls still catching taps**, which
is worse than blinking. Asserted with `elementFromPoint` rather than assumed:

```
ok  an OPEN panel is reachable by tap
ok  a closed panel catches no taps (visibility hidden, pointer-events none)
ok  a closed panel is fully transparent (0)
ok  panels transition rather than blink (0.15s)
```

### Verified

Smoke 5 modes, 274 assertions. Render **74 checks**, up from 61 when the
overhaul began. Gate green.

---


## Take 99 — 2026-08-23 — Drawn icons, and two bugs that would have been invisible

Second of three takes closing the presentation gap measured at take 98. Thirty-
eight emoji were doing the work of an icon set: 😖 for "Wrong turn" renders as a
different picture on every phone, 🏍 is a different bike on Samsung than on
Pixel, and none of them share a weight or a grid.

**20 controls now carry a drawn icon. No emoji remains in any control.** One
24×24 grid, 1.75 stroke, round caps, `currentColor` so an icon inherits whatever
the control it sits in is doing. Inline SVG — no sprite sheet, no icon font, no
fetch, nothing to go missing offline. The tab bar gets icons above labels.

### Deliberately not drawn

The machine. A recognisable motorcycle at 24 px in stroke is beyond what I can
draw well, and a bad one is worse than an emoji — it gets a generic vehicle mark
and the words "Dirt bike 24\"" carry the meaning. Knowing what not to attempt is
part of the job.

### The bug that would have shipped silently

`paintIcons()` expands `__IC_name__` placeholders so the SVG is defined once in
`ICONS` rather than pasted into fifteen buttons. My first version did it by
replacing **`#shell.innerHTML`** — which rebuilds the entire DOM and leaves
nothing wired to it.

The map would still have drawn perfectly. Every screenshot would have looked
right. **Not one button would have worked.** It now replaces each button's own
children, which leaves the button element — and its listener — untouched, and a
render check asserts a handler still fires after the icon pass.

### And one that would have shipped visibly

**Twelve places rewrite a chip's label with `textContent`**, which discards the
icon inside it. Press *Ride it* and the icon disappears; change machine, change
fuel range, switch basemap, run the self-test — all of them. One `setChip()`
helper owns that now, and a thirteenth turned up after the first pass.

### The harness caught the last one

`check_stubs` flagged `El.contains()`. I had reached for `classList.contains()`
when **the codebase already tests classes with `className.indexOf()` everywhere
else**. The right fix was to follow the convention that exists, not to add stub
API surface for a single call — so the stub I had just written came back out.

### Verified

`no icon placeholder reached the screen (0)` · `no emoji left in a control` ·
`20 controls carry a drawn icon` · `handlers survived the icon pass`.
Smoke 5 modes, 274 assertions. Render **70 checks**. Gate green.

---


## Take 98 — 2026-08-23 — Four destinations instead of fourteen chips

Jacob, after asking why onX feels more premium: *"I know how to use the
application but I fear others would get quite confused with the current UI —
trips, loops and saved stuff."*

He was right about the feeling and wrong about the cause. Measured, the gap is
not the architecture — onX is client-server with accounts because it bills
millions of people, not because that makes it feel good. The gap is presentation:

```
14 chips in one horizontally scrolling row
38 emoji used as icons
 1 CSS transition in 3,667 lines
15 distinct font sizes
```

None of that needs a server. This take is the first of three that close it.

### The shell

Four destinations — **Map · Plan · Ride · Tools** — and the numbers are the point:

```
14 actions split across destinations — at most 5 on screen at once
every action belongs to exactly one destination — none orphaned
```

Loop, Saved, Set home, Machine and Fuel now sit together under **Plan**, which is
precisely the grouping Jacob said nobody could infer. Self-test and Pan test are
under **Tools**, where nobody presses them on a trail.

### Deliberately the most boring implementation available

Every chip keeps its **id, its handler and its position in the DOM**. A closed
destination's chips are `hidden` — which `click()` ignores, and which the layout
self-test already skips because it measures elements with height. Nothing in the
app or in either harness had to learn that the tab bar exists, which is why 274
smoke assertions passed untouched on the first run.

It is deliberately **not a router**. There are no separate screens to get lost
between, and the map stays visible in every destination, because on a trail the
map is the thing you are looking at.

### The cost, stated

The bar takes **~52 px of map height**. That broke the contour-label check —
which had been finding exactly **one** label at one viewport, so it was measuring
the edge rather than the feature. I checked whether labels still work before
touching the check: they do, at z14.4 and z15.2. It now probes three zooms.

A check that flips on an unrelated change is testing a boundary. That is worth
more attention than the 52 px.

### On the mode selector Jacob asked for

The container is built; the selector is not. **A mode selector with one mode is
a promise, not a feature.** Paddle needs the river network, the corridor model
(A115) and the dam-portage rule that A112 makes a ship-blocker. When there are
two real modes the selector goes at the top of this shell and the destination bar
stays exactly as it is.

### Verified

Smoke 5 modes, 274 assertions. Render **66 checks**, including four new ones on
the destination bar and clean layout at all four device sizes. Gate green.

---


## Take 97 — 2026-08-23 — A27 measured, and headings that lied

### A27, open since take 21, measured at last

Take 21 shipped the CSP MapLibre build to fix a `blob:` worker problem that
**take 23 disproved**. It was kept as insurance and the entry said: *decide when
the Fold renders.* It renders, so I decided — or rather, measured, and then did
not decide.

```
CSP build      1,396 KB  (engine + separate worker)
standard build 1,032 KB  (worker inlined as blob:)
saving           364 KB
```

Built against the standard engine the app draws **identically** in headless:
3,198 rendered features, no page errors, no map errors, self-test 37/0, all
render checks green.

**And that proves nothing about the phone.** Headless Chrome is not the Android
WebView, and whether a Capacitor WebView permits a `blob:` worker is exactly the
question take 21 could not answer. Reverted to CSP.

It is not one-sided either. The CSP build needs `setWorkerUrl` pointing at a file
that must exist, and `ci/bundle.sh` carries `test -s
www/vendor/maplibre-gl-csp-worker.js` **because that file went missing once**.
The standard build has no such failure mode. 364 KB is 0.7% of a ~50 MB APK
against a possible dead map. Jacob's call, recorded with both numbers.

### Three headings were lying

`A103` read PROPOSED for work superseded eleven takes earlier. `A108` read OPEN
for something that shipped the take after it was raised. `A27` read OPEN.

Nothing errors on a stale status line — a successor simply reads it and believes
it. `check_ledgers` catches duplicate ids and gaps and had no opinion on a
heading that contradicts its own body. It does now.

**My check was wrong twice before it was right.** First it matched
`**Ruled out:**` — the evidence line `check_agenda` *requires on every item* — so
it flagged all nine open proposals. Then it missed A103, because resolution
sub-entries are appended at the END of the file rather than beside their parent,
so it must search the whole document.

Three controls: both real cases fire, and a genuinely open item correctly stays
silent. That last one matters most — a status check with false positives would be
turned off within a week.

## Take 96 — 2026-08-23 — Making the region model safe to widen

A94 and A95, the two remaining preconditions for statewide. Neither changes
anything a rider sees; both are the difference between A72 working and A72
producing a map made of the wrong place.

### A94 · a region switch left seven artifacts behind

`region.DERIVED` was a hand-kept list of twelve. The pipeline produces seven
more it never mentioned — `address`, `context`, `other`, `poi`, `contour`,
`imagery_tiles/` and `dem_meta` — **two of them added by me** at takes 89 and 91
without a thought for the list meant to clear them. It also still listed
`payload.json`, which stopped existing long ago.

A leftover payload is the previous region's data wearing this region's name,
with every hash correct. Landmine 37, and silent.

**`imagery_tiles/` is the worst of them**: 2,008 tiles of the last region's
ground, which survived every switch because `os.remove` cannot delete a
directory and nobody had listed it anyway.

The fix is not seven more names. Every payload this pipeline writes is called
`*_payload.json`, and that convention is now the source of truth — globbed, so a
new payload is cleared the day it is invented rather than the day someone
notices. Only artifacts that do not follow the convention are named, and they
are all imagery or ingest intermediates. **18 files and one directory**, up from
twelve.

Fourth time a copied set has drifted from the set it copies: the palette (77),
the CI dependency map (84), the label layers (90), this.

### A95 · two anchors outside their own region

Flagged UNKNOWN at take 75 as "not traced". Traced now: tapping a place chip
runs `map.easeTo` to that coordinate. `sthelen` listed **Roscommon 2.5 km** and
**Houghton Lake 16.2 km** outside its bbox, so those chips pan the rider to
blank ground — no imagery, no network, no explanation — and both were in the
search index doing the same.

That is landmine 34's family: a map with holes is worse than no map, because you
trust it.

Removed from `sthelen` rather than widening the bbox, and the reason is written
into the region's own note: widening changes what that region *downloads*, which
is Jacob's judgement, not a bug fix. A region that has never been built or
ridden is not the place to make that call unasked.

### The checks, and one that was its own control

`check_region_clean` compares the clear-list against **what the tools actually
write**, by scanning `tools/` for the filenames they emit — so the next payload
someone invents is caught the day it is written. Three negative controls, all
firing, including NC3: a tool starts writing `trailcam_payload.json` and nothing
clears it. That is takes 89 and 91 reproduced deliberately.

The anchor check needed no negative control, because **it failed on the real
defect the moment it was written**:

```
FAIL anchors outside their own region: sthelen/Roscommon 2.5 km outside;
     sthelen/Houghton Lake 16.2 km outside
```

### Verified

Smoke 5 modes, 274 assertions. Render 61 checks. Gate green.

---


## Take 95 — 2026-08-23 — A legal field, built before the data arrives

A101, an A72 precondition. The DNR publishes a free-text restriction on 180
features statewide and **67 of them read "Off road motorcycles are prohibited"**
— Jacob's exact machine. **Zero are inside the Bull Gap box**, which is the
whole reason to build it now: the machinery should exist before A72 widens the
region, not be discovered missing afterwards.

### The recon changed the design

I expected free-form legal prose and budgeted for a parser. Querying the actual
values found **nine distinct strings in the entire state**:

```
67  ORV Routes B BK… ORVs <65in, May 1–Nov 1. Off road motorcycles are prohibited
36  High Clearance Required
23  MDOT ROW Seasonal Connector Open May 1 To November 30
16  4x4 And High Clearance Required
15  ORV A and AG… including off road motorcycles only
13  Restricted ORV Route… May 16th to March 14th
 8  ORVs Less Than 65 Inches Only
 1  MDOT ROW - Seasonal Connector, Open May 1 - November 30
 1  Snowmobile Season December 1-March 31
```

Nine strings is a **table**, not a parsing problem. It is enumerated — a list
that can be read and checked by eye — rather than a regex on legal prose that
would silently mis-classify the tenth.

Note strings 3 and 8: the same rule written twice with different punctuation.
That alone is the argument against pattern-matching cleverness.

### The rule that makes it safe

**The table may only ever take access away, never grant it.** An unrecognised
string bans nobody and is printed *verbatim* on the feature card, marked
"(as published; not interpreted)". Telling a rider what the sign says is honest;
inventing a reading of it is not.

Caught in the same recon: **`-1` is the DNR's null sentinel** and appears on
1,877 of 1,889 routes. Treating it as a restriction would have flagged almost
the entire state network as restricted.

### The drill, because nothing here carries one

A refusal that has never fired is a hope (landmine 45). With zero restricted
edges in the region the only proof is to make one, so the harness injects the
verbatim DNR strings onto real edges:

```
ok  a DIRT BIKE is refused a segment the DNR says prohibits off-road motorcycles
ok  a QUAD is NOT refused it — the restriction bans one machine, not all
ok  an unrecognised restriction bans nobody
ok  and does not silently remove access — it is displayed, not interpreted
```

### Four places, again

`rst` had to be added to **four** stages to survive: the DNR field list, the
noding key list in `graph.py`, `bundle_id()`'s tuple, and the `bk` names beside
it. Landmine 132 says to measure at the END of the chain, which is the only
reason this surfaced in one pass instead of three.

### A89 · cell coverage, ruled out

`broadbandmap.fcc.gov` returns **403** and the bulk download path 404s. OSM has
10 communication masts in the region — and a mast is **not coverage**. Whether a
phone works depends on terrain, power and band, and the terrain here is exactly
what blocks it. Drawing masts as a signal proxy would be the app making a
safety-relevant claim it cannot support, which is the one thing the honesty
rules exist to prevent.

Ruled out on availability, not on value. The honest alternative is recorded:
the app could log where *you* had signal along your own recorded tracks — ground
truth rather than a model — but it ships empty until there are rides, and A18 is
still open.

### Verified

Smoke 5 modes, **274 assertions**. Render 61 checks. Palette 18. Gate green.

---


## Take 94 — 2026-08-23 — Named summits, and a sweep whose reason had expired

A76, the last piece of the orientation set — shields at 88, water names at 87,
places at 89, and now the high ground. Bull Gap is hill-climb country; a named
hill is the landmark people navigate by here.

### Four summits, and the cross-check is the good part

```
Wagon Wheel Hill 1464 ft · Auger Hill 1382 ft
Mio Mountain 1290 ft     · Timberline Mountain 1267 ft
```

**Three of the four match onX's own figures to within three feet** — Auger Hill
1,378 against 1,382; Mio Mountain 1,283 against 1,290; Wagon Wheel Hill 1,460
against 1,460. Two independent maps agreeing is worth more than either alone.

The **name** is OSM's. The **elevation is our DEM's**, because every other
height the app shows comes from that DEM, and a summit label disagreeing with
the readout under your wheels would be its own small lie. Checked before
choosing: our DEM agrees with OSM's surveyed `ele` within 1 m on three of four,
8 m on Timberline.

GNIS 404'd on the path I tried. It did not matter — OSM had the names and our
DEM had better provenance for the numbers.

Summits ride in the **contour payload**, because both are terrain derived from
the same region, and they share a home in the layers panel. Off by default,
drawn as a triangle, which is what a summit is on every map a rider has seen.

### Three faults, all caught by the harness

**The glyph pack had no triangle.** U+25B2 was not in the 107-character set, and
a character the map draws but the pack lacks renders as a box or as nothing,
announced only in a console warning nobody reads (landmine 30). Now 108 glyphs.

**`natural=peak` was dropped in two places** — the Overpass query in `ingest.py`
and the tag set in `osm_local.py` — so `aoi.json` held **zero** peaks while the
code that consumed them looked correct. Exactly the shape of `ref` at take 88,
and landmine 132 says to measure at the end of the chain, which is the only
reason it surfaced in one step rather than three.

**And the one worth keeping.** Summits kept appearing despite defaulting off.
`setBasemap` was re-applying `lbl-trail`'s visibility to **every symbol layer**
on every basemap change, including at load. Its own comment explained why that
existed and why it no longer needed to:

> *Satellite used to force every label off — from before labels had a dark halo,
> when dark-on-light was unreadable over jack pine. They are white on a halo now
> and survive it.*

A no-op in the normal case, and a bug for any symbol layer with its own default
— which is precisely what the layers panel started creating one take earlier.
Removed rather than special-cased; the Labels control still governs every symbol
layer through `labelLayers()`, which is where that belongs.

### Clean run (PROTOCOL §6b)

Three pipeline steps changed, so: pristine unpack, every generated artifact
absent, `osm_cache` and `dem_cache` symlinked because they are external
downloads that CI caches between runs — the test is of the code, not of a
400 MB download.

```
noded 12,649 nodes / 20,546 edges     duplicates 3,250 suppressed (16.1%)
emit  12,236 nodes / 20,222 edges     contour 3,204 lines, 423 KB
summits Wagon Wheel 1464 · Auger 1382 · Mio Mountain 1290 · Timberline 1267
glyphs 108                            verify -> COMPLETE
gate PASSED — 260 smoke assertions, 61 render checks
```

Every number reproduces the working copy.

### Housekeeping

Disk hit **95%** mid-take, which is landmine 101's corollary waiting to happen —
it masquerades as a GPU or render failure. The 1.5 GB `uv` cache is nothing this
project uses; clearing it returned to 86%.

### Verified

Smoke 5 modes, 260 assertions. Render **61 checks** including summits off by
default, summits drawing, and the label carrying a height. Palette 18. Gate
green on both trees.

---


## Take 93 — 2026-08-23 — The dispatch card, timed at last

A96, flagged UNKNOWN at take 75 and carried for eighteen takes without anyone
putting a number on it.

The concern was real on its face: tapping Dispatch runs **six full scans** —
`nearestEdge` (which decodes every edge polyline in the region), plus
`nearestJunction`, `nearestPavement`, `countyAt` and `addressAt` twice. The code
already had a `setTimeout(…, 20)` and a *"Locating you on the network…"*
message, which says the predecessor suspected it too.

### Measured, per scan

```
nearestEdge 17ms · nearestJunction 1ms · nearestPavement 4ms
countyAt 0ms · addressAt 1ms · addressNear 0ms          = 23 ms
```

`nearestEdge` dominates at roughly three quarters of the cost, exactly as
expected. The total does not. **23 ms** is imperceptible, and a second run gave
10 ms.

Per scan rather than as one number, because "the dispatch card is slow" is not a
diagnosis and would not have told anyone which of six things to look at
(landmine 131).

### But that is a desktop, and I nearly stopped there

Extrapolating a phone number from headless Chrome is the same mistake as
measuring label density on a 900×1400 viewport that does not exist (landmine
87). So the timing now runs **on the device**, as a self-test line:

```
PERF  dispatch-scan   N ms to assemble the dispatch card (20222 edges scanned)
                      — this is what you wait for after tapping Dispatch
```

Jacob's next report carries the real number instead of my arithmetic. Threshold
600 ms — generous, because the question is whether a rider notices, not whether
it is fast.

### Not optimised, deliberately

`nearestEdge` could be indexed. It is not going to be, on this evidence: it
costs 17 ms on the machine that can measure it, the app is the same code on both,
and rewriting a working safety path against a number that says it is fine is the
wrong trade. If the device reports something different, that is when it changes.

### Verified

Smoke 5 modes, 260 assertions. Render 57 checks including the per-scan timing.
Palette 18. Gate green.

---


## Take 92 — 2026-08-22 — Waypoints, and a slope layer ruled out by measurement

### A88 first, because it did not get built

Before starting, I measured the slope distribution across the region from the
DEM already on disk:

```
 0-3  deg   65.6%   ################################
 3-6  deg   18.6%   #########
 6-10 deg   10.3%   #####
10-15 deg    4.2%   ##
15-20 deg    1.0%
20-90 deg    0.2%
median 1.7 deg · mean 3.0 deg · max 47.9 deg
```

onX's slope-angle layer uses avalanche bands — 27, 30, 35, 45 degrees. **99.9%
of this region is under 22 degrees.** A conventional slope layer here renders one
flat colour across 1,060 km². Ruled out with numbers rather than carried as a
maybe. The 1.2% above 15 degrees is the interesting part — the hill climbs — and
contours already show it through line spacing, one take ago.

### A84 · waypoints

A dropped pin was ephemeral: one at a time, no name, gone the moment you dropped
another. It can now be **saved**. Tap a pin, tap ☆ Save as waypoint, and it is
there tomorrow — drawn in orange above the world's places, listed under ☆ Saved
alongside routes, with Go to / Rename / Delete.

Auto-named without a dialog, from what is actually there: the address if there
is one, else the nearest trail, else the coordinates. The harness saved one at
the region centre and it came back **"Curtisville Road"**.

### The design decision, and it is the opposite of the last one

A saved ROUTE stores its inputs and is re-routed on open, because closures move
between builds and a frozen line replays a legality decision made against stale
data (take 79, landmine 113).

**A waypoint stores its coordinate.** A point on the ground does not move and
encodes no decision — it is an observation, and freezing an observation is what
saving it means.

Both rules are asserted in the same smoke run, deliberately, so the difference
reads as intentional rather than as an inconsistency somebody later "fixes":

```
ok  a waypoint DOES store its coordinate — a point on the ground encodes no
    decision that could go stale, unlike a route
ok  and a saved ROUTE still stores no geometry — the two rules differ on purpose
```

### Drawn above the places

`wpt-dot` and `wpt-label` sit above the POI layer. A POI is something that is
there; a waypoint is something **you** decided mattered, and when they collide
yours wins.

### What I got wrong

Fired `contextmenu` at `grab("map")`, which is the DOM element stub. The map
events live on `theMap`, the MapLibre stub — two different objects with the same
informal name. Same family as reaching for `window.localStorage` when the app
runs in a `vm` sandbox (take 79): the harness has more than one thing that could
plausibly be called "the map".

### Verified

Smoke 5 modes, **260 assertions**. Render 56 checks. Palette 18. Gate green.

---


## Take 91 — 2026-08-22 — Contours, a fifth product of a DEM already downloaded

A87. `terrain.py` fetches 110 Terrarium tiles at z13 and makes four things from
them — node elevations, per-edge climb, elevation profiles, a rendered
hillshade. Contours are the fifth. **No new source, no new host, no extra
fetch**: the tiles are already in `dem_cache/` when the step runs.

The hillshade shows you there is a hill. A contour tells you how big it is and
carries a **number**, which matters where the whole region has 199 m of relief
and the difference between a rideable sand hill and a wall is fifty feet.

### Measured before choosing, not after

```
interval   levels   lines    points   payload
  20 ft        33    6551    118192    1154 KB
  40 ft        16    3204     42944     423 KB   <- shipped
 100 ft         7    1355     24259     237 KB
```

40 ft is the USGS interval for this relief and puts about seven lines on Wagon
Wheel Hill. Index contours every 200 ft — 1000, 1200, 1400 ft — draw heavier and
carry the label; intermediates are thinner and unlabelled, which is how a paper
quad is read. Bundle 2.59 -> 3.07 MB, about 1% of an APK that already carries
45 MB of imagery.

**Off by default**, in the layers panel built one take earlier. That panel
existed precisely so this would not arrive as another chip.

### Clean run (PROTOCOL §6b)

From a pristine unpack with no DEM cache: `contour: 3204 lines (880 index),
42944 points, 423 KB` and `contour.json fb6d41b680cf` — **byte-identical to the
working copy**. `verify -> COMPLETE`, gate green on the clean tree with 244
smoke assertions and 56 render checks.

### Three mistakes

**The size estimate was for an encoding I then did not use.** 419 KB assumed
delta-encoded ints; the first version wrote raw floats and cost 946 KB. Applying
the same encoding water and graph already use brought it to 423 KB — and the
client's existing `decode()` reads it with no new code. An estimate is only
worth what its assumptions are, and mine were not written down until they were
contradicted.

**A two-line declaration broke the build silently.** `DECLS` entries are
stripped from the source by EXACT STRING MATCH. Splitting the declaration across
two lines with different indentation in `src/app.html` and `build_app.py` left
`CONT = __CONT__` in the shipped app as a literal token, and the map never
constructed — every render check returned `-1` or `undefined`. One line in both
now, with the reason beside it.

**"1 intermediate vs 10 index" was not a bug.** It looked backwards and I nearly
went hunting. Measuring the payload against the actual viewport: the ground
there sits at **1,200 ft**, so that index level genuinely dominates — 59 index
lines against 31 intermediates across 1160 and 1240. Landmine 102 again; the
expectation was wrong, not the feature.

### The gate caught a dependency, then had to be taught

`scikit-image` is a real new CI dependency and `check_ci_deps` flagged it. It
flagged it **again** after `ci/bundle.sh` installed it, because the check
compares IMPORT names and `skimage` is not `scikit-image`. A `PIL -> pillow`
mapping already existed and simply did not know this one. Extended rather than
worked around, with `sklearn` added while I was there.

### Verified

Smoke 5 modes, 244 assertions. Render **56 checks** including contours off by
default, contours drawing, and index lines carrying an elevation. Palette 18.
Gate green on both the working tree and a clean one.

---


## Take 90 — 2026-08-22 — One place that owns what is on the map

A91. The tools strip had reached sixteen chips with basemap, relief and labels
scattered among ride actions, and the 59 places added one take earlier had no
toggle at all. There is now a **▤ Layers** panel: three basemaps and four layer
groups — Places, Lakes & rivers, Relief, All labels.

### The defect it was hiding

`LBL` was a hand-kept array of five layer ids under a comment reading *"every
label layer, so the Labels chip governs all of them"*. By take 89 the style had
**eleven** symbol layers and **six escaped it** — `lake-label`,
`lbl-trail-short`, `poi-label`, `lbl-ref`, `lbl-lake`, `lbl-stream`. Four of
those I added myself in takes 87–89 without a thought for the list meant to
govern them.

The comment beside its *second* use records the same bug happening once before:
*"lbl-show was NOT in LBL, so on satellite the only names left were trails you
may NOT ride"* — take 57. It happened, was fixed by adding one id to the array,
and then happened again with six.

The array is gone. `labelLayers()` asks the map which symbol layers it has.
Third place a copy of a set has drifted from the set: the palette (take 77), the
CI dependency attribution (take 84), and this.

### The harness told me I was making it worse

Three separate checks caught three separate mistakes, each before I could
convince myself it was fine:

- **`one tap shows satellite (none)`** — I had replaced the basemap button with
  a menu, costing a rider two taps and a hunt to reach satellite, in gloves. The
  render harness's basemap checks encode behaviour worth keeping. `c-base` is a
  one-tap cycle again; the panel got its own chip.
- **`Cannot set properties of null`** — `setBasemap` read `c-relief.className`
  to decide whether relief was on. I had deleted that chip. Layer state now
  comes from the map, which is the only copy that cannot be stale.
- **`harness stubs are missing APIs the app calls: MapStub.getStyle()`** — the
  gate's own stub-coverage check, landmine 62's guard, noticed that deriving
  labels from the style meant calling an API the stub had never offered. It held
  the layers already and simply did not expose them.

### And the gate check I wrote was wrong twice

First version matched `var LBL=[`, and passed a tree where the declaration was
gone and a **second call site still stood** — `LBL is not defined`, caught by
the browser, not by the check meant to prevent exactly this. Second version
matched the word anywhere and failed on the comment describing the old bug.
It now matches a use: `LBL` followed by `.`, `[` or `=`.

### Verified

`check_layer_control` gates it: no hand-kept array, `labelLayers()` present,
`LYRGROUPS` present, and **every layer a group claims to govern must exist in
the style** — a toggle that moves nothing reads as a bug. Four negative
controls, all firing.

In a real browser: the panel opens with 3 basemaps and 4 groups; turning Places
off hides both the pins and their labels; **All labels reaches route numbers,
water names and place names — the six layers the old list missed.** Basemap
cycling still works in one tap.

Smoke 5 modes. Render 53 checks. Palette 18. Gate green.

---


## Take 89 — 2026-08-22 — Places you can ride to

A110. The map drew lines. It now draws destinations: **59 places** — 14
campgrounds, 10 places to eat, 9 stores, 5 fuel stations, 5 boat launches,
5 information boards, 4 trailheads, 4 beaches, 2 day-use areas, 1 viewpoint.

All of it comes out of the Geofabrik extract the build already downloads. No new
source, no new host, 4 KB.

### The one that matters most is fuel

The app has costed routes against a fuel range since take 36 — the ⛽ chip — and
has never shown where fuel **is**. Same shape as A82, where telemetry was
recorded from take 41 and only elevation was displayed: the capability was
present and the last wire was missing. Five stations, five names.

### A78 closes for free

The trailhead markers wanted since take 43 turn out to be `amenity=parking`
carrying a name — **Bull Gap Trailhead, East Bull Gap Trailhead, Bull Gap Hill
Climb Trailhead**. No new work, no new query; they were in the data the whole
time behind a tag nobody had looked at.

### What is deliberately NOT shipped

205 unnamed parking areas, 15 unnamed shelters and 13 unnamed toilets are in the
region. Shipping them would be clutter, not information, so `amenity=parking`
ships only when it carries a name — which is how a trailhead identifies itself.

Beaches are the documented exception: all four are unnamed in OSM and a beach is
still a destination, so they ship and are labelled **"Beach"** by kind. Jacob's
Island Lake beach sits 6 m from the named `Island Lake Day Use Area`, and it
would be easy to borrow that name. That is inference dressed as fact and the
answer is no — both are drawn, and the day-use name sits beside it.

### Verified

Smoke: places payload 59 entries, fuel among the kinds, **every place inside the
region bbox**. Render: 16 pins of 59 drawn at the test viewport, named
`Family Fare, Mio Hydro, Paddle-In Group Camp, Beach, Mio Pizza Shop` — note
`Beach` labelled by kind, which is the honesty rule visible in the output.
Gate green. Self-test 38.

### What I got wrong

I opened this take believing the app side was unbuilt, because
`grep -c "POI\b" src/app.html` returned 0 — and `\b` does not match `POIS`,
`POIKIND` or `poif`. The whole feature was already there. Before that I had
written a second `POI` table into `osm_local.py`, which the existing
`POI = poi_tags()` silently shadowed; that table reads `POI_TAGS` out of
`ingest.py` by AST precisely so the two OSM paths cannot diverge, which is the
correct mechanism and better than what I was adding. Removed as dead code.

Second session in a row where work I had done earlier had left my working
memory and reading the file was the only thing that caught it — take 80 was the
first. The habit that saves it is grepping before writing, and the grep has to
be right.

---


## Take 88 — 2026-08-22 — Posted route numbers

A75, the other half of the orientation furniture from Jacob's onX screenshots.
"Two east of M 33" is how a rider says where they are, and the number is on
every sign where the street name often is not. We had it in the data and threw
it away twice.

### Dropped in two places

`ref` was discarded at the OSM ingest into the graph, and again by the noding
step, which rebuilds edges from an explicit key list. Both had to be fixed to
get one field through — the second only became visible because the first
measured **0 edges with a route number** after the first fix looked correct.

**4,470 edges carry one, across 183 distinct refs**: `M 33`, `M 72`, `F-28`,
`489`, `H57-7`, and Forest Road numbers. Packed through the same name dictionary
as trail names, since 183 strings shared across 4,470 edges is far smaller than
repeating them.

### A60 had already done the right thing

**2,318 of the 4,470 are hidden** as cross-source duplicates — 1,693 of them
tracks, which are the OSM copy of a Forest Service road we already label with
its FS number from the authoritative source. Left drawn: **2,152** — paved 760,
minor 527, track 865. Had A75 landed before A60, the map would have carried the
same number twice on two parallel lines.

### Chained, because a routing edge is too short to label

Median routing edge is 76 m; a line label needs several hundred. `chainStrokes()`
already solves this for trail names, so it was **parameterised by key** rather
than copied — a second walker is a second thing to keep in step, and they would
drift the way the palette did (landmine 107). Trail names chain by `labelFor`,
route numbers by the posted ref. 703 ref strokes result.

Multi-value refs (`M 33;M 72;F-32`) are split where they are drawn, not at
ingest — the raw value is what the source said and is worth keeping intact
upstream. Two fit along a road at riding zoom; a third is dropped rather than
truncated into nonsense.

### Priority, gated

`lbl-trail 29 < lbl-ref 33 < lbl-lake 34 < lbl-stream 35`. MapLibre places
symbols in layer order, so the trail you are riding wins, a road number beats a
pond, and both are now asserted rather than assumed.

Verified on the map centred on M 33 — coordinates read out of the payload, not
guessed: **`H58-1, M 33`**.

### What I could not settle

Trail names at the z14.5 Bull Gap anchor read 2 before this take and 1 after. I
could not establish whether that is real: two attempts at an A/B both landed on
runs where **no trail geometry drew at all**, and the headless placement varies
run to run. What the check now reports is the denominator — **1 label from 1,708
labelable strokes** — which says the viewport is small, not that labels are being
crowded out. The structural guarantee is the layer order, which is gated. Only a
ride settles the rest.

### What I got wrong

Bundled three edits to `render.mjs` in one script with an assert on each. The
third anchor was stale, the assert fired, and **the whole patch was discarded
including the two good edits** — the file is only written at the end. Landmine 99,
which is in the file, which I had read. Applied separately afterwards and all
three landed.

### Verified

Smoke 5 modes, 236 assertions. Render **48 checks** including route numbers
placed, the ref layer's position, and the new trail-label denominator. Palette
18. Gate green.

---


## Take 87 — 2026-08-22 — Naming the water, and four hours of blaming the product

A77. The map drew Shaw Lake and the Au Sable as anonymous blue shapes. It now
names them. A lake you can name is a landmark you navigate by; a blue blob is
scenery — Jacob's onX screenshots labelled Lake Saint Helen, Cooke Dam Pond and
Maltbys Swamp, and ours labelled nothing.

### The data was there and being thrown away

`pack.py` kept geometry and dropped every name. **175 of the water features
carry one.** Names now ride in a parallel list, one entry per geometry, null
where unnamed — the geometry encoding is untouched, so an older app reading the
payload simply ignores a key it does not know. Cost: 38 KB -> 41 KB.

### Rivers needed chaining, and that was measurable

Lakes labelled immediately. Streams placed nothing, and the reason was not
styling:

```
named streams 133 · length median 139 m · text needs ~1200 m at z13.5
long enough to carry a label: 16 of 133
max turn angle: median 38 deg, p90 104 deg · my text-max-angle was 45,
                                             which rejected 61 of 133
```

OSM splits a waterway at every confluence, bridge and county line. The app
already solves this for trails — `chainStrokes()` joins consecutive edges
sharing a label — so water is chained the same way, but **once at build time**
rather than on every app start, because water has no node ids to chain on and
coordinates are cheaper to match in Python than in the client.

**133 fragments became 28 strokes. Median length 139 m -> 2,361 m.** The Au
Sable is now one 68.9 km line. Long enough to label: 16 of 133 -> 20 of 28.
`text-max-angle` raised 45 -> 70, matching `lbl-road`.

Verified on the map: **Shaw Lake, Twin Lake, Briggs Lake, Muleshoe Lake** and
**Wolf Creek, Au Sable River**.

### Trail names win collisions by construction, not by hope

MapLibre resolves symbol collisions in layer order, so the water layers sit
after every trail-name layer: `lbl-trail 29, lbl-lake 33, lbl-stream 34`, and
the gate asserts that ordering. I tried to prove it empirically first and could
not — see below.

### What actually happened, which is the part worth reading

I spent most of this take convinced the layers were broken. They were working
almost from the start. Every "0 labels" reading came from an instrument fault:

1. A throwaway probe reported zero labels of **every** kind, trail names
   included. It was failing to load glyphs. Deleted rather than debugged.
2. An A/B said water labels *increased* trail names from 0 to 2 — impossible.
   That run had `trails = 0`: nothing drew at all.
3. `getSource("wlbl")._data` is private and undefined in MapLibre 5, so the
   diagnostic threw and reported `-2`, which reads as "no source" when the
   source had 175 features.
4. Then two probes in a row centred on viewports **with no named water in
   them**. Loon Lake is at 44.518; the Au Sable runs at 44.61–44.68. I was
   probing Bull Gap at 44.50 and 44.57 and concluding the layer was dead.

The thing that finally located it was changing the check from a verdict to an
observation: `0 label(s) of 175 in the source` plus a sample feature. Every
earlier reading said only "0", which is compatible with a dozen causes.

### Also fixed

`render.mjs` printed **`0 trail NAME labels — a rider can identify the trail`**
and marked it `ok`, because of an escape clause for runs where nothing drew. The
preceding check does fail in that case so the gate still goes red, but that
sentence is actively wrong in a log someone reads later. It now says
`NOT MEASURABLE — no trail geometry drew in this run`.

### Verified

Smoke 5 modes, 236 assertions. Render 46 checks including the two new water
assertions. Palette 18. Gate green.

---


## Take 86 — 2026-08-22 — A60: route both, draw one

The doubled parallel lines Jacob reported at take 62 — *"some paths don't match
the road properly"* — are gone. Open since take 60, blocked on measurement until
take 84 fixed the instrument.

### What ships

**20,222 edges routable, 16,972 drawn.** 3,250 edges (16% of the network,
111 miles of 2,244) stay in the graph and stay routable, and are not painted.
Every routing profile, loop, snap, retrace and cost function sees the identical
network it saw before.

### The predicate is source, not distance

Take 60's note says "duplicate geometry: route both, draw one" and does not say
what a duplicate is. At 17 m there are 8,103 near-parallel pairs, and **2,934 of
them share a source** — 861 are `mccct+moto24`, the Cross Country Cycle Trail
running along a motorcycle trail. That is two legal designations on one
corridor, not one road drawn twice. Collapsing on proximity would have deleted
861 pairs of legal designation and nobody would have seen an error.

Only **cross-source** pairs are duplicates. Of the 3,250 suppressed, **3,040 are
the OSM copy** and 210 are USFS line losing to a designated DNR trail.

### Which copy survives is by priority, never by length

```
closed / fsclosed        never hidden — a closure must always be visible
designated ORV classes   carry legality the OSM copy does not
fsroad                   agency road with MVUM per-vehicle rules
track / minor / paved    advisory OSM context
```

**Every designated class came through untouched**: `trail50` 0 hidden,
`mccct` 0, `moto24` 0, `route72` 0, `closed` 0, `fsclosed` 0. The suppression
falls where it should — `track` −2,194 edges / 70.8 mi, `minor` −811 / 35.1 mi.

### Two places, not one

`nf2` filters the drawn features. **`chainStrokes()` had to be filtered too** —
it walks `EDGES` and chains consecutive edges sharing a label into strokes for
line labels. Left unfiltered, a chain walks straight through geometry that is
not on the map and the trail name lands on empty ground. A60's note does not
mention this and it would have shipped as an invisible regression.

Old payloads with no eighth field are treated as all-drawn, so a stale bundle
degrades to the pre-A60 picture rather than to a blank map.

### A gate hole the APP found first

Mid-take the self-test failed `LOAD·terrain`: `terrain.json` had **18,252** node
elevations while `graph.json` had **12,236**. Terrain was stale from the
previous TIGER run — and it hash-verified perfectly, because nothing had ever
compared two artifacts to *each other*. `check_artifacts_agree` now does.

A runtime check catching an incoherent bundle before the gate does is the wrong
way round.

### Verified

`check_drawn` gates the invariants: no class entirely undrawn, and nothing in
`NEVER_HIDE` suppressed. **Five negative controls** — a whole class hidden, a
closure hidden, designated trail hidden, terrain from a different run, and the
eighth field stripped (which correctly degrades rather than fails).

Smoke **236 assertions** including both halves of the promise: every suppressed
edge still present in the routing adjacency, and no closure or designated line
among them. Render 44. Palette 18. Self-test 38.

---


## Take 85 — 2026-08-22 — Geofabrik becomes a real fallback tier

A108, with Jacob's agreement. The chain is now:

```
Overpass mirrors  ->  Geofabrik extract  ->  Census TIGER roads
```

### Why the order is the whole point

The tiers are not equivalent, and treating them as interchangeable is what cost
the last nine takes their water layer:

| tier | edges | water | topology |
|---|---|---|---|
| Overpass | 20,222 | yes | the shipping network |
| **Geofabrik** | **20,222** | **yes** | **identical** |
| TIGER | 34,341 | **no** | different shape |

Geofabrik is the same OSM ways, same tags, pulled through the sanctioned bulk
path instead of a volunteer query API. Before this take, one Overpass outage
cost the water layer and changed what the map was made of. Now it costs a
297 MB download and nothing else.

TIGER stays as the last tier: Geofabrik needs a compiled PBF reader and a large
download, and a build that can still finish with neither is worth keeping.

### The clean run, which is the proof

From a pristine unpack, no caches, Overpass down for both mirrors, the extract
downloaded from scratch:

```
osm: overpass-api.de HTTPError 503
osm: overpass.kumi.systems HTTPError 502
osm: every mirror failed (HTTPError)
osm: trying the Geofabrik extract (sanctioned bulk path, ~300 MB on first use)
osm: aoi.json written from Geofabrik (4849 ways) — real OSM data, water included
water: 244 polys, 180 lines          graph 20,222 edges / 12,236 nodes / 99.7%
verify -> COMPLETE                   smoke: badge 'GRAPH 20222', not PARTIAL
```

**The first COMPLETE bundle from a clean run in this container since take 76**,
with Overpass unreachable throughout. The same clean run one take ago produced
34,341 TIGER edges and no water.

### overpass.osm.ch removed

It is the Swiss chapter's instance: a Bern bbox returns 4,176 ways, a Bull Gap
bbox returns 0. It sat in the mirror list for twenty-six takes as a fallback
that could not once have worked, answering HTTP 200 with an empty set — which is
precisely why landmine 74's empty-result guard exists. The guard was right; the
mirror was never valid. Its PROVISION declaration went with it, and the
declared-but-never-reached check caught the leftover immediately.

Two mirrors now, not three, and the gate refuses to let it back in by name.

### Verified

`check_osm_fallback` gates the chain: Geofabrik reachable, TIGER present,
Geofabrik tried **first**, `osm_local.py` present, and osm.ch not in the mirror
list. **Four negative controls**, all firing — tier removed, tiers genuinely
reordered, Swiss mirror reinstated, `osm_local.py` deleted.

`ci/bundle.sh` installs `osmium`. `check_ci_deps` was narrowed at take 84 to
read `pipeline.py`'s STEPS table, so it now correctly demands osmium — because
`ingest.py` genuinely reaches it — while still ignoring the local-only
instruments. That narrowing paid for itself one take later.

### What I got wrong

Wrote the chain-order check as `ing.find("tiger_roads()")`, which matches
`def tiger_roads():` — the definition, near the top of the file. It reported the
tiers out of order on correct code. Then my first attempt at the reorder control
mutated `els = osm_local.build()` into `XX_osm_local.build()`, which still
contains the string being searched for, so the control passed without testing
anything and the reorder branch was dead until I wrote a mutation that genuinely
reorders. Both faults were in the checking, not the checked.

---


## Take 84 — 2026-08-22 — Fixing the instrument, and A60 measured at last

No change to the app. This take repairs the thing that made takes 76–83 partly
blind, and then uses it.

### The instrument

Take 83 established that CI reaches Overpass and this container does not:
Jacob's take-82 APK came back with 20,428 edges and a complete bundle while
every local probe returned 0/24. That is a broken instrument, not a broken
product — but it blocked anything that must be MEASURED against the OSM road
network, which is most of A60.

`tools/osm_local.py` builds `aoi.json` from the Geofabrik Michigan extract:
the sanctioned bulk download path, 297 MB, reachable from here at 16 MB/s. Same
output file, same element shape, and the same tag set — verified by reading the
Overpass query string out of `ingest.py` and diffing it, because a copy of a
table is not the table (landmine 107). That self-check earned its place
immediately by WARNing on my first run: my regex looked for
`way["highway"]~"…"` and the real query is `way["highway"~"…"]`.

**Validated against the record**, which is the only thing that makes it usable:

| | take-74 record | this instrument | Jacob's take-82 APK |
|---|---|---|---|
| edges | 20,222 | **20,222** | 20,428 |
| nodes | 12,236 | **12,236** | 12,338 |
| routable | 99.7% | **99.7%** | — |
| water | 242 polys / 180 lines | 244 / 180 | complete |

`emit_graph` returns the take-74 numbers exactly. The local network is the
network that ships.

**This is not a pipeline step and not a fallback tier.** `ingest.py` still uses
Overpass and still falls back to TIGER; nothing in `ci/` runs it. Promoting it
would mean a 297 MB download and a compiled dependency in the build, which is a
decision to make deliberately rather than smuggle in behind a measurement tool
(A107).

### A60, measured on real geometry for the first time

8,103 near-parallel edge pairs at take 64's safe 17 m threshold. Split by source,
which nobody had done:

```
osm  + usfs  4177   CROSS-SOURCE — the A60 case
dnr  + dnr   1493   same source — NOT a duplicate
osm  + osm    897   same source — NOT a duplicate
dnr  + osm    638   CROSS-SOURCE
usfs + usfs   544   same source — NOT a duplicate
dnr  + usfs   354   CROSS-SOURCE
```

**5,169 cross-source pairs, 222.7 mi** — `fsroad+track` 2,651, `fsroad+minor`
1,314. That is Jacob's complaint exactly: the OSM copy jittering alongside the
agency copy.

**And 2,934 same-source pairs that must NOT be collapsed.** The largest group is
`mccct+moto24` at 861 — the Michigan Cross Country Cycle Trail running along a
motorcycle trail. That is not one road drawn twice; it is two designations on
one corridor, and hiding either would hide a legal fact. `track+track` at 601
is two genuinely parallel two-tracks.

**So the rule is not "collapse near-parallel edges". It is "collapse a pair only
when the two edges come from different sources."** Nobody had written that down,
and the take-60 note does not say it. Building A60 on proximity alone would have
erased 861 pairs of co-designated trail.

### Two gate changes, both negative-controlled

`check_ci_deps` assumed `tools/pipeline.py` runs every tool in `tools/`. True
when every tool was a step; false now that three are local instruments — it
demanded CI install a compiled PBF reader to build an APK. It now reads the
STEPS table in `pipeline.py` rather than guessing, and fails loudly if it cannot
parse it. Controls: a pipeline tool gaining an uninstalled import, and
`bundle.sh` dropping pillow — both still caught.

`download.geofabrik.de` is declared in PROVISION with phase `local`. 10 hosts,
all declared and reached.

### What I got wrong

Ran the source-split measurement against `www/bundle/graph.json` — which was
still the **TIGER** build, because I had run `graph emit_graph` without
rebuilding the bundle. It reported 25,210 pairs where the first run reported
8,103. Two measurements of the same thing disagreeing is the signal; I checked
the inputs and found I had measured the wrong network. The corrected run asserts
its edge count before doing anything.

---


## Take 83 — 2026-08-22 — Three faults from the first real ride, and a sandbox that was lying to me

Jacob rode take 82 and sent a self-test report and two screenshots. Everything
below came from that, and the most important finding is one I could not have got
from here.

### His build has OSM data. Mine never could.

| | edges / nodes | bundle |
|---|---|---|
| **his take-82 APK** | **20,428 / 12,338** | **complete — nothing absent** |
| my sandbox | 34,341 / 18,252 | PARTIAL, `water.json` absent |
| take-74 record (OSM) | 20,222 / 12,236 | complete |

His numbers are the OSM profile. **CI reached Overpass fine.** Every "OSM is
down" line in takes 76–82 was an artefact of this container's egress and
nothing else — his screenshots show Shaw Lake and the lakes around Bull Gap
drawn exactly as they should be. Take 82's release notes told him his build had
no water. **It did have water.** Landmine 120 was written one take too late.

The practical consequence: I cannot measure A60 locally, but CI can build it.
That is a constraint on my instruments, not on the product.

### Fault 1 — no way to clear a route

> *"I'm a bit confused how to end directions, I closed the interface for
> directions/my trip I was planning and I still see the lines on the map."*

`clearRoute()` has existed since take 33 and clears all three sources — route,
alternates, approach legs. It was **never bound to anything a rider could
press**, only to side effects of changing machine or moving a pin. Now
`✕ Clear route` sits beside `☆ Save this route` on the route panel.

Deliberately explicit rather than automatic: dismissing a panel is not the same
gesture as discarding a plan, and you may well want the line up while you look
at the map.

### Fault 2 — the self-test turned the compass on and left it there

> *"When I did the self test I think the compass popped up at the top… Either
> way it doesn't work whatever it is."*

The safety drill calls `startRecording()` to test breadcrumb and retrace, and
`startRecording()` turns the ride HUD on. The restore block put back `TRUCK`,
`crumbs`, `crumbMi`, `posMode`, `ME`, `RIDE` and `LASTRIDE` — everything it was
written to think about — and left the ribbon showing over the place chips with
no heading, permanently.

**A drill must put back everything it moved, not just the state it was written
to consider.** It now saves and restores the HUD and chip visibility too.

And the ribbon no longer shows a bare needle: with no heading it says
*"waiting for heading — start moving"*, because a control that renders nothing
looks broken rather than honest.

### Fault 3 — `avg 2 fps · worst 39402ms` was a screenshot, not a device

That was the single FAIL in his report. A **39-second frame**: `requestAnimationFrame`
stops when the app leaves the foreground, so the first frame after you come
back is the length of your absence. One frame in seventy was over 33 ms; the
other sixty-nine were fine.

`stPerf` now watches `visibilitychange` and treats a >2 s frame as absence,
reporting it as info rather than scoring it. Landmine 56's corollary for the
third time: correct behaviour must not be scored as failure.

### Where the checks had to live, and why

I first asserted the HUD fault in `smoke.mjs`. It passed — **`was false, now
false`** — because the stub does not model the initial `hidden` attribute, so
both readings were the stub's default and neither came from the app. Landmine 85
in a harness I had just written. The checks moved to `render.mjs`, where
`hidden` is real, and all nine pass there.

Then the Clear-route check failed while the clear itself demonstrably worked
(226 features → 0). I had measured the button's existence **after** clicking it,
and clearing calls `show()`, which replaces the panel's innerHTML and takes the
button with it. My check was the broken one, again.

### Verified

Smoke 5 modes. Render **45 checks** including nine new field-fault assertions.
Palette 18. Gate green.

---


## Take 82 — 2026-08-22 — Audit before testing, and the ledgers I broke

No feature. Jacob asked for a full audit before he rides takes 76–81, and the
audit found real problems — several of them mine.

### The ledgers had re-accumulated, and I made it worse

Take 43 deduped these by hand and declared "no gaps, no duplicates". By take 81:

| | duplicate ids |
|---|---|
| HANDOFF | Take **49** ×2, Take **56** ×2 |
| AGENDA | **A46** ×2, **A52** ×2 — and **A60**, **A72**, **A87** from me |
| LANDMINES | **78** ×2, **85** ×2 |

**A87 was twenty minutes old.** I added `## A87 — Jacob's machine` while the
backlog block I had landed already used A87 for topo contours. A60 and the A72
precondition were the same mistake: appending a heading for an id that already
existed.

**Landmine 78 was the serious one** — two *different* lessons sharing a number
that `mkapex.py` and `gate.py` both cite. A citation resolving to whichever entry
you read first is worse than no citation. 78a (unresolved step reference) is what
the code means, so 78b (fail where the user can act) took **119**. Landmine 85
was the same lesson written twice; merged, and its "check with nothing to look
at" corollary — which I quote nine times across the codebase — is intact and
was verified to be attached to the canonical entry.

Everything was **disambiguated, never renumbered**: A46b, A52b, Take 49b,
Take 56b, and the reason recorded in each. A number that is already cited keeps
its meaning.

### The durable control (A93)

`check_ledgers()`: no duplicate take, agenda id or landmine number, and no gaps
in either sequence. **Five negative controls**, all firing — duplicate take,
missing take, duplicate agenda id, duplicate landmine, landmine gap — run against
a harness that first proves itself by producing the real baseline note.

Now: **81 takes, 82 agenda ids, 119 landmines, no duplicates, no gaps.**

### The clean run (PROTOCOL §6b)

Take 76 changed three pipeline steps and no clean run had been done since. CI is
always a fresh runner, so this is what Jacob's build actually does. From a
pristine unpack of the seed, nothing cached:

```
ingest -> TIGER fallback, 4556 ways     graph  18475 nodes / 34484 edges, 99.7%
emit   18252 nodes / 34341 edges        glyphs 107 / 45.9 KB
address 2797 segments / 761 names       imagery 2008 tiles / 45.2 MB / 3.40 m/px
bundle PARTIAL, water.json MISSING      www/bundle 10 files
smoke 5 modes / 230 assertions   render 36   palette 18   GATE PASSED (28 checks)
```

Every number reproduces the working copy. The clean tree passes.

### CI ordering, tested rather than reasoned

`ci/bundle.sh` runs the pipeline **before** `npm ci`, so the take-77 palette step
finds no puppeteer. Verified by hiding `node_modules/puppeteer` and running it:
prints *"puppeteer absent — run `npm ci` first, skipping"* and exits 0, pipeline
completes. `node tools/verify_palette.mjs` then runs at line 29, after chrome
installs, and the gate re-runs it at line 31. `ci/apk.sh` references none of it —
it builds from `www/`, correctly.

### Recorded for Jacob

**A100 — his machine is a narrow dirt bike.** On the `bike` profile the take-81
per-vehicle rules exclude **0 edges / 0.00 mi**. The 25-edge quad exclusion
touches nothing he rides. Two consequences worth having written down: if a route
looks wrong on his phone, machine legality is *not* the first place to look; and
takes 80–81 are effectively invisible to him, so he should not be asked to
confirm them by riding. Noted at the `MACHINE` table too, where a future reader
will hit it.

### What I got wrong

Created three duplicate agenda ids in two takes, one of them within the same
session, while A93 sat open in the very file I was appending to. The check that
would have caught it took nine lines.

---


Newest first. Written BEFORE the build ships, per PROTOCOL §6.
The gate refuses to build a take with no entry here.

## Take 81 — 2026-08-22 — The Forest Service states its rules per vehicle, and we read the class

Take 80 dimmed line a machine cannot use. This fixes the rule underneath it:
what "cannot use" actually means.

### The defect

`MACHINE[m].ok` is a **class** allow-list, and for the DNR it is exactly right —
the DNR puts width in the layer a feature comes from, so a 24" trail is class
`moto24`, a 50" trail is `trail50`, and the allow-lists follow.

The Forest Service does not work that way. It publishes **one** trail class and
states the rules **per vehicle** in the attributes. In this region 25 `fstrail`
edges carry `moto: open` with `atv` unset, and their MVUM symbol reads *"Trails
open to motorcycles, Yearlong"*. Class `fstrail` is in `quad.ok`, so **the router
would put a quad on a motorcycle trail** — while the feature card printed
`Moto open` right beside it. The app displayed the fact and ignored it.

`machineLegal(e)` now decides. The class rule stands; where the source states a
per-vehicle rule, that rule governs. Both the router **and** the snapper go
through it, because a snap onto a node the router will not leave either reports
"no route" when a legal one exists or starts the rider on one (take 24). Two
now-dead class allow-lists removed.

```
bike  class-only 34062 edges / 2773.5 mi -> per-feature 34062 / 2773.5   excluded 0
quad  class-only 33318 edges / 2743.7 mi -> per-feature 33293 / 2741.8   excluded 25 (1.95 mi)
sxs   class-only 28508 edges / 2276.9 mi -> per-feature 28508 / 2276.9   excluded 0
```

`sxs` has no stored flag — the MVUM's `other_ohv_gt50inches` and
`highclearancevehicle` are fetched by ingest and dropped before the bundle — so
it falls back to the class rule, which excludes `fstrail` entirely. Conservative
rather than wrong. Recorded open.

### Two findings from the recon that are NOT defects

**`LicenseType: "Snowmobile Trail Permit"` on 552 ORV edges / 99.6 mi.** I was
about to report riders being sent onto snowmobile-permit trail. Then: **1,418 of
1,889 ORV Routes statewide** carry it. Three-quarters of Michigan's ORV route
network cannot require a snowmobile permit. Full records read
`TrailUseCategory: Motorized`, `OpenClosedStatusORV: Open`, and one carries
`SpecialRestrictionType: "…ORV license and trail permit required"`. The field
records a **winter co-designation**. My expectation was wrong, not the data.

**`SpecialRestrictionType` is not ingested** — and it carries real law:
*"ORVs less than 65 inches in width only between the dates of May 1st and
November 1st. **Off road motorcycles are prohibited**"*. **Zero** of the 246
in-region features have one, so Bull Gap is unaffected. It is a latent defect for
A72: the moment statewide lands, features that prohibit motorcycles enter the
graph. Recorded as an A72 precondition.

### The negative controls took four attempts and every failure was mine

1. Imported `gate.py` to call one check. `gate.py` calls `sys.exit()` at module
   level, so the **first import ended the script** — and printed `GATE PASSED`,
   which looks exactly like success. Four controls recorded as passing that
   never ran.
2. Cut the runner off with `SRC.find("for fn in (")`. That matched a line
   **inside my own check**, truncating the function after its second statement.
   Baseline went silent; one control "fired" only because `src` was empty.
3. Diagnosed that as `read()` returning empty. Also wrong.
4. Fixed the anchor and required the baseline to produce the real **note** — and
   the harness then caught a defect **in the check itself**: a fixed
   2600-character window from `nearestNode()` ran past its end into `route()`,
   so the control passed on a `nearestNode` reverted to class-only. The window
   is now bounded at the next top-level function.

All four fire. It took a harness that verifies itself before it verifies
anything else.

### I also lost track of my own state

Mid-cycle I went to write this entry as take 80 and found a **complete take-80
entry already there** — A86, with matching agenda and landmines 114/115, BUILD
and stamps at 80. I had done that work earlier in the same session and the record
of it had left my working memory. Reading the file before writing caught it; had
I written blind I would have produced the duplicate take heading A93 exists to
prevent. `applyMachine()` at line 1631 confirms take 80 shipped code, not just
prose.

### Verified

Smoke **5 modes**, property asserted against the real bundle: 25 motorcycle-only
edges found, dirt bike allowed, quad refused, edges with no per-vehicle rule
still falling back to the class rule. Render 36 checks. Palette 18. Self-test 38.
Gate green with a non-vacuous machine-legality line.

**Overpass:** 8 probes × 3 mirrors — `overpass-api.de` error 8/8,
`kumi.systems` error 8/8, `overpass.osm.ch` HTTP 200 with zero results 8/8.
0/24. A60 stays blocked.

### What I got wrong

Three wrong diagnoses of my own harness in a row, each producing plausible
output. A unit error — I first reported the affected span as 3.13 mi, having
divided metres by 1000 instead of 1609.34; the real figure is **1.95 mi**. And
losing track of which take I was on. Landmine 102 four times in one take.

---

## Take 80 — 2026-08-22 — The map now knows what you are riding

A86. Switch to a side-by-side and the 24" and 50" line fades. It is still drawn,
because it is still there — it is simply not yours today.

**Overpass, measured properly this time: 0/8 on all three mirrors**, eight
samples each at two-second intervals, counting only responses carrying real
data. A60 stays blocked. Landmine 112 applied to its own author.

### This was an honesty gap, not a filter

The router has refused illegal line since take 7. The MAP said nothing. A 24"
motorcycle singletrack and a 72" ORV route were drawn identically, so a rider
planning on a side-by-side saw a dense network, picked a line, and learned it was
off limits only when routing declined. The app knew the whole time.

**Dimmed, not hidden and not dashed.** Hidden would be dishonest about what
exists — the reason non-ORV trails are drawn at all. Dashed already means "not
yours to ride, ever", and a motorcycle trail is a perfectly legal ORV trail that
simply will not take a 72" machine; conflating those two would be a false
statement about the world. Opacity says the true thing: still there, still a
trail, not for what you are on. Closed line stays at full strength — it is closed
to everything, red already says so, and fading it would weaken the one colour
that must not be missed.

### The take-77 lesson, applied the same week

The three casings carry base opacities of 0.95 / 0.75 / 0.55. Dimming them
needed those numbers — and writing them into a second table would have been
landmine 107 all over again, three takes after paying for it. Instead
`applyMachine()` **reads the base out of the style once** via
`getPaintProperty` and computes from there. Proven in the browser: the casing
resolves to `0.285`, which is 0.95 × 0.30, a number that appears nowhere in the
source.

Implemented as a data-driven `['case', ['in', ['get','c'], ...]]` expression
because `casing` covers five classes in one layer, so a per-layer toggle could
not express it.

### Two of my own checks were wrong before the product was

- **Asserted on `moto24`.** It renders **0 features at the harness viewport
  whichever machine is set**, so the assertion was both wrong and vacuous
  (landmine 85). Measured the actual counts and moved to `trail50`: 244 in view,
  legal for a bike, illegal for a 72" machine.
- **Compared paint-expression strings for `paved`.** They differ between
  machines because the ok-list literal differs, even though `paved` is in every
  list and its resolved opacity never changes. Comparing serialised expressions
  was testing the wrong thing entirely.

Both were landmine 54 — a broken instrument accusing a working product — and
both were found by printing the numbers instead of arguing with the failure.

### Verified

Render **36 checks** (was 30), including the one that matters non-vacuously:
illegal line still draws **34 features for a side-by-side, the same 34 as for a
dirt bike**. Dimmed, not hidden, proven by count rather than by looking.

Smoke 5 modes, 220 assertions. Self-test gains `machine-on-map`, which asserts
the map and the router are actually *wired* to `MACHINE[machine].ok` rather than
that two lists happen to agree.

### The gate caught me mid-take

`check_stubs` failed: `MapStub.getLayer()` and `MapStub.getPaintProperty()` were
missing. Landmine 62 doing its job — reading base opacity back out of the style
is a new API call, and a stub that returned `undefined` there would have
collapsed every base to 1 and stopped the casings dimming correctly, silently.
The stub now answers from the real style object it was constructed with.

---

## Take 79 — 2026-08-22 — Save a route, and a lesson about one sample

A85. Plan a route or a loop, tap **☆ Save**, and it is still there tomorrow.
That is the last thing take 25 enumerated as missing from A28 — *"saving and
naming a planned route so it survives an app restart"* — open for fifty-four
takes.

### I nearly built on a fluke

A single probe to `overpass-api.de` came back **200 with `ways = 19`**. I wrote
"Overpass is back" and started a re-ingest. The pipeline immediately got
**503** on the same host.

Ten probes, three seconds apart: **0/10 succeeded.** The one success was noise.
Had I not run the pipeline before reporting, I would have declared A60 unblocked
on a sample size of one and spent a take routing against half-fetched data.

**A60 remains BLOCKED.** Landmine 112.

### The design decision that matters

A saved route stores its **inputs** — the two points, the machine, the profile,
the region, the bundle hash. It does **not** store the line.

That is a safety property, not a storage preference. The bundle carries twelve
temporarily-closed segments, refreshed from the DNR on every build. A route
frozen as geometry in October and replayed in May would draw you down something
that closed in between, with every closure check bypassed because the answer was
already on disk. Re-routing from the inputs runs the current legality filter,
the current closures and the current machine rules every single time.

The cost is that a reopened route can differ from the one you saved. That is
correct, and the app says so in words when the bundle hash has moved.

Asserted structurally rather than by inspection: the stored record is grepped
for `path`, `geom`, `line` and `coords`, and must contain none of them.

### Also decided

- **One tap, no dialog.** The name is generated from what the route is —
  `12.4 mi to the ⌂ pin · 8/22` — because a rider in gloves on a moving bike
  should not meet a system prompt. Rename lives in the panel, where there is time.
- **Save sits below the cards, not inside them.** A button nested in a
  selectable card needs `stopPropagation` on every path, and "save" means the
  option currently chosen.
- **Region-stamped.** A route saved in another region is not offered; a line
  planned on a different map is not meaningful.
- **Re-saving the same name replaces**, rather than accumulating near-duplicates
  the rider then has to tell apart.

### Verified

Smoke gains ten assertions across five modes, including the structural
no-frozen-geometry check and save → list → reopen. Render 30 checks. Palette 18.
Self-test gains `saved-routes`, which reports how many are held and states
plainly that nothing leaves the phone — and says *"storage unavailable in this
browser — saving is disabled, not silent"* when it is, rather than failing
quietly.

`localStorage` is on-device state, not a network surface; PROTOCOL §8 draws that
line at requests leaving the phone. Offline-clean is unchanged and the gate
confirms it.

### What I got wrong, three times

- **Assumed loop options carried `loop` and `target` fields.** They carry
  neither. The real state was already there — `buildLoops` sets `na === nb`, and
  the chip handler records `LOOP_MI`.
- **Called `syncMachine()`, which does not exist.** The chip handler sets
  `machIdx`, `machine` and the label inline; I invented a helper from memory
  instead of reading the three lines that do the work.
- **Reached for `window.localStorage` in the harness.** Smoke runs the app in a
  `vm` sandbox where `sandbox.window = sandbox`; the harness's own `window` is a
  different object entirely.

All three are the same fault: writing against a remembered shape instead of the
one in the file. Landmine 102 exists for exactly this and I tripped it three
times in one take.

---

## Take 78 — 2026-08-22 — The riding screen tells you what you are doing

A80, A81, A82. Heading, speed and trip on screen while riding.

**A60 was the plan and is blocked.** Overpass is still down — `overpass-api.de`
503, `kumi.systems` 500 after 53 s, and `overpass.osm.ch` answering **HTTP 200
with `count = 0`** for a box that certainly has roads, which is landmine 74's
signature exactly. A60 is *about* OSM↔agency duplicate geometry; measuring it on
a TIGER network would be measuring a different problem with the same name. Left
alone until OSM returns.

### What was already there and thrown away

`onFix` took `(at, acc)`. Every fix since take 21 has also carried
`coords.speed` and `coords.heading`, **discarded in both drivers**. Take 41
recorded time, distance and elevation and the app displayed only elevation.
A82 was never a feature to build; it was a wire that was never connected.

### One entry point, both drivers

`hudSet(mps, deg, at)` is fed by the Capacitor watch, the web watch and the
simulator. When a fix withholds speed or heading — Android reports heading
`null` whenever you are stopped, and the simulator has no `coords` at all — both
are derived by differencing the crumb trail, the same data the track is drawn
from. So the simulator exercises every line the GPS path does, which is what
makes it a usable test double (take 16).

`bearing()` and `compass()` are reused rather than reimplemented: take 69
verified those four cardinal cases independently after a reversed bearing would
have sent a reader the wrong way.

### The ribbon takes the chip strip's slot rather than adding height

Top:0 was the place-name chips. During a ride those jump the camera to a town —
and the map recentres on the rider every sixth fix, so they undo themselves the
moment they are used. The ribbon is worth more in that space. Verified first
that the layout self-test skips hidden elements (`offsetParent === null`) and
reports a scroller *count* rather than asserting one, so nothing false-fails.

Stats go top-right, the only empty corner: the left column already holds the
scale at 60, readout at 82, basemap at 104 and activity at 150.

### Verified

**Heading computed outside the code that produced it** (take 69's rule). The
harness steps +8e-4 lon, +5e-4 lat; east = 0.03941 mi, north = 0.03450 mi,
`atan2` = **48.8°** = NE. The ribbon centres on **NE**. A fix carrying
`heading: 90` centres on **E**, and `speed: 8.9408 m/s` reads **20 mph**.

Four-device matrix now **forces the ride state on** before measuring — the HUD
is a new full-width element and the matrix would otherwise have measured it
hidden, which is a check with nothing to look at (landmine 85):

```
small  360x800  ribbon 360px of 360, 4 labels, stats right edge 349
mid    412x915  ribbon 412px of 412, 4 labels, stats right edge 401
large  430x932  ribbon 430px of 430, 4 labels, stats right edge 419
fold   411x960  ribbon 411px of 411, 4 labels, stats right edge 400
```

Smoke **5 modes, 198 assertions** (was 192). Render **30 checks** (was 26).
Palette 18. Self-test gains `hud-matches-ride`, which asserts the HUD's
*response* to the ride state rather than a fixed state — landmine 56's corollary,
the lesson take 76 paid for.

### A gate blind spot, found by my own mistake

I replaced `function rideStop(){` as an anchor and did not restore it, so the
HUD block swallowed the function header. `node --check` on the built file caught
it — **and the gate said `inline syntax ok (2 files)` on the same tree.**

`check_syntax` only ever scanned `www/`. It never looked at `src/`. Since
`check_current` compares take *stamps* rather than content, an edit inside the
same take could sit unparseable in the source with the gate green, so long as
nothing had rebuilt. Take 12's lesson on the opposite axis. Now 3 files, and the
negative control — break `src/app.html`, leave `www/` good — fails as it should.

### What I got wrong

Two things, both mine. The swallowed anchor above, which is landmine 65 for the
second time in three takes and argues for asserting the *anchor's survival*, not
just its presence. And I nearly shipped the device matrix measuring a hidden
element and calling it a pass.

---

## Take 77 — 2026-08-22 — One palette, and the measurement overruling me three times

A74. The legend and the map now read one table, the colours are measurably
brighter over canopy, and the difficulty grammar is stated on screen for the
first time. Three of the decisions here are not the ones I set out to make.

### The drift, quantified

`ACTS` said two-track was `#A9702F`. The layer painted `#9C7343`. **dE 12.9** —
four times the just-noticeable difference — and `#A9702F` appeared **nowhere in
the style at all**. Take 61 set the value, take 64 dimmed the *layer*, take 67
wrote the swatch from the take-61 value, and nothing connected them.

Landmine 98 claimed the picker and the map "read the same table, so the two
cannot disagree." Half true, and the wrong half: the picker read a **copy**.

### One table

`PAL` is now the only place a network colour is written. The style paints from
it, every legend swatch reads from it. `check_palette` fails on any hex literal
in a `lyr()` call, in the show-line expression, or in a swatch — **four negative
controls**, all firing: literal in a layer, literal in a swatch, `PAL` deleted,
and a new drawn class with no legend row.

**Proven in the browser, not in the source** (`tools/verify_palette.mjs`, 18
checks, computed style per row — reading the source twice is how the drift
survived ten takes):

```
easy · 72" route        swatch rgb(15,174,87)   = map rgb(15,174,87)
moderate · 50" trail    swatch rgb(11,127,232)  = map rgb(11,127,232)
difficult · 24"/MCCCT   swatch rgb(28,26,22)    = map rgb(28,26,22)
Two-track               swatch rgb(150,86,42)   = map rgb(150,86,42)
forest road · drivable  swatch rgb(138,124,102) = map rgb(138,124,102)
closed · do not ride    swatch rgb(193,18,31)   = map rgb(193,18,31)
```

### Vibrancy, measured

1,048,576 pixels sampled from this region's own z15 satellite tiles, scored on
four axes at once: sand basemap, darkest canopy, siblings, and every
non-ridable class. dE against canopy:

| | before | after |
|---|---|---|
| route72 · easy | 26.1 | **49.2** |
| trail50 / fstrail · moderate | 62.5 | **74.4** |
| track · two-track | 29.0 | **41.7** |

### Where the measurement overruled me

1. **`#B0722B` won two-track on visibility and lost on legality.** It sits dE
   **12.5** from `nfsmoto` amber — a trail whose ridability the MVUM governs.
   Landmine 88: styling must not contradict legality. Took `#96562A` instead:
   satellite 41.7 rather than 43.6, but **28.2** clear of amber. I had already
   written `#B0722B` into the palette before the collision check caught it.
2. **It refused to give me a colour for `fsroad` at all.** Sand is light
   (228,215,188), canopy is dark (91,106,84), and every lighter candidate gained
   on satellite exactly as fast as it lost on sand — nine candidates, none
   clearing both. `fsroad` is fixed with a **casing**, the same answer as
   designated trail and two-track: 0.55 opacity, the faintest of the three, so
   take 61's hierarchy still reads. Verified drawing 19-for-19 against the
   `fsroad` layer.
3. **`showother` sat dE 5.2 from `fsroad`.** The fallback colour for unmatched
   show-only routes was almost indistinguishable from a forest road the rider
   *may* use, separated only by a dash pattern. Pre-existing, found by the same
   collision sweep. Now **25.5**.

### The legend explains things it never did

Five legend-only rows — three difficulty tiers, forest road, closed. Green /
blue / black is the universal trail-map grammar, learnable the moment it is
stated once, and until now the app never stated it. Tier rows are not tappable
(no `data-k`, guarded at bind time rather than with a `:not()` selector the
harness need not model — landmine 62) and are exempt from the 36 px control
minimum because they are not controls; verified in the browser.

`LEGEND_EXEMPT` declares `minor` and `paved` — grey means road, and Jacob agreed
directly. Declared in the app rather than left as a standing gate note, because
a note that always lists three names carries no signal and a fourth would join
it silently.

### Two harness bugs found on the way

- **`render.mjs`'s readiness poller had a stray fragment** pasted in from the
  route-layer probe: `if (!m) return {route:-1,alt:-1,approach:-1,...}`, which
  made it **return on iteration 0** whenever the map had not appeared yet. It
  only ever worked because of a 3-second sleep underneath it. Landmine 65's
  family — a botched edit that lands somewhere syntactically valid.
- **My own verifier cost twenty minutes because I derived its launch args
  instead of copying render.mjs's.** Without `--enable-unsafe-swiftshader`,
  Chrome silently refuses SwiftShader for WebGL, MapLibre never gets a context,
  and `window.map` never appears — **with no page error to say so**. My
  diagnostic then conflated "never constructed" with "constructed, never
  loaded", which are different faults. PROTOCOL §3, and landmine 55 twice.

### Verified

Smoke **5 modes, 192 assertions**. Render **26 checks**, distinct viewport
colours 843 → **945**, app self-test 36/0. Palette **18 checks**. Gate green,
`palette: 17 colours, one table, style and legend agree; 11 drawn classes, 2
exempt`. `verify_palette.mjs` is a pipeline step now, so it cannot rot.

**Still on the TIGER road network** — Overpass was down for take 76 and this
take did not re-ingest. Trail data is unaffected; the palette work is
source-independent.

---

## Take 76 — 2026-08-22 — A layer with nothing in it is not a layer

v2 opens. The plan was the colour table (A74); a real Overpass outage during the
first clean run produced something that had to come first.

**`ingest` said "no water layer, bundle will be PARTIAL". `bundle verify` said
`COMPLETE`.** Both were running on the same tree, minutes apart.

### What was actually broken — six holes, one family

I found one and fixed it, then found another, then another. After the third,
landmine 82's corollary applies: stop fixing them one at a time and enumerate the
class. The class is **"a layer that is not there is reported as there."**

1. **`pack.py` wrote an empty artifact.** Its guard was *"if `aoi.json` is
   missing, skip water."* Take 56's TIGER fallback **writes an `aoi.json`** — it
   just carries no water tags — so the guard sailed past, pack scanned 4,556
   TIGER elements, found nothing, and wrote a structurally valid
   **65-byte** payload: `{"bbox":[…],"l":{"waterway":[],"water":[]}}`.
   A downstream fallback silently defeated an upstream guard three takes older.
2. **`bundle.build()` staged it.** No producer is trusted to be the only guard on
   a safety-relevant path (landmine 74), and this one catches every future
   producer rather than the one that bit us.
3. **`bundle.verify()` could not see an artifact that was never staged.** It
   looped `man["artifacts"]` — a list that, by construction, cannot contain what
   was never added. **Proven, not assumed:** reconstructing the take-75 predicate
   verbatim against a bundle with `graph.json` never staged returns **COMPLETE**.
   A bundle missing its *required graph* verified as complete. The app's own
   fatal screen would still have caught it at runtime, but the gate would have
   shipped it.
4. **`bundle.build()` left stale artifacts in the destination.** The previous
   run's `water.json` survived, so `build_app` copied it onward and both
   `verify()` and the app's loader saw a layer the pipeline had just refused to
   produce. The app-side check was correct and was defeated by a leftover file.
5. **`build_app.split()` left stale payloads in `www/bundle/`** — and `www/` is
   what `cap sync` packages, so it rides into the APK.
6. **`build_app.single()` hardcoded `state:"complete", absent:[]`.** The browser
   build claimed a full region however much was missing, and `WATER` silently
   defaulted to an empty layer.

### And two assertions scored correct behaviour as failure

With the fix in, smoke went red: `bundle complete, badge 'PARTIAL'`, and the
app's self-test failed `LOAD·bundle-complete`. Both asserted **completeness** —
but PARTIAL is a *designed* state, and take 56 called it "the designed
behaviour" in as many words. Landmine 56's corollary: assert the system's
**response** to a condition, never the condition itself.

- `smoke.mjs` now derives the expectation **from the manifest the app loaded**
  rather than from a `--expect-partial` flag someone must remember to pass. That
  is strictly stronger — it checks the honesty machinery in both directions.
- The self-test check is now **`bundle-honest`**: state and named layers must
  agree, whichever answer that is. *Jacob: this line is renamed in your report.*

### Measured

| | before | after |
|---|---|---|
| bundle with no water | **COMPLETE** | **PARTIAL**, absent: `water.json` |
| bundle with no *graph* | **COMPLETE** | **UNUSABLE** `['graph.json']` |
| empty layer staged | verified, shipped | gate **FAILS** |
| `www/bundle/` stale copy | survives into the APK | removed, named in the log |
| single-file build | always `complete` | reports what it has |

**Positive control — the normal path is not over-degraded.** Three synthetic
water ways injected into `aoi.json` and run through the real `pack.py`:
`1 polys, 2 lines` → bundle **COMPLETE** → smoke asserts *"every optional layer
present — not PARTIAL"* → self-test **37 pass, 0 fail** → gate green, 4 countable
layers.

**Negative controls, both firing.** An empty `water.json` staged and hashed into
the manifest → `GATE FAILED (1)`, naming the artifact and landmine 34. A required
artifact removed → `verify -> unusable`.

**Full verification on the honest (water-less) build:** smoke **5 modes, 192
assertions**; render **26 checks, 4,304 features drawn**, app self-test 36/0;
gate **PASSED**.

### The outage itself, which every guard handled correctly

`overpass-api.de` 503 · `overpass.kumi.systems` 500 · `overpass.osm.ch` returned
200 with a payload that tripped landmine 74's empty check. The take-60 marker
fired exactly as designed — *"cached aoi.json came from the TIGER fallback —
retrying OSM before settling for it again"* — then fell through to TIGER, marked
it, and warned. Takes 60, 74 and 86 all working in a real outage, unsimulated.

**This build's road network is TIGER-derived: 34,341 edges / 18,252 nodes /
2,800 mi, 99.7% in the largest component.** That is the fallback signature, close
to take 56's 35,115 edges / 2,856 mi, and it is **not** comparable to take 74's
20,222-edge OSM figure. Everything else reproduced the record exactly — glyphs
107 / 45.9 KB, address 2,797 segments / 761 names, imagery 2,008 tiles / 45.2 MB
/ 3.40 m/px, relief 199 m.

### What I got wrong

I diagnosed this as one bug in `pack.py` and said so before looking further. It
was six, and the two most serious — a missing *required* artifact verifying as
COMPLETE, and stale files defeating a correct check — were nowhere near the file
I started in. The fix only became durable when I stopped patching instances and
checked the manifest against **what a bundle is supposed to contain**.

I also lost a cycle to a backgrounded pipeline that had silently died: a
process started with `nohup … &` does not survive the turn in this container, and
Python block-buffers stdout to a file, so the log looked like a stall rather than
a corpse. Landmine 106.

### Deferred this cycle

A74, the colour table — specced and measured, next take. The measurement already
corrected my hypothesis: the designated tiers are fine, and the least legible
class on satellite is **`fsroad` at dE 15.8 against median ground with no
casing**. Statewide (A72) stays deferred behind the square, by Jacob's decision.
A72–A98 are reserved in AGENDA for the document-F backlog and land next cycle;
this take took **A99** so no number quoted to Jacob has to move.

---

## Take 75 — 2026-08-22 — v1 capstone (documentation only)

Jacob: **"I'd call v1 done!"** — on the strength of the take-73 field test
(41/0 on-device, screenshots of filter, cards, labels and satellite behaving)
and the take-74 label push.

No code changed this take. What changed is that the project can now explain
itself to a stranger:

- **README.md** — the repo front page, which had never existed: what it is,
  install from Releases, the data-honesty line, the not-an-emergency-device
  block, how the seed builds.
- **docs/V1-STATE.md** — the whole of v1 in one document: numbers, feature
  surface, pipeline, CI, verification, and the honest open list.
- **docs/V2-KICKOFF-PROMPT.md** — the brief for the next session: study
  everything, change nothing, produce an architecture readback, an invariant
  list, a labeled v2 proposal, and questions.

Durable knowledge now lives in the repo, not in a chat transcript. That was
the point of every seal since take 1; this take finishes the job.

---

## Take 74 — 2026-08-22 — Labels one more notch out, from the field

First live field report: **41 PASS / 0 FAIL** on the CI build, screenshots of the
filter, cards, and satellite all behaving. One ask: names further out — "those
show around 1000 ft".

Minzooms dropped again — trail 11.4 → 10.8, road 12.0 → 11.0, forest road
12.4 → 11.6 — and measured before shipping:

| zoom | scale | trail | road | fsroad |
|---|---|---|---|---|
| 10.5 | 2 mi | 0 | 0 | 0 |
| **11** | **1 mi** | **3** | **25** | 0 |
| 12 | 3000 ft | 2 | 19 | 11 |

The z11.3 screenshot settles the clutter question: a dozen named section roads
(Cauchy, Hoy, Evans, Curtisville, Brainard Springs, Fowler…), MAT twice on the
blue line, names tracking their roads with clean halos. That is orientation, not
soup — the section-road grid with names is exactly "which road am I two east
of". Forest-road numbers stay one notch later on purpose; 4-digit IDs at 1 mi
would be noise where names are signal.

Mid-take an aborted run left the tree in an uncertain state; greps confirmed the
minzooms had landed and the measurement screenshot had survived before anything
was rebuilt. Verify, then proceed — cheaper than re-doing either by assumption.

---

## Take 73 — 2026-08-22 — Search forgives a gloved thumb, and the notes became a test script

The last unexamined surface. Search turned out well built — ranked place → trail
→ junction, live address geocoding, trail-ID lookup — with one gap a rider hits
constantly: **it demanded exact text from someone typing in gloves.**

`mcct` (one C short of MCCCT): nothing. `pinkstore`: nothing. `h5717`: nothing.

Two tiers behind the existing exact ones, in strict rank order so a fuzzy hit can
never outrank an exact one:

- **compressed** — spaces and punctuation stripped from both sides, so
  `pinkstore` finds *The Pink Store* and `h5717` finds *H57-17*
- **one edit** — a single wrong, missing or extra character, only when nothing
  better matched and the query is ≥4 characters: `mcct` → *Meadows-MCCCT*,
  `wagnr` → *Wagner Lake*, `bul gap` → *Bull Gap*

Also: forest roads were typed *trail* in results, contradicting the take-61 map
distinction. Now *road* — search speaks the language the map draws.

**`ci/RELEASE.md` is rewritten as a test script in ride order** — opening state,
filter, search, labels, loops, cards, directions, dispatch, satellite — since
Jacob tests from this build. Eleven checks, each one sentence, each answerable.

Disk filled a fourth time mid-verification; the failure-count-with-no-text tell
from landmine 101's corollary named it in one step instead of a debugging
detour.

---

## Take 72 — 2026-08-22 — The county, which decides who gets sent

Left open at take 71. Michigan dispatch is organised by county, so the first
question after "where are you" is which one — and the card could give the
coordinate, the road, the junction, the elevation and the nearest pavement, and
not that.

`context.py` already parses Census cartographic shapefiles and simplifies rings
for the state outline, so the counties come from the same source with the same
simplifier: **9 counties touching the region, 70 points, 1.4 KB.** Ray casting
at runtime; the payload went 7.0 KB → 8.4 KB.

### Verified against the real boundaries, not my memory

Four locations through the actual dispatch card: Mio → Oscoda, Rose City →
Ogemaw, Bull Gap → Oscoda, South Branch → **Ogemaw**.

I had expected South Branch to be Iosco and marked it MISMATCH. **I was wrong and
the app was right** — the full-resolution Census polygons say Ogemaw. Checking
against the source rather than trusting my expectation is the only reason that
did not become a bug hunt for a bug that was not there.

Then the question that actually mattered: does simplification move a boundary?
**3,000 random points across the region, 3,000 agree with the unsimplified
polygons — 100%.** A county line is exactly the place a cheap simplification
would show up, and it does not.

Failure is non-fatal by design: no county list degrades one dispatch line and
never stops a build.

---

## Take 71 — 2026-08-22 — Reading the dispatch card

The highest-stakes screen in the app, and I had never read its output. With no
fix it refuses correctly. With one, it gave coordinates, nearest trail, junction,
truck, elevation and nearest pavement — **and no address at all**, two takes
after the geocoder learned to produce one for most points.

A street name and number is what a dispatcher types into their own system; the
trail name and junction are what the responder needs once close. The address now
comes first after the coordinate:

```
44.65970 -84.13300                    DECIMAL DEGREES
Nearest address 0.2 mi NW of 798 N Morenci Rd, 48647
On or near an unnamed two-track — 505 ft, OSM
Nearest junction Pond Drive × South Ream Road — 0.23 mi N
Elevation 965 ft
Nearest pavement 0.18 mi ESE — North Morenci Avenue
Read the coordinates first, then the address, then the junction.
```

Labelled **"Nearest address"** when it is a bearing-and-distance rather than the
address of the point — the distinction from take 69, carried into the place it
matters most.

**And landmine 101 was here too.** "On or near **two-track**" bolded a class as
though the trail were named that. In directions it reads oddly; on a dispatch
card it is a false statement to someone sending help. Now "an unnamed
**two-track**".

Verified by giving the browser a real geolocation at two points — one with an
exact address (Pink Store: *Address 5525 S Mount Tom Rd*) and one without
(*Nearest address 0.2 mi NW of…*).

---

## Take 70 — 2026-08-22 — Reading the directions for the first time

I had never actually read the turn-by-turn output. It is better than I expected —
turn arrows, trail names carrying the IDs that appear on real trail markers
(`H57-17`), climb notes, right-aligned distances. Two things were wrong.

**Nothing said where you are in the ride.** Every step gave its own length and
the header gave the total, but a rider glancing down mid-ride is asking "I have
done about four miles, which step am I on" — and nothing answered it. `tot` was
already being accumulated for the header and thrown away. Each step now shows the
running total at its start:

```
Bear right  Mack Lake Motorized Trail (MAT)      4.9 mi
                                              at 0.4 mi
Continue    Mack Lake Motorized Trail · H57-6    3.8 mi
                                              at 5.3 mi
```

**"Turn left two-track"** reads as though the trail is *named* two-track. It has
no name at all; the string was a class label dressed up as one. Unnamed features
now read "unnamed two-track", in italic, so the distinction is visible.

Verified at 360x800, the smallest phone in the matrix.

**Disk filled again mid-verification** — my own screenshots — and render reported
5 failures with no failure text. Not a code fault. Third time; the tell is a
failure count with nothing to read.

---

## Take 69 — 2026-08-22 — Silence was throwing away a true answer

`address-at-anchors 2/8` has sat in every field report for twenty takes. I had
read it as a data gap. It was not:

| anchor | nearest addressed road | old behaviour |
|---|---|---|
| The Pink Store | 60 m | address given |
| Mack Lake | 100 m | address given |
| **Mio** | **307 m** | **nothing** |
| **Luzerne** | **377 m** | **nothing** |
| **Rose City** | **635 m** | nothing |
| Bull Gap | 2,555 m | nothing — correctly |

`ADDR_CAP` is 0.09 mi (145 m), and beyond it the app said *nothing at all*. That
rule exists for a good reason — an address 300 m away is not your address, and
claiming it would be a lie of exactly the kind this app refuses to tell.

But there is a true statement available: **"0.2 mi NW of 798 N Morenci Rd"**.
That is what you read to dispatch when there is no address where you are
standing, and it was being thrown away.

Second tier out to 0.55 mi, phrased as a bearing and distance FROM a road, never
as the address of the point. **2 exact, 4 near, of 8.** `address-honest` still
passes — nothing is invented.

**The bearings are verified independently**, because a reversed one sends help
the wrong way: recomputed all four from the raw segment geometry outside the app
and compared compass points. Mio NW, Rose City SE, Luzerne W, South Branch S —
all agree.

`segNear` now returns its planar offset so the bearing comes from the geometry
it already computed, rather than being re-derived.

---

## Take 68 — 2026-08-22 — Two things we already had, doing their job

Asked to improve what exists rather than add features, so I looked for things
already computed that were not being used properly.

### Loops were still costed by hand

Take 58 established that a dirt bike wants trail, and gave point-to-point routing
`DESIG`/`DIRT` tables. **The loop generator never got them.** Its "most trail"
shape named `moto24` and `trail50` by hand and missed `route72`, `mccct` and
`fstrail` entirely — so an MCCCT loop was costed no better than a gravel road.
And `fastest` was listed first, which on a dirt bike means pavement.

Same tables now, most-trail first:

| | before | after |
|---|---|---|
| first loop offered | fastest, **4.7 mi trail of 14.3** | most trail, **15.0 mi of 15.0** |

The cost is 11% ridden twice, up from 0%. For a loop chosen by "most trail", that
is the right trade.

### The elevation profile was a hairline

`summarise()` has computed a full profile since take 12; `spark()` drew it as a
128x26 px line with no numbers. Now it fills the card width, is shaded, and
prints low and high in feet — climb and drop were already on the line below.

**And it had no CSS at all.** Two failed asserts earlier in the take each aborted
their script *before* `write_text`, so the stylesheet additions were silently
lost twice while the markup landed. `.profax` computed to `display: block`,
which is why the two figures rendered as "1955 ft2572 ft". Found by asking the
browser for computed style and span positions rather than looking at a
screenshot: now `space-between`, spans at 0-40 and 90-130 in a 130 px card.

Verified at 360x800, the smallest phone in the matrix.

---

## Take 67 — 2026-08-22 — Filter by activity, which is also the legend

Eight colours had accumulated with nothing anywhere telling a rider what any of
them meant. Jacob asked for an activity filter and for the picker to say which
colour is which — the same control answers both, and that is the right shape:
**a legend that can drift from the map is worse than none**, so the picker and
the map read the same table.

`ACTS` lists every discipline with its swatch colour, its classes, and whether
it is dashed (non-ridable). Selecting one filters the map; roads always stay
visible, because you still need to know where the road is — especially when the
answer to "can I ride this" is no.

Measured at Bull Gap, z12.6:

| filter | designated | two-track | show-only | roads |
|---|---|---|---|---|
| All routes | 143 | 121 | 60 | 233 |
| ORV / dirt bike | 143 | 0 | 0 | 233 |
| Hiking | 0 | 0 | 45 | 233 |
| Snowmobile / ski | 0 | 0 | 1 | 233 |

### Three things went wrong, all caught by harnesses

- **`p.querySelectorAll is not a function`** — the DOM stub models elements but
  had no element-level query API. Extended, along with `data-*` parsing beyond
  `data-i` and `hidden`.
- **`check_stubs` failed: `MapStub.setFilter()`** — the gate that exists exactly
  for this, catching the app calling something the harness cannot model. 20 map
  calls now covered.
- **Every dashed swatch rendered hollow.** `background: transparent` inline is a
  *shorthand* and resets `background-image` — the dash pattern — so the legend
  showed no colour for precisely the disciplines it exists to explain.
  `background-color` instead. Verified by computed style, per row:
  hiking `rgb(124,179,66)`, equestrian `rgb(142,107,181)`, snowmobile
  `rgb(79,179,201)`, NFS `rgb(201,138,46)`.

---

## Take 66 — 2026-08-22 — Release notes in the repo, and a trailhead that names itself

### "I still see the fold portion"

He was reading **"Install from this page on the Fold"** two takes after I changed
it. The release notes were **inline in the workflow YAML** — the one file the
seed cannot update — so they were frozen at whatever take he last pasted. Exactly
the failure take 55 was supposed to prevent, in the one place I did not move.

Notes now live in **`ci/RELEASE.md`**, read with `--notes-file`. In the repo,
seeded like everything else. Landmine 96.

### A trailhead you had to tap to identify

"M-33 Bull Gap Trailhead is not labeled so I'm sure there's others."

It is **740 ft across 3 edges** — about 90 px at riding zoom — and its name is 23
characters. No line label of any size fits, so MapLibre drew nothing, at every
zoom, forever. `line-center` did not help: it still fits text along the line.

Short named strokes now get a **point** at their midpoint and a wrapping label
(`text-max-width: 9`). At Bull Gap that turned up eight names that had never been
drawn: *M-33 Bull Gap Trailhead, 4523, Shaw Lake Road, Shaw Lake Drive, Center
Drive, Hilda Lane, H57-12, MAT.*

### Non-ORV routes were all one grey

A hiking trail and a snowmobile route looked identical, and both looked like
"some line". Coloured by use, still dashed because dashed means *not yours to
ride*: **hiking lime `#7CB342`**, equestrian violet, ski/snowmobile cyan, NFS
motorised amber.

### Legibility on satellite

Designated blue brightened to `#2585D8`, and the white casing widened to
`w(3.2, 7.2, 15)` — near-black singletrack on dark canopy is legible only
because of that halo, which is what "dirtbike trails are hard to see" was about.

**I broke the app mid-take**: `strokeLen(pts)` where `pts` was not in scope at
either call site — the geometry comes from `walk()`. The app caught it and
rendered the fatal screen, so there was no console error; the smoke harness said
`map constructed: FAIL` and that is what found it.

---

## Take 65 — 2026-08-22 — Labels a zoom earlier, and stop designing for one phone

### "Confused by the distance indicator"

A scale bar reading **3000 ft** with **1194 ft** directly beneath it. Two numbers,
same unit, no captions — of course it was confusing. The lower one now reads
**"1194 ft elevation"**.

### Labels started too late

Measured against the scale bar rather than guessed:

| zoom | scale | trail names | road names |
|---|---|---|---|
| 12 | 3000 ft | **0** | **0** |
| 12.5 | 3000 ft | 5 | 0 |
| 13 | 2000 ft | 6 | 6 |

His screenshot exactly: at 3000 ft, nothing. Minzooms dropped a full level —
trail 12.5 → 11.4, road 12.8 → 12.0, forest road 13.4 → 12.4, show-only
13.8 → 13.0. Now 4 trail names at z11.5 and 15 road names at z12.

### One phone is not a device target

The harness ran at 411x960 — the Fold cover screen, which is unusually narrow —
and the default is now a mid-size Android (412x915). Layout is checked across
**four sizes**: 360x800, 412x915, 430x932, and the Fold. A control that fits at
430 px and slides off at 360 px is broken for half the people who might use this.

**The new check failed on all four immediately**, flagging `c-labels` off-screen
— including the Fold, where it demonstrably works. A chip inside a horizontally
scrolling strip is not off-screen, it is *scrolled*: reaching it is one swipe.
Only vertical overflow strands a control. Landmine 54 for the ninth time, caught
because "it fails on the device that works" is not a believable result.

Negative-controlled by pushing the map-detail button to `top: 2000px` — all four
sizes then report `c-base (vertical)`.

---

## Take 64 — 2026-08-22 — Two false failures, and a duplicate I will not paper over

Field report: **PASS 41 · FAIL 2**. Both failures were my checks, not the map.

- **`trails 0 features`** — the check measured whatever viewport Jacob had left
  the map in. He was parked over Brainard Springs, where there genuinely is no
  designated trail. Now an info line, not an assertion; `trail-names` jumps to a
  known site and is the real check.
- **`labels 0`** — queried in the same tick as its own `jumpTo`. Symbols are
  placed asynchronously, which is landmine 87 and was already fixed for
  `stLabels`; this second copy still had it. Now informational, with a pointer to
  the check that waits.

### The doubled lines

"Some paths don't match the road properly." He is right: **5,390 spans carry more
than one edge**, 1,957 of them `fsroad + track` — the same physical road from two
sources, a few metres apart, drawn as two jagged parallel lines. `conflate.py`
dedupes USFS against DNR and nothing deduped OSM against either.

I tried to drop the OSM copies. At a 45 m tolerance that removed **558 miles — a
quarter of the network** — and connectivity fell 99.7% → 97.4%. Swept it:

| tolerance | dropped | miles |
|---|---|---|
| 45 m, ±1 cell, 72% | 539 ways | 558 |
| 22 m, ±1 cell, 85% | 389 ways | 452 |
| **17 m, no neighbours, 85%** | **14 ways** | **~5** |

Shipped the conservative one: 2,241 mi, 99.7% routable — unchanged from before.

**It barely dents the doubling, and that is the finding.** The duplicates are
real, but deleting them costs connectivity because the two sources have different
topology — the OSM way bridges gaps the agency geometry leaves. The correct fix
is to keep both for routing and draw only one, which needs a flag through
`emit_graph`'s packed edge format. That is a deliberate change, not something to
bodge at the end of a take. **A57 open.**

### Also

Designated trail widened and two-track dimmed to `#9C7343`, so the ORV network
reads first — "it's really hard to see the ORV trails". And the release notes no
longer say "on the Fold": this should install on any Android 8+ device, and it
has never been tested in tablet mode.

---

## Take 63 — 2026-08-22 — Relief hidden, not faded

Jacob asked to confirm relief is off at open. It already was, as of take 62 —
verified by measurement rather than assertion: hillshade opacity 0, satellite
off, Labels the only chip on, plain sand map with blue trail, brown two-track,
grey roads and labels drawn.

But "opacity 0" is the wrong way to switch a raster layer off. **The tiles are
still uploaded and drawn every frame** — real GPU work for something invisible,
and relief is off by *default*, so that cost was being paid on every frame by
every user by default. Battery is the one thing about this app still unmeasured
(A18), which makes free GPU work worth removing.

`visibility: none` now, in `setBasemap`.

**And the toggle broke, which is the part worth recording.** The Relief chip has
its own handler that set opacity directly and never touched visibility — so
`setBasemap` hid the layer and the chip only faded it. Turning relief ON did
nothing at all: `visibility=none, opacity=0.42`. Two places controlling one
thing, changed in one place.

Both agree now. All four states measured:

| state | visibility | opacity |
|---|---|---|
| open | none | — |
| relief on | visible | 0.42 |
| satellite + relief | visible | 0.16 |
| relief off | none | — |

---

## Take 62 — 2026-08-22 — Opening state, and the road question answered with data

### "Did you fix this for the other roads as well?"

Checked rather than asserted. Across the whole graph:

| class | edges | road-named | drawn |
|---|---|---|---|
| track | 7,085 | 534 | warm brown — RIDE |
| fsroad | 4,494 | 4 | grey-tan — ROAD |
| minor | 4,134 | 3,398 | grey — ROAD |
| paved | 898 | 808 | dark grey — ROAD |
| trail50 / mccct / moto24 / route72 / fstrail | 3,211 | **0** | trail colours |

**No designated trail carries a road name, and all 9,526 road edges are grey
family.** The distinction holds everywhere, not just at Wagner Lake.

The 534 road-named tracks are the interesting case, and they are correct:
*Bull Gap Road, Keeley Road, River Loop Road, Stoney Ridge Road* — 90 distinct
names that are seasonal two-track in fact. Jacob's own words: "many roads up here
lead to trails." A road name does not mean maintained, and the source classifies
these as vehicular trail.

### Opening state

Only **Labels** is on now. Relief was on in the markup and is off. Basemap opens
on **Map** — satellite is something you choose, not something you land in.

### The map-detail button moved

Out of the horizontally scrolling chip strip, to a floating tile at top-left
**under the scale and elevation**, where every off-road app puts it. Orange when
satellite is active.

**It rendered at 0,0 first, and the cause is worth recording.** The CSS was
correct and the DOM was correct — but `setBasemap()` runs at load and rewrote
`className` to `'chip'`, discarding the positioning class entirely. Computed
style said `position: static`. I had replaced one of the two assignment sites and
missed the other because it was indented two spaces, not four — the same
indentation trap as landmines 65 and 75.

Asking the browser for the computed style found it in one step, after reading the
source twice had not.

---

## Take 61 — 2026-08-22 — Three tiers, not two

Jacob on take 59/60: "trails have color, but the trail color also bleeds into the
main roads like E Wagner. E Wagner is brown and the trails that run off it is
also brown."

His example proved the point better than he knew. In the data:

| name | class | drawn as |
|---|---|---|
| East Wagner Lake Road | minor | grey |
| **E. Wagner Lake Rd** | **fsroad** | **brown** |

The *same road*, split in the source between the county-maintained part and a
Forest Service segment. Take 58 painted `fsroad` and `track` the same brown, so
half of one road looked like trail.

They are not the same thing. **A Forest Service road is something you drive a
truck down; a two-track is something you ride.** Three tiers now:

- designated ORV line — green / blue / black, thickest, white casing
- **two-track** — warm brown `#A9702F` with its own casing
- **forest road** — muted grey-tan `#8A7C66`, thin, no casing
- paved and county road — grey

**The two-track then disappeared entirely**, and the reason is worth recording:
it shares the `net` source with designated trail, so it inherited the casing
tuned for a 3.2 px trail line. A 1.6 px brown line under a 6 px white halo reads
as a *cream* line. Two-track now has its own narrower casing and a slightly
wider stroke. In view at Wagner Lake: 18 designated · 37 two-track · 19 forest
road · 25 road, and all four are distinguishable.

### Attribution was covering a button

MapLibre's compact attribution renders **expanded** on first paint, and on a
411 px screen that bar lies across the chip strip. Collapsed on load and on idle;
the (i) still opens it, and the credits are in About too. 24 px wide now.

---

## Take 60 — 2026-08-22 — Why the rerun worked, and the trap under it

Jacob: "I reran the workflow manually and it did work, so that's weird."

Not weird — the **cache**. CI caches `aoi.json`, and `fetch_osm` returns
immediately when that file exists. His first run hit an Overpass outage, fell
back to TIGER, and failed the region check. The rerun restored a **good OSM
`aoi.json` from an earlier successful run**, so TIGER never ran and the bad data
never appeared. The cache was working in his favour.

But the same mechanism is a trap. If a TIGER-derived `aoi.json` is ever cached,
`fetch_osm` skips it forever: the region would be pinned to the road-only
fallback, with no water layer and none of the OSM path classes, and **nothing
would ever retry**. A single outage would silently degrade every future build.

`aoi.json` written by the fallback now carries `"source": "tiger"`, and
`fetch_osm` retries OSM when it sees that marker rather than settling. Verified
against the real code:

```
plain cache      -> osm: aoi.json present, skipping fetch
tiger-marked     -> osm: cached aoi.json came from the TIGER fallback —
                    retrying OSM before settling for it again
                    osm: overpass-api.de HTTPError 503
                    -> rebuilt from TIGER, clipped, 4556 elements
```

Overpass was genuinely down while testing, which made control 2 an end-to-end
proof rather than a simulation.

---

## Take 59 — 2026-08-22 — The gate refused my own bundle, correctly

CI, on the take-58 seed:

```
FAIL bundle neml-bullgap UNUSABLE: graph.json is not this region:
  579/18420 nodes outside bbox [-84.3, 44.42, -83.9, 44.72]
  (data spans -84.37,44.16 to -83.87,44.86)
```

Overpass was down again, so the TIGER fallback from take 56 ran — and my filter
there was wrong. It kept a **whole way** if any single point fell near the
region, so county roads trailed off to the county line. 44.16 to 44.86 against a
44.42-44.72 region: eighteen miles of overhang in each direction.

**Filter replaced with a clip.** Each run of consecutive in-box points becomes
its own way; a road that leaves the region and returns becomes two. Measured with
the gate's own tolerance (pad 0.05, limit 2%):

| | outside | verdict |
|---|---|---|
| CI, before | 579/18420 = **3.14%** | refused |
| TIGER, clipped | 2/18272 = **0.01%** | passes |
| OSM path, unchanged | 13/12177 = 0.11% | passes |

Reproduced the failure locally first by pointing every mirror at an invalid host
— the span came back 44.16-44.86 exactly as CI saw it — then fixed, then
re-measured both paths.

**The check that caught this was written at take 11** and has sat green ever
since. It exists because a bundle built for one region and shipped as another
would put a rider on the wrong map, and it refused a bundle I had just built and
would otherwise have shipped.

One correction to my own reporting mid-fix: I measured containment against the
*strict* bbox and reported 2,566 nodes outside, which looked worse than the
original failure. The gate allows ±0.05 and 2%; measured its way, it is 2.
The check was right and my probe was too strict.

---

## Take 58 — 2026-08-22 — Half the network was styled as "not for you"

Jacob: "a lot of trail colors are missing. Alot of trails I'd ride with my
dirtbike have no color." His two place cards proved the *data* was right —
"M-33 Bull Gap Trailhead · USFS · LEGAL · Moto open" and "Ogemaw Hills Route ·
DNR · LEGAL". The trails were there and known legal. They just did not look it.

### 1,169 of 2,246 miles

| class | miles | was styled |
|---|---|---|
| track (forest two-track, TIGER 4WD) | 784 | thin tan **dashes** |
| fsroad (USFS road) | 384 | thin grey **dashes** |

**52% of the network** — and it is exactly what a dirt bike rides. Drawn as grey
dashes it reads as "not for you". Both are now solid warm tan with a white
casing, thinner than designated trail so the hierarchy still reads: designated
ORV line in green/blue/black, ridable dirt in tan, actual roads muted grey.

### Routes were sending him down the highway

He also asked for routes to say whether they are fully approved. Adding that
composition line immediately exposed something worse than a display gap:

```
Fastest          9.3 mi   no designated trail · 0.8 forest road · 8.5 PAVED
Easiest          8.4 mi   no designated trail · 2.3 forest road · 6.1 paved
Pavement soonest 8.7 mi   no designated trail · 0.7 forest road · 7.9 paved
```

Every profile optimised for speed or ease, and pavement wins both. Return Home
was handing a man on a dirt bike eight and a half miles of highway.

**"Most trail" is now the first profile:** designated ORV line costs 0.55x,
forest road 1.3x, pavement 8x — expensive but never forbidden, because crossing
M-33 is inevitable and he said so. Result:

```
Most trail      11.1 mi   93% designated · 10.3 trail · 0.5 forest road · 0.3 paved
```

Two miles longer and it is the ride he wants. Six profiles now, and every card
carries **all designated trail / N% designated / no designated trail** so the
approval status is visible before committing.

**Not done:** an emergency profile that routes over non-ORV line. Pavement is
already never forbidden and "Pavement soonest" is the get-out — routing anyone
onto a hiking trail needs more thought than a cost multiplier.

---

## Take 57 — 2026-08-22 — CI built it, and the field report found three label bugs

**Take 56 was built by GitHub Actions, installed from a release, and passed
43/0 on the Fold.** The chain works: push, build, release, install. No more APKs
by hand.

The self-test then reported something I did not like:
`trail-names: 3 names for 85 trail segments`. My harness had claimed 8 for 66.

### The harness was measuring a screen that does not exist

`render.mjs` ran at **900x1400**; the Fold's cover screen is **411x960** — under
a third of the area. MapLibre places symbols against the viewport it has, so
every label-density figure I have quoted was optimistic. Set to 411x960 at dpr
2.625, the harness immediately reproduced the device: **4 names for 86
segments**, against Jacob's 3 for 85.

Swept the parameters at the real size rather than guessing: 75/100/pad2 → 4,
85/60/pad1 → 5, and with slightly smaller text → **6**. Past that it flattens.

### Then two bugs the sweep exposed

**Show-only labels outranked ridable ones.** `lbl-show` sat before `lbl-trail`,
and MapLibre gives earlier symbol layers collision priority — so a path Jacob may
NOT ride was named while the loop under his wheels was not. Moved after.

**Satellite hid every trail name.** `LBL` was forced to `none` in Satellite mode,
a rule from before labels had a dark halo, when dark-on-light was unreadable over
jack pine. They are white-on-halo since take 46 and survive it fine. Worse,
`lbl-show` was not in `LBL` — so on satellite the *only* names left were the
trails he may not ride: "Shore To Shore Trail" labelled, his own trail not.

Measured after: **Map 3 · Satellite 3 · Hybrid 3** ridable names, where Satellite
was 0.

---

## Take 56 — 2026-08-22 — checkout lands on the commit that triggered the run

```
bash: ci/bundle.sh: No such file or directory
```

`actions/checkout@v4` checks out **the commit that triggered the run**, not the
tip of the branch. The seed job pushes a new commit; every downstream job then
checked out the *old* SHA, where `ci/bundle.sh` genuinely does not exist. I had
assumed checkout follows the branch and never verified it.

Both downstream checkouts now pin `ref: ${{ github.ref_name }}`.

### The check I wrote for it passed vacuously

`check_checkout_ref()` reported green — because it scans `ci/` and
`.github/workflows/`, and **the generated `apex.yml` was in neither**. It is
written to the outputs directory for Jacob to paste; my repo had an empty
`.github/workflows/`. So every workflow check has been validating `ci/build.yml`,
which has no seed job, and reporting on a file nobody runs.

`tools/mkapex.py` now writes the repo copy as well. The gate sees 2 workflow
files instead of 1, and the negative control fires properly:
*"apex.yml:bundle needs a job that pushes, but checks out the triggering
commit."*

Landmine 54 for the ninth time, and the most expensive variant yet: not a check
that was wrong, a check that had **nothing to look at** and said so as though it
had looked.

### On the cadence

Six CI failures in six runs. Every one real, every one a property of the runner
invisible from inside my container — but the pattern is that I have been
*learning the platform by trial* rather than reading it. The honest fix is what I
did here: after finding the fault, ask what else in the same family I have
assumed, and gate it. Checkout semantics, per-job runners, per-job dependency
installs, workflow validity, absolute paths, vendored assets — six gate checks
now, all negative-controlled.

---

## Take 56b — 2026-08-22 — A volunteer service on the critical path

*Shipped in the same take as 56 above and written as a second entry. Relabelled
56b at take 82: the take number is the seal, and two entries claiming one seal
makes the history unreadable. Nothing was renumbered.*

CI got further than ever — the workflow shim worked, the seed pushed, the bundle
job started — and then every Overpass mirror 503'd. `graph.py` correctly refused
to ship a bundle whose Return Home cannot reach a road, so a build that fetched
all 1,027 trails perfectly produced nothing.

The refusal was right. The dependency was wrong. **OSM is volunteer-run and it
was the single point of failure for the entire build.**

### Census TIGER roads as the fallback

TIGER is a US government CDN: no rate limit, no outage history worth planning
around, and I already parse its shapefiles for addresses and boundaries. It also
carries **MTFCC S1500, "Vehicular Trail (4WD)"** — 384 in Oscoda County alone,
which is precisely the two-track this app exists for.

`tiger_roads()` writes Overpass's element shape, so `graph.py` needs no special
case. OSM stays primary; TIGER is used only when every mirror fails.

Exercised by pointing every mirror at an invalid host:

```
osm: every mirror failed (URLError) — falling back to Census TIGER roads
tiger: 4100 road ways from 15708 features
  residential 3099 · service 567 · track 414 · primary 20
noded: 18619 nodes, 35115 edges
network 2856 mi total, 2850 mi (99.8%) routable together
```

A complete, routable graph with no OSM at all. Water is still skipped — that
layer is genuinely OSM-only — so the bundle reports PARTIAL and the app says so,
which is the designed behaviour.

### Also fixed: checkout landed on the wrong commit

`bash: ci/bundle.sh: No such file or directory`. `actions/checkout` defaults to
the commit that **triggered** the run; the seed job pushes a newer one, so every
downstream job was checking out a tree from before the seed. `ref:
${{ github.ref_name }}` on both. Landmine 85.

**My check for it passed vacuously** — `ci/build.yml` has no seed job, and the
generated `apex.yml` was not in the repo at all, so there was no workflow with a
pushing job to check. `mkapex.py` now writes the repo copy too, and the negative
control fails correctly.

---

## Take 55 — 2026-08-22 — The gate deadlocked the fix it was gating

My own take-54 check failed the seed job:

```
FAIL a job installs no Python deps it needs — each job is a fresh runner:
  apex.yml:seed runs python without ['pyyaml']
  apex.yml:bundle runs python without ['pyyaml']
  apex.yml:apk runs python without ['pillow']
```

The check was right about all three. But it exposed a design fault I had built in
and not noticed: **`gate.py` validates the workflow file, and the workflow file
is one Jacob pasted by hand that the seed job cannot update.** So a workflow one
version behind fails the gate, the gate fails the seed, and the seed is the thing
carrying the fix. A deadlock, with the fix on the wrong side of it.

Three changes:

**1. The workflow is a thin shim now.** Everything that can change moved into
`ci/bundle.sh` and `ci/apk.sh`, which live in the repo and *are* updated by
seeding. The bundle job went from eleven steps to six; the apk job from ten to
seven. Dependency lists, vendoring, render, gate — all in the scripts. The pasted
file should now almost never need re-pasting.

**2. `APEX_GATE_SEED=1`** skips workflow-file checks in the seed job. The
workflow there is the user's, not part of the seed, and gating the seed against
it is the deadlock. The seed still runs every other check.

**3. The seed job installs pyyaml**, because it runs `gate.py`.

Two knock-ons the move required: `check_ci_deps()` now follows `bash ci/*.sh`
into the script, or the deps look absent one level down; and every check that
greps "the workflow" for a command — CSP worker vendoring, `tools/android.py`,
the unpkg host — now reads `ci/*.sh` too, since that is where those commands went.

Simulated: a deliberately stale pasted workflow, a fresh seed zip, seed mode
gate. **51 files unpacked, GATE PASSED, no block.**

---

## Take 54 — 2026-08-21 — Each job is a fresh runner

The bundle job **passed** on the runner — ingest, graph, terrain, glyphs,
imagery, bundle, both smokes, render, gate. The first complete pipeline run on a
machine that is not mine.

Then the apk job died:

```
File "tools/icon.py", line 19, in <module>
    from PIL import Image, ImageDraw
ModuleNotFoundError: No module named 'PIL'
```

**Every job is a fresh runner.** The bundle job's `pip install pillow numpy scipy
pyyaml` does nothing for the apk job, which had no Python dependencies installed
at all. Added.

**My own check from take 53 missed it**, and that is the part worth recording. It
searched the whole workflow file for the package name, found `pillow` in the
bundle job's install line, and passed. Dependencies are **per job**.

`check_ci_deps()` is rewritten to work per job and to resolve imports
**transitively through local modules** — `android.py` imports `icon`, and
`icon.py` imports `PIL`, a chain no direct-import scan would have found. It also
understands that `tools/pipeline.py` pulls in every tool. Negative-controlled by
removing pillow from the apk job alone.

### Pages

`Failed to create deployment (status: 404)` — Pages was not enabled. Jacob has
since set Source to GitHub Actions. The job is `continue-on-error: true`, so it
never blocked the APK; it just looked alarming.

### Four environment faults, four CI runs

A font from my sandbox, a module path from my sandbox, a package that was already
installed here, and now a package installed in the wrong job. Every one invisible
from inside the machine that had it. The gate now covers paths, per-job
dependencies with transitive resolution, and vendored assets.

---

## Take 53 — 2026-08-21 — Stop finding these one CI run at a time

The runner hit the same font error, because the fix was in my take-52 seed and
Jacob's repo was still on take 51. Rather than just say "upload the new zip", I
went looking for what would break NEXT.

**`gate.py` imports `yaml`; CI installs `pillow numpy scipy`.** On the runner the
import would have failed, the workflow validator would have **silently
downgraded to a note**, and the check that exists specifically to catch invalid
workflows would have been absent on the one machine where a workflow is actually
parsed. It would have passed, greenly, doing nothing.

`pyyaml` added to the install line, and **`check_ci_deps()`** now walks every
`import` in `tools/`, subtracts the standard library and local modules, and fails
if the workflow does not install the rest. Negative-controlled by removing pyyaml
from the line.

That is three environment faults in three CI runs — a font from my sandbox, a
path from my sandbox, and a package I never had to install because it was already
there. All the same shape: **the build depended on my machine and I could not see
it from inside my machine.** There are now three gate checks in that family:
absolute paths, CI dependencies, and vendored assets.

---

## Take 52 — 2026-08-21 — The typeface only existed in my sandbox

The repo seeded, the workflow ran, and the pipeline got six steps deep on a real
GitHub runner — ingest 1,027 features, conflation, 20,133 edges, 110 DEM tiles,
98k ft of climb — then died:

```
OSError: cannot open resource
  tools/glyphs.py, ImageFont.truetype(font_path, SIZE)
```

`glyphs.py` loaded its typeface from
`/mnt/skills/examples/canvas-design/canvas-fonts/NationalPark-Bold.ttf` — a path
that exists **only inside my container**. Same fault as `emit_graph.py` importing
`/home/claude/pack.py` at take 45, and the same reasoning as the logo at take 30:
**a typeface is a source asset, not something to borrow from whatever happens to
be installed.**

`assets/fonts/NationalPark-Bold.ttf` is vendored (77 KB) and `glyphs.py` resolves
it relative to the repo. Identical output — 107 glyphs, 45.9 KB pbf — so no map
changes.

**`check_absolute_paths()`** now fails the gate on any tool referencing
`/mnt`, `/home`, `/opt`, `/usr` or `/Users`, excepting the publish directory.
Negative-controlled by putting the old path back.

Full pipeline clean in 105 s afterwards, all five smoke modes and the render
green.

### What the first real CI run taught

Nothing local could have caught this. Every check ran in the container that had
the font. The runner is the first machine that did not — and it found the last
two hand-dependencies in four minutes. Landmine 81 is really landmine 32
restated: **if a build needs it, it belongs in the repo.**

---

## Take 51 — 2026-08-21 — The seeder tried to overwrite the workflow running it

First real CI run. The seed job worked — unpacked the zip, flattened the nested
shape, gated clean at take 49, committed 48 files — and died on the last line:

```
! [remote rejected] main -> main (refusing to allow a GitHub App to create or
  update workflow .github/workflows/apex.yml without `workflows` permission)
```

Landmine 46, from the other side. I had recorded that GITHUB_TOKEN cannot write
`.github/workflows` and built the whole one-file installer around it — then
handed Jacob a zip containing `.github/workflows/`, so the seeder tried to
overwrite **the workflow that was running it**.

Nothing was pushed. The repo stayed clean, which is what the gate-before-commit
ordering is for.

Two faults, not one:

1. **The seed copied `.github/`.** It now deletes that directory from the
   unpacked tree before copying. Whatever the user pasted is theirs and is never
   touched.
2. **`build.yml` would have been a second workflow running the same build.**
   `apex.yml` already contains every job it has, plus seed — so every push would
   have built twice.

**The canonical build definition moved to `ci/build.yml`**, where GitHub does not
execute it. `tools/mkapex.py` generates `.github/workflows/apex.yml` from it, and
that generated file is the only workflow in the repo. `scan_hosts()` and the
workflow validator both read `ci/` as well, or a declared host looks unreached.

Simulated against a repo with a pasted `apex.yml`: the file survived byte for
byte, no `build.yml` appeared, and 47 files landed.

---

## Take 50 — 2026-08-21 — CI had never been valid

GitHub rejected the workflow: *"(Line: 49, Col: 1): 'concurrency' is already
defined."* Tracing it found something worse than a bad splice.

**`build.yml` has carried TWO `concurrency:` blocks since take 20.** GitHub
rejects such a file outright — which means **the CI workflow has never been
valid and could never have run.** Every check we have was local; the one thing
that would have caught it is the one thing we never did, which is let GitHub
parse it.

It survived thirty takes because **PyYAML's `safe_load` silently keeps the last
of duplicate keys**. `yaml.safe_load(...)` returned a clean dict, the gate said
fine, and I validated the generated `apex.yml` the same way — so my validator
passed a file GitHub refuses.

### Fixes

- **The duplicate is gone**, `cancel-in-progress: true` kept.
- **`check_workflow_yaml()`** loads every workflow with a constructor that
  *raises* on a duplicate key, and requires a `jobs` block. Negative-controlled.
- **`tools/mkapex.py`** generates `apex.yml` from `build.yml` instead of my
  splicing it by hand each time — takes the header verbatim so a second
  `concurrency` cannot appear, injects the seed job, asserts the job list and
  the `needs`, and strict-validates before writing.

My splice had also mangled the header: the seed job ended up nested under
build.yml's own `jobs:` with the whole build header duplicated above it. Hand
splicing was the wrong technique; generation with assertions is the right one.

**Landmine 79.** A permissive parser is not a validator. `safe_load` answers
"can I read this", not "will the consumer accept it" — and the gap between those
two questions hid an invalid workflow for thirty takes.

---

## Take 49 — 2026-08-21 — Two workflow bugs, one of them mine

Jacob pasted `apex.yml` back into the chat. Auditing it instead of glancing at
it found two failures, both of which would have hit on his first CI run.

### The release would have published with no APK

`${{ steps.pkg.outputs.apk }}` appeared twice in the apk job — as the
upload-artifact path and as the asset argument to `gh release create`. **No step
declared `id: pkg`.** The step was `id: take` and only ever wrote `take`.

GitHub does not error on an unresolved step reference; it substitutes an **empty
string**. So `upload-artifact` would get no path and the release would be created
with no asset — and nothing in the log would say why. Pre-existing in
`build.yml`, and it survived because CI has never actually run this repo.

Fixed: the step is `id: pkg`, writes `apk=` to `$GITHUB_OUTPUT`, and the file is
named `apex-orv-take-N.apk` — it had still been `apex-offroad-` since the rename
at take 38.

### My generator dropped the env block

Building `apex.yml` I sliced `build.yml` at `jobs:` and prepended a header. That
threw away the **top-level `env:`** — `APEX_REGION` and `TILES_KEY`. With
`$APEX_REGION` empty the bundle job dies on `cp bundles//manifest.json`.

The generator now preserves everything between `name:` and `jobs:` verbatim and
**asserts** that no top-level key was lost and that `env` survived. Same lesson
as landmine 65: a transformation that silently drops content is worse than one
that fails.

### The durable fix

`check_workflow_refs()` — every `steps.X.outputs.Y` must correspond to a step
declaring `id: X`. Negative-controlled: renaming `id: pkg` fails the gate.

It false-positived first, of course: the regex required `id:` at line start and
missed the `- id: deploy` form, reporting a broken reference on a healthy
workflow. And its second check — "does the step write that output" — is
unknowable for third-party actions, which declare their own (`deploy-pages`
emits `page_url`). Dropped that half; kept the half that is both checkable and
the half that silently broke. Landmine 54, ninth time.

---

## Take 49b — 2026-08-21 — Make the wrong choice work, and the failure legible

*Second entry under take 49, relabelled 49b at take 82 for the same reason.*

Jacob got the repo created, pasted a workflow, uploaded a zip, and got a Node
error that told him nothing. Three separate causes, all mine.

1. **He pasted an older `build.yml`**, not the `apex.yml` I had just shipped.
   That old copy has the `steps.pkg.outputs.apk` bug — a step with `id: take`
   whose output is read as `steps.pkg.outputs.apk`, which resolves to empty, so
   `upload-artifact` and `gh release create` both get a blank path. Already
   fixed in the repo; the stale paste reintroduced it.

2. **He uploaded `apex-orv-github-repo.zip`**, not `apex-seed.zip`. Entirely
   reasonable — it is the one whose name says "repo". The seed job looked for
   one filename, found nothing, said "going straight to the build", and the
   build then failed deep inside Node with no reference to the real problem.

3. **Nothing checked that the repo contained the project** before spending ten
   minutes trying to build it.

### Fixes

**The seed accepts either zip and flattens the nested one.**
`apex-orv-github-repo.zip` nests everything under `apex-orv/`; the plain seed
does not. Both now land correctly at the root. A reasonable wrong choice should
work, not punish.

**The bundle job checks for source first** — `BUILD`, `tools/pipeline.py`,
`src/app.html`, `regions.json`, `package.json` — and if any are missing prints
what is actually at the root and names the file to upload. It fails in seconds
instead of two hundred lines into npm.

Simulated all three cases against real directories by extracting the scripts
verbatim from `apex.yml`: correct zip → take 49 unpacked and gated; wrong zip →
flattened, unpacked, gated; empty repo → explicit error naming the missing files
and the right zip.

**Landmine 78.** An error a user cannot act on is not an error message. The Node
stack trace was technically accurate and completely useless: the actual fault was
four steps earlier and in a different language.

---

## Take 48 — 2026-08-21 — One file, one zip, one button

Jacob, trying to get the repo onto GitHub from a phone: "There has got to be an
easier way. I don't want to be creating and editing files, I want to drop it
into my GitHub." He was right and I had over-complicated it.

The two constraints are real — GitHub's mobile web UI cannot create folders from
an upload, and `GITHUB_TOKEN` cannot write `.github/workflows` (landmines 42,
46) — but the conclusion I drew from them was wrong. I had him pasting **two**
workflow files and cutting a release.

**The installer does not need to WRITE the build. It can BE the build.**
`apex.yml` merges the seed job in front of bundle/pages/apk. So:

1. Actions → paste `apex.yml` (one file — the Actions tab prefills the path)
2. Add file → Upload files → drop `apex-seed.zip` at the root (one file, no
   structure required, which is exactly what mobile CAN do)
3. Run

The seed job unzips, gates **before** committing so a bad seed cannot
half-populate the repo, pushes, and the build runs on in the same workflow. Every
run afterwards skips straight past it. No release, no second file, no folders.

### The simulation earned its keep immediately

Running the seed script verbatim against an empty directory holding only the zip
showed `GATE FAILED (3)`: the gate read the hardcoded filename
`.github/workflows/build.yml`, found nothing in the single-file layout, and
failed three checks on a perfectly good seed — which would have blocked Jacob's
very first run. It now concatenates **every** workflow file it finds. Both
layouts gate green.

I would not have caught that by reasoning about it; I caught it by running the
job's own script against an empty folder.

---

## Take 47 — 2026-08-21 — Coverage reconciled against the agencies, exactly

Before Jacob rides it for real: prove nothing ORV is missing, and that nothing
ridable is drawn as un-ridable.

### State — exact match

DNR layer 19 is the master layer, one row per trail with a flag for every use.
Everything it flags ORV Route / ATV Trail / Motorcycle in this region: **199**.
Our ingest, reconciled:

| ours | count |
|---|---|
| route72 | 14 |
| trail50 | 148 |
| moto24 | 25 |
| closed (temporarily) | 12 |
| **total** | **199** |

**199 = 199.** And the 12 we reclassify as closed match layer 19's own
`OpenClosedStatusORV = Temporarily Closed` count exactly — 187 open, 12 closed.
MCCCT (47) is a separate designation and is additional.

### Federal — exact match

MVUM roads **366 = 342 ridable + 24** with no motorcycle or ATV legality, which
is precisely why those 24 are `fsclosed` and unroutable. MVUM trails **46**, all
46 motorcycle-legal, all ingested.

### The real find: multi-use trail drawn twice

A trail can be designated for several uses at once and the DNR publishes it in
every matching layer — **"LP 9" is a motorcycle trail AND a hiking trail AND an
equestrian trail**. Drawn naively that put a grey dashed *"not ridable"* line
directly on top of a trail Jacob may legally ride.

That is worse than useless: it tells him to stay off something he is allowed on.
**70 show-only copies of ridable trails are now dropped — the ridable
designation wins.** Show-only went 767 → 697. Overlap between routing classes and
show-only classes remains NONE.

---

## Take 46 — 2026-08-21 — Difficulty colours, and the map gets the screen

Jacob, with onX and AllTrails screenshots: "feels like a barebones test / cheap
clone." Fair. Two things were doing that.

### The trails were coloured by taxonomy, not difficulty

Green for ORV routes, black for ATV trails, orange for motorcycle, purple for
MCCCT — a legend of *which agency drew the line*. What a rider needs is what the
line will DO to them, which is why every trail map on earth uses green / blue /
black. Now:

| tier | classes | colour |
|---|---|---|
| easy | route72 (72" ORV route) | green `#2F7D4F` |
| moderate | trail50, fstrail | blue `#1F6FB2` |
| difficult | moto24, mccct | near-black `#17150F` |

Roads dropped back to muted greys so trail reads first.

### The white casing was switched off on the default map

`casing` — the white halo under every trail — existed but was bound to satellite
mode, so on the sand basemap trails had no separation from the road network at
all. It is unconditional now, and it is the single change that makes a coloured
network legible over jack pine. Verified: casing paints 126 features where
trail50 paints 126.

Labels went white-on-dark-halo and up 1–2 px. Dark-on-light survives sand and
dies on satellite; white-on-halo survives both.

### The first thing on screen was a build console

A title bar with `NET —` and `GRAPH —` badges, and a `Frames/s` stat cell. None
of that is navigation. The bar is hidden (kept in the DOM so every diagnostic
that writes to it still works, and the self-test still reads it), `Frames/s`
became **Elevation**, and the map now owns the top of the screen.

Added what was missing instead: a **scale bar** and a floating **elevation
readout**, the way onX places them. Without a scale a rider cannot tell whether a
gap is 200 yards or two miles — which is exactly the judgement that decides
whether to push through.

### Two probes lied to me before the map did

- Querying `moto24`, `mccct`, `route72` at Bull Gap returned **0 painted** and I
  nearly went hunting for a filter bug. They cluster around −84.20, not −84.09;
  jumping onto a real segment showed all four painting fine. Landmine 54.
- Three separate patches silently no-matched on indentation before I stopped
  guessing and printed the bytes with `cat -A`. The asserts caught every one.

---

## Take 45 — 2026-08-21 — Every route in the area, and the guards that keep it honest

Jacob: "ensure no off-road trails are missed, even hiking trails or obscure
ones — I need to know every route available." Rebuilt from the take-44 seed
after the container died, then went looking. **648 → 1,027 routes.**

### The DNR FeatureServer was withholding 36 features

`DNRTrailsOPENDATA/FeatureServer` silently returns FEWER features than
`/MapServer` for an identical query. Measured twice, on two different days, in
both GeoJSON and Esri JSON:

| layer | FeatureServer | MapServer |
|---|---|---|
| ORV Trails | 153 | **159** |
| Motorcycle | 23 | **25** |
| MCCCT | 45 | **47** |
| Hiking | 13 | **24** |
| Skiing | 0 | **10** |
| Snowmobile | 97 | **101** |

`returnCountOnly` reports the MapServer totals from **both** endpoints, so the
data exists on both and the FeatureServer drops it on the way out. **Six ORV
trails and two motorcycle trails were missing from every build for forty takes.**
One word of URL.

The fix that matters more is the guard: `query()` now asks the server how many
features match and prints `!! layer N: server reports X, got Y — Z MISSING`
whenever the payload is short. "Did I get everything?" is not a question to leave
unasked on a map someone navigates by. Landmine 72.

### Everything that exists, including what he may not ride

Ten non-ORV DNR layers (hiking, biking, equestrian, skiing, snowshoe, Iron Belle,
hunter walking, MOU, snowmobile, railtrail) plus the full USFS NFS trail set —
and the OSM classes that were being **fetched and silently dropped**:
`path`, `footway`, `bridleway`, `cycleway`, `raceway` had no entry in graph.py's
CLS map. `service` was not even requested. In jack-pine country a lot of real
connecting two-track is tagged `highway=path`.

Result: routing network **16,440 → 20,133 edges**, 2,114 → **2,246 mi**,
connectivity 99.4% → **99.9%**, plus a **767-route show-only payload** (227 KB).

### The invariant, not another list

Non-ORV routes must never enter the routing graph. The obvious implementation —
maintain `SHOW_ONLY` beside `CLS` and remember to update both — is exactly the
shape of mistake that ships a footpath as a dirt-bike route. So the gate checks
the **built data**, not the source:

> every class in the routing graph must be ridable by some machine or explicitly
> closed, and nothing show-only may also be ridable.

Verified: graph holds `closed fsclosed fsroad fstrail mccct minor moto24 paved
route72 track trail50`; show-only holds `foot horse nfsmoto snow snowmob`;
**overlap NONE**. Negative control: injecting `foot` into the graph's class list
fails the gate with "a rider could be routed onto one".

Tapping a dashed show-only line now says what it is and that routing will never
use it. Seeing a trail and being allowed to ride it stay separate facts.

### Three more, found by the audit and the clean run

- **The APK said Take 44 inside** while BUILD said 45: `www/` was rebuilt before
  the bump and `cap sync` copied it verbatim. The gate compared `src/` to BUILD
  and passed it. It now compares the BUILT stamp in `www/index.html`, negative-
  controlled in all three states. Landmine 75.
- **An empty `aoi.json` built a road-less bundle.** `overpass.osm.ch` answers 200
  with zero elements; the guard checked the file EXISTED. A clean run produced
  **3,621 edges instead of 20,133** — trails only, no roads, silent. Empty is now
  a failure in the fetcher (falls through to the next mirror) and in the graph.
  Landmine 74.
- **My own audit regex matched body text** ("DONE take 9") and reported stale doc
  stamps on a current tree. The gate's own check was right all along.

### Two more failures a fresh container exposed

- **`emit_graph.py` imported `/home/claude/pack.py`** — an absolute path outside
  the repo that only ever worked because a stray copy sat there. A fresh
  container has no such file and the pipeline died at step four. Landmine 32
  wearing an import.
- **Overpass 503'd through two builds.** Mirrors serve the same database, so
  `ingest.py` now tries three in turn. A single volunteer endpoint should not
  stop a map someone rides with.

---

## Take 44 — 2026-08-21 — Trail names, from almost none to eight

Jacob's self-test had been quietly reporting `labels 1 at z13.6` for several
takes and I had read past it. Knowing WHICH trail you are on is the point of a
trail map, so this was a real gap hiding in plain sight.

**The data was never the problem: 100% of trail edges carry a label.** Two
separate causes suppressed them.

**1. Routing edges are too short to host a line label.** The graph is split for
routing — median edge **76 m**, and **76% under the 230 px symbol spacing** — and
each edge was its own GeoJSON feature. MapLibre places line labels along a
feature; a feature shorter than the text cannot carry one. `chainStrokes()` now
walks the graph and joins consecutive edges sharing a label into maximal
strokes: **16,440 edges → 1,240 strokes**, longest 213 points. Label layers read
from those; routing and rendering still use the edges.

**2. `text-max-angle:32` placed literally zero labels.** ORV trails bend far
more than 32 degrees inside the width of a name, and MapLibre rejects such
placements outright. Measured sweep at z14.5 over 29 candidate strokes:

| max-angle | spacing | labels placed |
|---|---|---|
| 32 | 230 | **0** |
| 60 | 230 | 3 |
| 60 | 120 | 4 |
| 85 | 90 | 5 |

Settled on **75 / 100** — most of the gain without text wrapping round hairpins.
`line-center` was tested and is worse (1-5). Two road label layers had the same
too-strict angle and were relaxed with them.

**Result at Bull Gap z14.5: 8 names for 66 trail segments**, reading
*MAT · H57-18*, *Bull Gap Hill Climb · 4276*. Before: zero.

### And my check was wrong before the map was

The new self-test check reported "0 names for 62 segments" while `render.mjs`
reported 8 on the same build. Labels are placed **asynchronously**, and the
self-test jumped and queried in the same tick. Moved into the async chain with a
1.8 s settle. Landmine 54 — verify the check before believing it — for the
seventh time, and the reason render.mjs and the self-test measuring the same
thing is worth the duplication.

---

## Take 43 — 2026-08-21 — Full audit. Two features had been shipping invisibly

A checkpoint audit across everything since take 29. Identity, shipped bytes,
feature presence, negative controls, delivery chain, the clean run PROTOCOL §6b
required, and doc coherence. Five real defects, one of them serious.

### 1. Two features drew nothing, for eight takes

`alt` (dimmed alternates, take 35) and `approach` (dashed off-network legs, take
39) had sources created and fed correct geometry — and **no layer to draw
them**. Both patches anchored on `'route-line'`; the layer is called
`'routeline'`. They silently no-matched.

Every check written for them measured `setData` — the DATA, not the DRAWING —
so take 35 reported "alternate lines drawn: 272" and take 39 reported "two legs,
0.49 and 0.06 mi", both true and both about data nothing rendered. Worse, the
alternates were themselves the *fix* for Jacob's "the line doesn't update"
report, so that fix never actually reached him.

Now: both layers exist and render (**66 alternates, 2 approach legs** measured),
`check_orphan_sources()` fails the gate on any source no layer references,
`render.mjs` asserts `queryRenderedFeatures` per layer, and a dead `pins` source
left over from an earlier design is gone. Landmine 69.

### 2. My own check had a false positive, and I caught it before acting

The orphan-source check first flagged `sat` as a ghost — it is declared with a
ternary (`sat:TILES?{...}:{...}`) which my regex missed. Verified the check
before believing it, for once (landmine 54).

### 3. The clean run — which I owed under §6b — found two more

Three pipeline steps had been added (`context`, `address`, rewritten `imagery`)
with no clean run. Doing one found:
- **An Overpass 503 killed the entire build**, after DNR and USFS had already
  fetched fine. Water is optional and now degrades to PARTIAL; the ROAD network
  is not, and now refuses with a clear message rather than shipping a bundle
  whose Return Home cannot reach a town. Landmine 70.
- **`render.mjs` died at import** on a checkout with no `node_modules`. It says
  "run `npm ci` first" and skips.

The clean run then completed in **14 s warm**, COMPLETE bundle, all five smoke
modes green — and reproduced the missing-layer defect exactly, which is
independent confirmation it shipped.

### 4. My guard didn't land, in the audit written to catch that

The `graph.py` refusal was inserted with two spaces of indent against
module-level code. No assert, so it silently no-matched — landmine 65, in this
audit. Reapplied with an assert and verified.

### 5. Documentation had drifted

Landmine **57** held two different lessons under one number, **62** was the same
lesson written twice, and handoff takes **29** and **37** each appeared twice
(interrupted turns). Deduped: 42 handoff entries, 70 landmines, no gaps, no
duplicates, stamps agree.

**Everything else was clean:** cert continuity, take coherence across BUILD /
src / APK / seed / handoff, all five negative controls biting, seed ⇄ repo
byte-identical, bootstrap simulation exact.

---

## Take 42 — 2026-08-21 — Satellite imagery, 6.5x sharper

Jacob: "I can almost count the pixels. I only use it without the map due to
this." Measured before changing anything: the shipped mosaic was **22.1 m/px**.
A two-track is about one metre wide. He was right to stop using it.

**The pipeline was throwing away most of what it downloaded.** It fetched native
z14 tiles (6.8 m/px, 4864x5119 px) and squashed the whole AOI into a single
1500 px JPEG for size — a 3.2x loss on top of an already-coarse zoom.

**Now it ships real tiles**, so MapLibre fetches only what is on screen. That
bounds MEMORY rather than disk, which is what makes higher zoom possible at all:
a z15 mosaic would be 9728 px and would not fit in a texture, but z15 *tiles*
are fine. Measured at 21.3 KB/tile before committing to a level:

| through | size | m/px | what you can see |
|---|---|---|---|
| z14 | 11 MB | 6.81 | two-tracks |
| **z15** | **45 MB** | **3.40** | **individual trails** |
| z16 | 158 MB | 1.70 | ruts and tree lines |

z15 chosen: **2,008 tiles, 45.2 MB, 3.40 m/px** — 6.5x finer than before, for an
APK that goes 5.2 MB → **51 MB**. That is a fair trade for a sideloaded offline
map, and `imagery_max_zoom` in regions.json makes it per-region if a smaller or
sharper region is ever wanted.

The single-file browser build keeps the 1500 px mosaic as a fallback — it cannot
carry 2,000 files — and the app picks tiles when the bundle has them. Both paths
render-verified.

The self-test now reports ground resolution, so the thing Jacob complained about
is a number in his own report rather than an opinion: `imagery tiles z12-z15 ·
3.40 m/px · 2008 tiles, 45 MB`.

Verified from the shipped APK: 2,008 tiles packaged, extracted, and rendered.

---

## Take 41 — 2026-08-21 — The ride measures itself (A18 Stage 1 instrumentation)

Stage 1 is the standing blocker and only a real ride can close it: battery cost
with the screen held on, and GPS quality under jack pine. Neither is measurable
from a container, and "it felt fine" is not a measurement. So the ride now
measures itself.

**Recorded from the moment ▶ Ride it starts**, entirely locally — battery from
the Capacitor Device plugin (falling back to `navigator.getBattery`), fix timing
from the watch already running:

- fix count and median gap between fixes
- **dropouts** — any gap over 15 s, checked every 20 s, with the worst gap kept
- median horizontal accuracy, which is the canopy question
- battery used, and %/hour with the screen held on

Stopping the ride produces a **ride report** with Copy and Share, and the last
ride rides along in the self-test report — so one share covers both.

### The estimate that would have lied

A first pass reported "37 hours from full" off a 90-minute synthetic sample.
The arithmetic was right and the number was nonsense: **Android reports battery
in 1% steps**, so a ten-minute ride can show 0% or 1% and extrapolate to
anything between "forever" and "two hours". A rate is now quoted only from a
sample that can support one — **20 minutes and at least 2% moved** — and
otherwise the report says *"too short to quote a rate"* rather than going quiet.

Verified both ways in a real browser: an 8-minute ride refuses to quote; a
95-minute ride gives **17.7%/hour → 5.7 hours from full**, with a 40 s dropout
counted and ±9 m median accuracy tracked.

Battery is sampled every third pulse (60 s) while the dropout watch runs every
20 s — the dropout needs to be prompt, the battery does not.

**What this changes:** one ride now closes the parts of A18 that are
measurable. What it cannot close — sunlight legibility, glove operation, the
fold seam — stays open and stays honest.

---

## Take 40 — 2026-08-21 — Loops. The third of plan / ride / improvise

A28 was the honest gap: point-to-point routing cannot express "a ride that ends
where it starts" — the shortest path from a node to itself is nothing.

**Method.** Three waypoints on a circle around the start, routed through in
turn, with already-used edges made six times more expensive so the return leg
does not retrace the outbound. Circumference C = 2*pi*r, so a target of T miles
wants r = T/(2*pi).

**One radius guess is never right.** A single cut came back **33–126% long** —
trail does not run in circles, and a trail-hungry cost wanders further than a
fast one. Distance is near-proportional to radius, so scale and retry: four
passes lands inside a few percent. Measured across six targets from a real start
node:

| target | fastest | most trail |
|---|---|---|
| 6 mi | 6.3 (±6%) | 6.7 (±11%), 96% trail |
| 15 mi | 14.0 (±7%) | 16.0 (±7%), **100% trail** |
| 20 mi | 20.4 (±2%) | 19.7 (±1%), 95% trail |
| 40 mi | 40.7 (±2%) | 41.9 (±5%), 91% trail |

**0–3% ridden twice** across every target — these are genuine circuits, not
out-and-backs. 62–129 ms to build. The one weak case is a 30 mi *fastest* loop
(24% short): this network cannot make a fast 30 mi circuit without pavement, and
that is the data speaking.

Two shapes are offered — **fastest** and **most trail** — and they become
ordinary route options, so the cards, elevation profiles, fuel and dark
warnings, dashed approach legs and dimmed alternates all work with no new UI.
`◯ Loop` offers 6/10/15/20/30/40 mi.

### Landmine 38 caught me again, and my own edit hid it

I wrote three call sites for `presentRoutes()` and the definition **silently
never landed** — a replacement that no-matched and which I did not re-grep. The
first tap threw `presentRoutes is not defined`, and a second botched edit then
ate the `},30)}` closing `routeToPoint`. Both were found by driving the real UI
in a browser rather than by reading the diff. Verified after: 116 route features,
265 points, a closed circuit from Bull Gap.

Loops are asserted in both harnesses — smoke checks the builder lands within 30%
and under 40% repeat, and the on-device self-test reports actual loop quality so
Jacob's phone tells me how it behaves on his data.

---

## Take 39 — 2026-08-21 — The route was right; the drawing was not

**The action log earned itself on its first field report.** Jacob said two pins
"didn't seem to connect or find a proper path". The trace gave me the exact
inputs:

```
  28.1s  pin  dropped at 44.53949,-84.12855
  30.8s  act  start from here
  33.8s  pin  dropped at 44.55265,-84.10724
  45.8s  route 5 options, best 2.2 mi
```

Straight line between them is 1.39 mi; 2.2 mi over trails is entirely sane. The
routing was never wrong. What was wrong: the cards have always **said**
"+0.5 mi off-network to the pins" while the line silently began at the nearest
graph node — so a pin in the trees produced a route that appeared to start
nowhere near it.

**The gap is drawn now**, dashed, in the route colour, from the pin to where the
network actually starts. Reproduced with his exact coordinates: two legs of
**0.49 mi and 0.06 mi** — precisely the 0.5 mi the card was claiming. The card
wording changed to "+0.5 mi off-network (dashed) to reach the trail" and is a
warning rather than a footnote, because half a mile of pushing a bike is a
planning fact.

`fitBounds` now includes those legs, and clears the chip strip that floats over
the bottom of the map — 40 px of padding had been putting the end of a route
underneath it.

### The self-test hid its own best evidence

His GPS section reported only `XX first-fix — no fix in 20s`, while the action
log showed a startup fix at **2.7 s**. The report dropped `startup-locate`,
`position` and `mode-correct` whenever its own 20-second watch timed out —
losing the informative lines exactly when the live watch failed. Those now report
from the app's actual state either way, and "no fix in this watch" is
distinguished from "no position at all".

---

## Take 38 — 2026-08-21 — Renamed to APEX ORV

Straightforward, with one trap worth recording.

**`strings.xml` is written once by `cap add android` and never revisited by
`cap sync`.** Changing `appName` in `capacitor.config.json` renames the app in
the config, the release title, the About card and the browser tab — and leaves
the launcher label untouched. That is the one place the rider actually reads the
name. `tools/android.py` now patches `app_name` and `title_activity_main`
directly, idempotently, so the rename survives a fresh `cap add` or an existing
android/ tree either way.

Renamed: window title, header, About card, the loader's fatal screen, the GitHub
release title, ROADMAP, and the Android launcher label. Verified out of the built
APK with `aapt2 dump badging`.

**Deliberately NOT renamed: the signing certificate.** It reads
`CN=APEX Off-road` and must keep reading that — it is what every installed build
is signed against, and the committed keystore is what makes take N install over
take N-1. The `-dname` in `android.py` only applies if the keystore is
regenerated, which would break update continuity regardless (AGENDA A21). Noted
in place so a future reader does not "tidy" it.

---

## Take 37 — 2026-08-21 — Process, not features

Jacob asked what could be improved given that he cannot help with APK work. The
honest bottleneck is not his skill: **three of his last four reports were
interaction bugs my tests structurally could not see**, and several times my
harness either hid a real bug or invented a fake one. Three fixes, aimed there.

### 1. The stubs are now checked against the app

Six times a stub has omitted a method the app calls. Twice it **hid** a feature
(marker taps, take 33), four times it **invented** a failure the app did not have
(`getElement`, `scrollIntoView`, `getContainer`, the two `queryRenderedFeatures`
contracts). Every one was found by a person tapping a phone — the most expensive
way to find anything.

`check_stubs()` is static and free: it extracts every `map.X()`, marker method
and DOM method the shipped `app.js` calls and fails if the harness does not
implement it. On its first run it found **eight genuine gaps** —
`getCanvas`, `getLayoutProperty`, `isStyleLoaded`, `jumpTo`, `setBearing`,
`El.click`, `El.remove`, `El.select` — all in the self-test path, which smoke
had never exercised. Filling them meant **smoke can now run the app's own
self-test too**, so a regression there is caught by whichever harness runs first.

Smoke judges only what a stub can judge: render and perf failures are expected
and isolated, everything else must pass.

### 2. Layout checks that run on his phone

The class that keeps biting is layout, and no data check sees it. The self-test
now measures the rendered page at his width: nothing wider than the screen (the
take-35 bug exactly), every horizontal scroller within the screen, tap targets,
primary actions on screen, and the map keeping most of the height.

It immediately found a real one: **chips were 31 px tall**. For gloves on a
moving bike that is too small — now 38 px minimum.

It also produced two false positives of its own, both fixed rather than
tolerated: a row that simply *fits* is not a row that *cannot scroll*, and a
hidden panel legitimately has no width.

### 3. An action log in the report

Prose loses order and state. The report now carries the last 25 actions with
timestamps — taps, pins dropped and removed, GPS fixes, routes computed — so
"I clicked start from here, then tried to drop another pin" becomes a trace.
It stays on the phone unless he shares it.

### And I broke something mid-take

Removing a duplicated `stLayout` — I had defined it twice — my slice also
deleted `stData` between them. Caught by the render harness immediately
(`stData is not defined`), recovered from the saved block. A surgical edit
across two anchors must check what lies between them.

---

## Take 36 — 2026-08-21 — Long press to pin, and a pin that knows when it is done

Two reports, one root cause: **tap was doing too many jobs.** It identified a
trail, and on open ground it also dropped a pin — so a pin could never be placed
*on* a road, and the two meanings fought.

**Long press drops a pin now; tap always identifies.** Own implementation rather
than the browser's `contextmenu`, which is inconsistent in a WebView and cannot
be tuned: 450 ms with a 12 px tolerance — long enough not to fire while panning,
short enough to feel deliberate with gloves — and a buzz on fire, because a
gesture with no feedback feels broken. Right-click does the same on desktop.

Verified with real CDP touch at 411x960: a **700 ms hold** on a spot with six
features under it drops a pin at Bull Gap (1070 ft); an **80 ms tap** at the
same point identifies instead.

### The pin that "wiped out" the first one

Tapping **Start from here** moved ME to the pin — and left the pin sitting on
top of the new ◎ marker. The next pin then appeared to erase the first, when in
truth the first had already done its job and become the start. A pin consumed by
an action is now removed, the message says which marker holds the spot, and drop
cards gained **✕ Remove pin**.

### My probe was wrong before the code was

The first touch test reported both gestures dead. `getCanvasContainer()` is a
**zero-height** wrapper around absolutely-positioned children, so computing a
press point from its rect aimed at y=38 — up in the chip strip, not the map.
Landmine 54 for the sixth time: verify the check before believing it. It did
surface a real fragility though — `lpAt()` now measures `getContainer()`, which
is what `unproject()` is defined against and actually has a height.

### From the field report

Take 34 self-test: **36 pass, 0 fail**, and the frame-time detail added at take
32 closed an open question — `0/70 frames over 33 ms · worst 14 ms`. The earlier
p99 of 21 fps was a single hitch, not stutter. First fix took 10.9 s at ±25 m
this time versus 0.8 s at ±4 m before; indoors, and worth watching rather than
acting on.

---

## Take 35 — 2026-08-21 — Four bugs in the route picker, measured not guessed

Jacob reported three symptoms while planning a trip from home: the line did not
update, the map shifted randomly, and the option strip could not be scrolled so
a fourth option would be invisible. Reproduced all of it in headless Chrome at
his exact viewport (411x960 @2x) before changing anything — and one of my
assumptions was wrong.

**The line WAS updating.** Instrumenting `setData` showed a redraw with distinct
geometry on every tap. What he was actually seeing:

1. **`fitBounds` fired on every selection.** Five routes over the same 3.7 mi
   corridor look nearly identical one at a time, and re-framing the map on each
   tap read as "shifting over randomly" while masking the very change it was
   meant to reveal. Now fits only on the first draw.
2. **The strip could never scroll.** `#shell` is a grid, grid items default to
   `min-width:auto`, so `#rail` refused to shrink and grew to **788 px on a
   411 px screen**. Nothing overflowed, so there was nothing to scroll and cards
   4 and 5 were simply unreachable. `#shell>*{min-width:0}` fixes it —
   measured: scrollWidth 799 vs clientWidth 385, scrollable.
3. **Selecting rebuilt the whole strip**, resetting `scrollLeft` to 0 on every
   tap. Now the `.sel` class is toggled in place and the chosen card is scrolled
   into view.
4. **Alternates were invisible.** The other four routes are now drawn dimmed
   underneath, so switching visibly moves the highlight — the pattern every
   first-party map uses. 272 alternate segments drawn.

Verified per card at his viewport: refit 0, scroll preserved, exactly one card
marked, and the line redrawn each time.

**And the harness was hiding a real call again.** `El` had no `scrollIntoView`,
so the stub threw where a browser would not. Added — and the app now guards the
call, since the options form is not universal in older WebViews. Same family as
the missing `getElement()` at take 33: an API a stub omits is an API the tests
cannot see.

---

## Take 34 — 2026-08-21 — Offline geocoding, both directions

Jacob asked for an address on a pin, and to be able to type an address to set
home — with the explicit rule that **when there is no address, say nothing**.

Live geocoding is a network service and this app does not get to depend on one
on a trail, so the index ships in the bundle. Source: Census TIGER **ADDRFEAT**,
per-county address *ranges* — each road segment carries the house numbers at
each end, per side, plus the ZIP. That is how rural geocoding works where there
are no address points: find the nearest segment, work out which side of it you
are on, and interpolate along it.

`tools/address.py` picks the counties overlapping the region from the Census
county file, downloads their ranges, clips to the region and emits a name table
plus segment records. For Bull Gap: **2,797 segments, 761 street names, 186 KB**
(bundle 1.89 → 2.07 MB). Counties chosen automatically — Alcona, Oscoda, Ogemaw
and Iosco matched; Crawford correctly did not.

**Verified on real data:** The Pink Store resolves to *5525 S Mount Tom Rd,
48654*, Mack Lake to *1798 Partridge Ct, 48647*, and a round trip —
point → address → back to point — lands within **14 feet**. Only 2 of 8 anchors
resolve at all, which is the honest state of rural address coverage and exactly
why the card must stay quiet rather than announce a gap.

- **Reverse:** shown on every place card when found, omitted entirely when not.
  Parity is preserved, so an odd-side range never yields an even number.
- **Forward:** typing "4952 S Branch Rd" leads the search results and opens a
  place card, which already carries **Make this home** — so setting home by
  address is two taps and needed no new UI.
- Street names joined the search index, so "Mount Tom" finds the road.
- A point outside the data returns **null**, never a nearest guess. Smoke and
  the self-test both assert this specifically; inventing an address 60 miles
  from the data would be worse than having none.

`parse_shp_all()` in context.py now serves both the county outlines and the
address ranges — same record layout for polygon and polyline, and null shapes
yield an empty list so DBF rows and geometry stay aligned. Silently dropping
them would shift every later record's attributes.

---

## Take 33 — 2026-08-21 — Michigan looks like Michigan, and the map answers taps

### Legal boundary vs land boundary is not a detail

Take 32 drew Michigan from TIGERweb's **legal** state boundary, which runs far
out into the Great Lakes — one 10,721-point ring wrapping both peninsulas and a
great deal of water. Jacob: "the weirdest map of Michigan I've ever seen." He was
right, and the mistake was mine for shipping a shape I had never looked at.

The **cartographic** boundary file (`cb_2023_us_state_20m`) is clipped to the
shoreline: Lower Peninsula, Upper Peninsula, Isle Royale and three islands in
469 points. `context.py` now downloads that zip and parses the shapefile
directly — a small DBF reader to find the state and a polygon reader for its
rings, about eighty lines, no dependency. Rendered as **filled land** rather
than a line, because the land/water contrast is what makes the mitten legible.
Four Great Lakes are labelled from a fixed table; nobody needs lake geometry to
know where Lake Michigan is. 6.9 KB in the bundle.

### The map answers taps now

The app had no place interaction at all. It has the first-party pattern now:

- **Tap the home pin, your position pin, or open ground** and get a card —
  coordinates in DD, elevation, distance and compass bearing from you, and the
  nearest named trail with its number.
- **Actions on every card:** Directions here, Make this home, Start from here,
  Dispatch card (live fixes only), Centre.
- **Tap-to-route.** `routeToPoint()` was extracted from the Return Home handler,
  so a tapped pin gets the same five profiles, the same machine legality and the
  same closure avoidance. One router, many callers — Return Home is now just
  this with HOME as the destination.
- Tapping a **trail** still identifies it; only open ground drops a pin. One
  handler, one meaning per tap (landmine 50).

Dropping a pin no longer silently moves the planning start, which was
unexplained and had no undo.

### The harness was quietly declining to test markers

The `Marker` stub had no `getElement()`, so the pin-tap listeners — wrapped in
try/catch — registered nowhere and the whole feature was invisible to smoke.
Added, and `--away` now taps the home pin, asserts its card, taps open ground,
asserts the dropped-pin card, and routes to it. Landmine 39, again: a stub that
omits an API silently omits the feature that uses it.

---

## Take 32 — 2026-08-21 — Clean sweep, and the icon finally fits

**Take 31 field report: 34 pass, 0 fail.** Every previously failing check is
green — `startup-locate` confirms the app knew its position before the test ran,
`mode-correct` reports `posMode=away`, and the fix arrived in **0.8 s at ±4 m**.
The whole GPS chain works on the device.

### The icon was clipping, and it was my bug

`trimmed()` crops the mark to its ink — 782x636, decidedly not square — and then
I resized that into a **square** safe zone. Two errors compounding: the aspect
was distorted, and the extremes were pushed outward until a launcher mask ate
the A's foot and the X's arm.

Now the foreground keeps the master's aspect (1.231 vs 1.229) and is sized by
the **diagonal**, not the width, because a circular mask cuts corners and the
bottom-left of this mark *is* a corner. The furthest ink corner now sits at
r=0.311 of the canvas against a safe-circle radius of 0.310. Verified against
circle, squircle and rounded-square masks — the three shapes a launcher may
apply — with clear margin in all of them, and smaller overall as asked.

### Frame-time instrumentation

p99 min fell 90 → 21 fps between runs while the average held at 115. A single
hitch and a sustained stutter produce the same p99 and need completely different
answers, so the perf check now reports **how many frames exceeded 33 ms and the
worst one**. It also fails on more than 10% slow frames rather than on p99
alone — one GC pause should not condemn a device, and a hundred should.

---

## Take 31 — 2026-08-20 — Michigan, and the startup fix that never fired

Field report on take 29: **32 pass, 1 fail**, and the failure was the one that
mattered — `posMode=none` meant the app still had no idea Jacob was 135 mi away.

### Startup locate never worked

Take 30 used `getCurrentPosition` with `enableHighAccuracy:false` and a 10 s
timeout. On the Fold it never produced a fix, while the self-test's **own watch
got one in 1.0 s at ±17 m** in the same session. So `locateOnce` now uses the
same `gpsStart` machinery that demonstrably works, takes the first fix and stops.
**One proven path beats two plausible ones.** The self-test gained a
`startup-locate` check that reports whether the app knew its position *before*
the test ran — the thing a rider actually experiences on opening the app.

### The orange box is gone; Michigan is there instead

Jacob called the DOWNLOADED square distracting and ugly, and he was right — it
shouted at the one part of the screen that was already obvious. Removed
entirely. In its place, the **state outline** from US Census TIGERweb: a thin
grey line below z9.6, fading out as you approach the data, 10,721 points
simplified to **126** and 2.3 KB in the bundle. It answers "where am I relative
to my download" and nothing else — it is not in the graph, the router, or any
safety path, and it disappears before it could be mistaken for a trail.

**A silent RDP bug nearly ate it.** On a closed ring the first and last points
are identical, so the baseline has zero length and every perpendicular distance
evaluates to exactly **zero** — the simplifier discarded the entire state and
returned two points, with no exception. Rings are now split at their farthest
point and simplified as two open lines.

### And the harness invented one more failure

`flushTimeouts()` fired every pending timer regardless of delay, including the
25 s give-up timer, releasing the GPS receiver during a four-frame idle loop.
It now respects delays. The `--away` mode was rewritten to drive the **startup**
path with no tap at all, which is precisely what failed on the device.

Also noted from the field report: agency data drifted again (16,352 → 16,440
edges), and elevation at Mio moved 965 → 938 ft with it. Within the 90 ft
tolerance, and a reminder that the DEM re-fetches with the region.

---

## Take 30 — 2026-08-20 — Stop redrawing the logo, use the logo

Takes 24 and 29 both tried to reproduce Jacob's APEX mark from primitives and
both missed. His verdict on take 29 was "isn't even close", and he was right —
the letterforms are specific and hand-plotting them was guesswork wearing an
engineering costume. Three attempts at approximating something I had a pixel-
perfect copy of.

**`assets/logo-master.png` is now the artwork itself**: cropped from the file he
supplied, snapped to the three brand colours so JPEG haloes cannot survive
scaling, corner-cleaned, and reduced to the six shapes that are actually the
mark. `tools/icon.py` derives every density from it — still one source of truth,
still no per-density binaries.

**A logo is a source asset, not generated data.** Committing it is the honest
thing; committing five rendered sizes would not be. The earlier "no binaries"
instinct was right about *outputs* and wrong about *inputs*.

### Cleaning it took three passes, each found by looking

1. His screenshot carried registration marks in the corners — cleared by masking
   to the rounded tile.
2. The tile's own anti-aliased border quantised to white and survived just inside
   an exact-radius mask, so the adaptive foreground showed faint arcs once the
   art was lifted onto transparency. Fixed by insetting the mask 12 px.
3. Sixty-four fragments of JPEG debris remained. The mark is **six** large
   shapes — triangle-with-streak, A, P, E, X, and the red X wedge — with a clean
   size gap between 4,678 px and 423 px, so components under 1,000 px are
   dropped. 130,032 ink pixels kept, bbox x129..911 y128..764.

Verified by pulling the 432 px adaptive foreground back **out of the built APK**
and looking at it, then re-checking under circle and squircle masks and down to
40 px.

**Regression check:** the icon touched nothing in the app — render 19/19, the
app's own self-test 29/29, and all five smoke modes green against the take-30
APK bytes. `icon.py` imports only PIL, os and sys; scipy was used once to prepare
the master and is not a build dependency.

---

## Take 29 — 2026-08-20 — Jacob's mark, and a full pre-test audit

Icon replaced with the design Jacob supplied: A-frame outline open at the base,
APEX across the legs with a dark stroke separating wordmark from frame, red
sliver hanging from the peak, red flick off the X, on charcoal. Drawn as
geometry in `tools/icon.py` (Poppins-Bold for the wordmark) rather than
embedding his JPEG, so it stays crisp at every density and CI regenerates it —
no committed binaries (landmine 32). Three iterations, each judged at 48 px:
the wordmark was first oversized and mid-triangle, then the red streak was a
band where the reference has a sliver. Verified square, circle-masked and at
every launcher density.

Scope noted, since it changes the earlier reasoning: this is a personal
sideloaded tool, never listed or sold. AGENDA A21's keystore decision already
assumed that; the icon follows the same footing.

### Take-29 full audit

| area | result |
|---|---|
| smoke, 5 modes, repo build | all PASSED (124 assertions) |
| render, split build | 19 checks green |
| render, single-file build | PASSED |
| render, shipped APK bytes | PASSED, self-test 29/29 |
| smoke, shipped APK bytes, 5 modes | all PASSED |
| second region (sthelen) full pipeline | COMPLETE |
| primary region, clean pipeline | COMPLETE, 148 s |
| bundle geometry-in-bbox, both regions | COMPLETE |
| gate | PASSED |
| seed ⇄ repo byte-identity | 41 files identical |
| bootstrap simulation | reproduces the tree exactly |
| icon inside the APK | extracted and verified visually |

**Negative controls, all firing:** the take-22 style-expression bug → RENDER
FAILED (15); the `mi()` collision → smoke dies; a missing required network
artifact → app refuses, map not constructed; `CI=1` with no browser → gate
fails.

### Two real findings during the audit

**A transient 503 from a state endpoint killed the pipeline.** Take 14 gave
Overpass retries and stopped there; DNR and USFS had none, so one upstream
hiccup is a red CI build for something nobody controls. All network reads retry
with backoff now (landmine 57).

**And it nearly fooled me.** After the failed run I checked
`bundle.py verify neml-bullgap` and got COMPLETE — from **stale bundle files**,
because ingest died before anything was rebuilt. A verify that passes on
leftovers is landmine 32 wearing yet another hat; the fix was to actually
re-run the pipeline to green rather than trust the verdict.

**Icon centring:** the adaptive foreground centred its coordinate box, not its
ink, leaving the mark visibly high with dead space beneath — only obvious once
extracted from the APK and composited on the declared background. Nudged.

---

## Take 28 — 2026-08-20 — The Fold renders, and the self-test paid for itself

**A18 Stage 0 is closed for real.** Take 27 on the SM-F966U1, Android 16, WebView
Chrome/152, **Adreno 830**: satellite imagery, trails, water, hillshade and place
labels all drawing, **avg 123 fps, p99 min 90**, NET CLEAN, 0 remote requests.
The style-validation fix was the whole thing.

The self-test reported 30 pass / 3 fail on its first field run. **One was a real
bug that broke the app; two were my checks being wrong.**

### The real one: ▶ Ride it was dead on the device

Capacitor 7 returns the watch id **synchronously** from `watchPosition`, not a
Promise. `.then()` threw, `gpsStart()` threw with it, and the click handler died
— while the watch quietly ran in the background, which is why a fix still
arrived in 1.3 s at ±18 m. Both call sites now accept either shape. **A plugin's
return type is not something to assume** (landmine 56); nothing in the harness
could have caught this because the harness stubs Capacitor.

### Two checks that lied

- **labels 0** while the screen visibly showed *The Pink Store*. The check
  counted at whatever viewport the map happened to be on. It now jumps to a site
  anchor, counts, and restores. Landmine 54, fifth appearance.
- **in-region FAIL** whose own detail line read *"planning mode is correct"*. Being
  135 mi away is not a failure; it is Tuesday. Now informational, and the
  assertion is on the app's **response** (`posMode==='away'`).

### What Jacob asked for, built

- **The app now locates you at startup**, not only when you tap Ride. It knew
  nothing about position until a ride began, which is why it cheerfully showed a
  region 135 mi away and said nothing.
- **Zoom out to the whole state.** minZoom 9 → 5.2 and maxBounds widened from the
  bundle bbox to Michigan. A dashed orange **DOWNLOADED** box marks the covered
  area, so blank space reads as *not downloaded* rather than *broken* — and a
  blue **you-are-here** pin sits at the real fix.
- **◉ Locate** flies to the real position (statewide zoom when far, 14.5 when
  inside) instead of delegating to a control that does nothing useful outside
  the region.
- **Place labels now outrank trail names** — MapLibre places earlier layers
  first, and `lbl-place` was last, so town and trailhead names lost every
  contest to road labels.

---

## Take 27 — 2026-08-20 — The app tests itself

Jacob asked for a diagnostic he could run once instead of tapping through every
feature, producing something I can actually work from. Built it, because the one
class of bug I genuinely cannot reach from this container is device-specific
WebView behaviour — and a report from the real thing is exactly that.

**⛑ Self-test** runs 29 checks plus 11 environment readings, in-app, on the
device: bundle state and offline cleanliness, glyph pack bytes, graph and
terrain sizes, style loaded, features drawn per layer group, elevation against
three surveyed landmarks, search index, all five routing profiles with distances,
turn-by-turn steps, machine legality, closure avoidance, breadcrumb accumulation,
retrace losslessness, truck pinning, dispatch refusal, haptics, and frame rate.
Visual pass/fail list on screen, then **Copy** or **Share** (Capacitor Share,
with clipboard fallback).

**The design point:** `tools/render.mjs` calls the *same* `window.__selfTest()`
headless in Chrome. So I hold a baseline for every check, and anything that
differs in Jacob's report is device-specific **by construction**. That is the
only comparison that can isolate a WebView problem.

Every check reports what it **observed**, not just a verdict — "FAIL routing" is
nearly useless; "profiles 0/5 · cost is not a function" names the layer.

### It found four bugs immediately, all mine

- `PROFILES[].cost` does not exist; the field is `.f`. All five profiles threw.
- `IDX` is built lazily, so reading it cold reported "0 entries" — a number that
  looks like failure and means "not built yet". Now forces the build first.
- The fps check asserted ≥30 in headless Chrome, which rasterises in **software**
  at single digits. It now detects a software rasteriser and reports the number
  without a verdict; only real hardware gets judged.
- An SxS finding no route read as a failure when it is usually correct — 72"
  machines are barred from most of this network. Now distinguishes "cannot snap
  at all" (broken filter) from "no legal route" (real data).

And landmine 38 caught me again in `smoke.mjs`: I used `idxSrcEarly` above its
own declaration.

**Baseline from headless Chrome, take 27:** 29 passed, 0 failed. Elevation Δ0 ft
at Mio and Bull Gap, Δ10 at the Pink Store. Routing 5/5 profiles, 8.8–9.8 mi.
Search index 2,543 entries. Breadcrumb 1.26 mi from 25 synthetic fixes, retrace
lossless.

---

## Take 26 — 2026-08-20 — Tidying, and two features proven for the first time

Pre-test sweep. Four things.

**1. Stamping was rewriting history.** Takes 13-25 bumped doc stamps with a
whole-file `replace('take N','take N+1')`. It happened to be harmless — each
file carried exactly one take reference — but any prose deliberately citing an
earlier take would have been silently altered. `tools/stamp.py` now edits only
the stamp line, driven by BUILD. Checked all four docs for damage: none.

**2. Labels and satellite had never been proven to draw.** The take-23 render
check asserted *something* rendered; it never asserted the specific things a
rider depends on. Now, by layer: 712 trail features, 6,751 road features, and —
the one with its own failure mode, the glyph pack — **5 place labels**. Plus the
basemap cycle: satellite hidden by default, visible after one tap, still visible
on Hybrid, hidden again on return. Satellite is an image source with a blob url,
so it fails independently of everything else and deserved its own check.

**3. A self-inflicted false alarm, again.** The trail-name check first asserted
at the region's bbox centre, which is farm roads with no moto trail on it, and
duly reported *"0 trail segments drawn"* on a perfectly good map. Anchored to a
`site` anchor instead: **Bull Gap at z14.5 — 66 trail segments, 5 trail NAME
labels**, which is the thing that matters mid-ride. Third time a broken
instrument has accused a working product this week (drawImage, the constructor
wrapper, now this). The pattern is worth naming: **when a check fails, verify
the check before believing it.**

**4. Nine stale APKs were sitting in outputs.** Any of them installable, most of
them blank-mapped. Removed; the repo is the history, old builds are just a
hazard. One APK, one seed, one setup page.

Render suite is now **16 checks**. Smoke is 5 modes, 116 assertions. Both run
against the shipped APK's own bytes.

---

## Take 25 — 2026-08-20 — Closing take 23 properly

Jacob pointed out that I shipped take 23's fix and moved to the icon without
finishing it. He was right. Five loose ends, all real:

1. **`tools/render.mjs` could not run from the seed.** puppeteer was never a
   declared dependency, and `tools/android.py` *overwrote* `package.json` from a
   fixed template. The check that found the blank map was unavailable to the one
   person who needs it. Now declared, and `android.py` merges instead of
   clobbering.
2. **CI never rendered anything.** `check_render` skipped when Chrome was
   absent, and the workflow had no Chrome — so it skipped every time, politely.
   The workflow now installs Chrome and renders before gating, and the gate
   **fails** rather than notes when `$CI` is set with no browser. Landmine 53.
3. **The single-file build was engineless from a clean seed.** `single()`
   inlined `mlg.js`/`mlg.css`, both **gitignored** — present only in my
   container. From the seed it would have written a 2 MB page with no MapLibre
   in it. Now inlined from `www/vendor/`. Landmine 32, fifth appearance.
4. **The pixel assertion had been dropped** when I tidied the harness after take
   23 — the strongest evidence, quietly deleted. Restored, and implemented
   properly: the screenshot is fed back into the page as an `<img>` and read
   from a 2D canvas, avoiding the `preserveDrawingBuffer` trap entirely.
5. **The CSP engine was never revisited** after take 23 disproved the worker
   hypothesis it was shipped for. Recorded honestly as A27: kept as insurance,
   not as a fix, with a decision point once the Fold renders.

**Negative control:** reintroducing the exact take-22 style bug now fails all
five render checks — glyphs url, feature count, badge, colour count, dominant
colour share. Both builds verified: split and single-file each render 7,736
features, 531 colours, busiest colour 39%.

**Agenda:** A24, A25, A26 closed; A27 and A28 opened. A28 is the honest gap —
Jacob's goal is plan / ride / **improvise**, and loop generation for an impromptu
ride does not exist yet. Sequenced deliberately after A18.

---

## Take 24 — 2026-08-20 — An icon of its own

Jacob found an APEX Capital logo he liked and asked to recolour it and drop the
wordmark. Declined the trace — that is their brand mark — and drew an original
from primitives instead, which costs nothing and is actually his. What he liked
about it (peak geometry, a streak through the letter) is not anyone's property.

`tools/icon.py`: an A-frame that reads as both letter and peak, with a single
tapered streak down the left face in the app's own flag orange, on rail black —
same palette as the map, so icon and app look like one thing. All geometry is
derived from the two triangle edges, so the crossbar and streak sit exactly on
them at every size.

Two revisions after looking at it rendered: a hollow crossbar turned into a
smudge below ~72 px and became solid, and a zigzag "switchback" read as a blob
and became one confident wedge. **Both found by generating the thing and looking
at it at 48 px** — the same principle as take 23, applied to design.

Emits legacy square and round icons mdpi..xxxhdpi, adaptive foregrounds on the
108dp canvas with art inside the 66dp safe zone, `mipmap-anydpi-v26` xml with a
`monochrome` layer for themed icons, and the background colour resource.
Verified under both circle and squircle masks. `tools/android.py` calls it, so
CI generates icons rather than carrying committed binaries (landmine 32).

---

## Take 23 — 2026-08-20 — The map has never rendered, and now it does

**The app has drawn nothing since take 9.** Fourteen takes of "verified" work,
two full audits, 112 green assertions — over a map that was blank every single
time. This is the most important entry in this file.

### The actual cause

MapLibre **rejects an entire style** if any part of it fails validation. Two
parts did:

1. `glyphs` was a bare `data:` URI. MapLibre requires a template carrying
   `{fontstack}` and `{range}`. This is the error the on-device detector
   surfaced, and it was only the *first* one.
2. `lbl-place`'s `text-size` was `['case', cond, w(...), w(...)]` — **two**
   zoom-based interpolates in one expression, which the spec forbids.

Either alone kills all 24 layers. My take-22 diagnosis — a blocked `blob:`
worker — was **wrong**, and the detector I built is what proved it wrong. That
is the one thing that went right.

### Fixes

- Glyphs now load through a custom `apexfont://{fontstack}/{range}.pbf`
  protocol registered with `addProtocol`, serving the pack from memory. Works
  identically in the single-file build and the APK, no font files, no network.
- `wCase()` keeps a single zoom curve on the outside and branches inside it.

### tools/render.mjs — the hole that let this live for 14 takes

`smoke.mjs` stubs `maplibregl` entirely, so it could never see a style being
rejected. `render.mjs` serves `www/` over http, loads it in **real headless
Chrome**, and asserts: no page errors, no map errors, a valid glyphs url,
`queryRenderedFeatures() > 0`, the badge is not RENDER FAIL, and the composited
screenshot is not one flat colour. It is now a pipeline step and a gate check.

**Verified output:** 7,736 features rendered, badge `GRAPH 16352`, 6,037
distinct colours, and a screenshot showing hillshade, the road network, water,
and labels reading *Mack Lake*, *The Pink Store*, *Bull Gap*.

### Two testing lessons, paid for expensively

- I wrapped MapLibre's constructor to catch construction-time errors, and the
  wrapper **broke the map** — no events, no layers, no errors — producing a
  confident, fabricated diagnosis. Observe; never intercept.
- My first pixel check read the canvas with `drawImage`, which always returns
  black because MapLibre runs `preserveDrawingBuffer:false`. The test reported
  "blank map" on a map I had not yet proven either way. Screenshot the
  composited page instead.

Both are landmine 39's moral from the other side: **a broken instrument reports
failure as confidently as a broken product.**

---

## Take 22 — 2026-08-20 — Pre-flight on take 21's own changes

Take 21 changed a lot in one pass. Audited it as an adversary, and three of the
new things were wrong.

### 1. The CSP engine could have bricked the app entirely

If `maplibregl.setWorkerUrl` were not a real top-level export, `index.html`
would throw on the first script and produce **nothing** — strictly worse than
the blank map it was fixing. Loaded `maplibre-gl-csp.js` in a stubbed browser
realm: 66 exports, `setWorkerUrl` a function, `Map`/`Marker`/`GeolocateControl`/
`LngLatBounds` all present. API-compatible. Verified rather than assumed.

### 2. The RENDER FAIL detector would have cried wolf

`queryRenderedFeatures()` is legitimately empty while tiles are still being
built, so a single check 1.5 s after load could condemn a **healthy** map. It now
takes three zero readings over ~7 s, is driven by the `idle` event, and any
non-zero reading settles it permanently and restores the badge. **A false alarm
is worse than the silence it replaces** — a rider who learns to ignore this badge
has lost it. Drilled with `--dead-renderer` per landmine 45.

### 3. Planning mode clobbered the identify tap

Take 21 added a *second* `map.on('click')`, so every tap both identified a trail
and moved the planning start — the second handler winning and wiping the trail
card. Worse, the app already had an arm-a-pin flow doing this properly. The new
handler is gone; planning folds into the existing empty-ground branch, so
**tapping a trail identifies it, tapping open ground plans**. One handler, one
meaning per tap.

### And the harness invented a bug of its own

To make a healthy renderer look healthy I had the stub return 1,240 features
from `queryRenderedFeatures` — to *both* of MapLibre's contracts behind that
name. The no-argument form is a viewport census; the box form is a hit test.
Conflating them made a tap on open ground look like a tap on a trail. Faithful
stubs, or the harness invents failures that do not exist.

**Smoke is now five modes** — gps, sim, fatal-drill, dead-renderer, away — all
run by the pipeline and all enforced by the gate, which previously ran only one.

`--away` is Jacob's actual situation and it passes end to end: out-of-region fix
reports the distance, stops tracking, labels the readout MAP CENTRE, dispatch
refuses with no coordinate printed, a tap drops a planning start, a tap on a
trail still identifies it, and Return Home routes 5 profiles from the planned
start.

---

## Take 21 — 2026-08-20 — A18 opens: the Fold spoke, and it said two things

**Stage 0 PASSED, enormously.** avg **121 fps**, p99 min **119**, remote **0**,
NET CLEAN, GRAPH 16352, chips populated from the region manifest. The offline
bundle pipeline works on the device. Bar was 50/30.

**And the map was blank sand.** Both facts are the same fact.

### The renderer was idle, and my test called it fast

121 fps over an empty canvas is not speed. The pan test printed
*"16352 edges rendered"* — a number taken from `EDGES.length`, i.e. from what I
hoped, never from what drew. **My instrumentation asserted its own hope and
reported PASS on a broken app.** It now calls `queryRenderedFeatures()` and
prints *drew of total*, and fails when drew is 0.

### Diagnosis, by elimination rather than guess

Executed the shipped APK's own bytes: net source **16,352 features**, water 422,
places 8, geometry spanning -84.37..-83.87 / 44.36..44.75 — all correct. 24
layers correctly wired, only 2 hidden by design. `map.on('load')` demonstrably
fired (the chips carry a runtime class). So: valid style, valid data, working
map transform — the DOM markers positioned correctly, which requires it.

What draws on the **main thread** worked (background, DOM markers). Everything
that requires MapLibre's **worker** — every GeoJSON and raster source — drew
nothing. MapLibre builds that worker from a `blob:` URL; Android WebView under
Capacitor is a known environment where that fails. MapLibre publishes a CSP-safe
build for precisely this, so the app now loads `maplibre-gl-csp.js` with an
explicit `setWorkerUrl("vendor/maplibre-gl-csp-worker.js")`.

**Stated honestly: this fix is inferred, not yet observed.** So the app also
ships a detector — if sources hold features and `queryRenderedFeatures()`
returns 0, the badge reads **RENDER FAIL** and the panel explains what loaded,
what did not, and names any engine error. The next run either works or tells us
exactly why. Landmine 47.

### The more serious bug: a fabricated position

The screen read **44.57072 -84.15770 · 1135 ft** while Jacob was a few hundred
miles away. Precise, plausible, wrong — sitting on the same screen as the button
that reads coordinates out to **dispatch**. That is the worst failure mode this
app has shipped, and no render bug outranks it.

`posMode` now distinguishes `none` / `gps` / `sim` / `away`:

- the readout labels the coordinate **MAP CENTRE** until a real fix exists;
- an out-of-region fix says *"about N mi from Bull Gap"* and enters **planning
  mode** rather than pretending;
- **dispatch refuses** anything but a live in-region fix, and says why;
- the simulator sets `posMode='sim'` — it exercises every line of the GPS path
  (test-double fidelity, take 16) but is **still refused** by dispatch, because
  those coordinates are invented. Smoke asserts both halves.

### Planning mode — what Jacob actually asked for

Tap anywhere to drop a planning start; **Return Home** and **Directions** route
from it. Search, browse, elevation and the full graph all work hundreds of miles
away, which is where ride planning actually happens.

**A18 amended:** Stage 0 closed (121/119). Stage 1 blocked on the render fix.

---

## Take 20 — 2026-08-19 — First live run: bootstrap green, build silent

**Jacob ran it.** Bootstrap: checkout, seed download, unzip, `GATE PASSED —
take 19`, 38 files committed (43 zip entries less 5 directory entries — exact),
pushed `602c83a..d147a6f`. Twenty seconds. Every local prediction held.

**And then nothing built.** A push authored by GITHUB_TOKEN does not trigger
`on: push` workflows — GitHub's anti-recursion rule. Landmine 46, and one that
nineteen takes of auditing structurally could not find: every check I ran was
against files and YAML, and this is a property of GitHub's event system.
Platform semantics require a real run to learn.

Recovery was one tap because `workflow_dispatch:` was already on build.yml
(added at take 17 for manual runs). Permanent fix: the seeder now ends with
`gh workflow run build.yml` — `workflow_dispatch` and `repository_dispatch`
being the two documented exceptions to the token rule.

Nothing in the seeded repo is wrong; it does not need re-seeding.

---

## Take 19 — 2026-08-19 — Audit round two: the refusal path fires

Second full audit, from the exact deliverables. Fifteen checks: seed ⇄ staged
repo byte-identical per file (43/43, none extra, junk-free, `.gitignore`
carried, `.github/` excluded); setup-embedded workflows byte-identical; release
permissions (`contents: write`) and the gh token present — the first-real-run
killers; all 12 actions pinned; Pages-safe relative paths; the take-18 APK
re-opened and its own bytes run through GPS, simulator **and** partial-imagery
modes; all five verifiers green against the live-drifted 16,409-edge data; both
regions verify; take numbers coherent.

**Two of my own probes misfired across the two audits** — the `pages:` split
and a literal-`fetch(` grep — each failing a correct artifact. Same moral as
landmine 39 from the other side: hand-rolled greps lie in both directions; the
executed smokes are the authority.

**The gap worth a take: the unusable-region refusal had never fired.** The
fatal screen is landmine 34's entire promise, and no audit had executed it.
`smoke.mjs --fatal-drill` now copies the target www, strips the required
`network` artifact from the manifest, and asserts: fatal screen shown, it says
*Region incomplete*, names the missing artifact, states the principle ("worse
than no map"), the map is **not** constructed, zero remote requests. Fired
against the repo build and against the shipped take-18 APK's extracted bytes —
both refuse correctly. The pipeline now runs smoke in **three** modes.
Landmine 45.

**DEFERRED:** unchanged. Jacob runs the setup next; A18 awaits four numbers.

---

## Take 18 — 2026-08-19 — Full-stack pre-flight, and the second build was broken

Jacob asked for a full-stack smoke before running the setup. Everything was
verified from the **exact files he will download**, nothing from the warm tree:
seed integrity and standalone gate; both pasted workflows parse, and the setup
page's embedded copies are byte-identical to the real files; a clean pipeline
from the seed absorbed live agency drift (16,409 edges vs 16,345 — the trails
moved upstream since the first fetch, and the pipeline just took it); **the
bytes inside the shipped APK were extracted and executed** through smoke, both
GPS and simulator modes; and a clean `npm → cap → gradle` build from the seed
produced an APK whose signing cert digest **equals the shipped one** —
signature continuity proven, CI updates will install over the sideload.

**One layer was red, and it was going to be his second build.** The bundle job
skipped the pipeline on cache-hit, so `bundles/` and `www/bundle` never
existed, and the next step's `cp bundles/…/manifest.json` dies. First build
fine; every subsequent push fails. **Executed, not inferred**: simulating the
cache-hit checkout reproduced the failure exactly. Landmine 44.

Fix: the pipeline is unconditional — a cache hit is a *fast path*, not a
skipped one — and `dem_cache/` + `img_cache/` join the cache so the warm run
stays warm. The fixed path was then executed: **13 seconds**, both smokes, all
artifacts, gate green.

A small verifier lesson en route: my pages-job probe split the YAML at the
first `pages:` — the *permissions* block — and failed a correct workflow.
Filed under landmine 39's moral: a checker aimed at the wrong slice fails good
artifacts as happily as bad ones.

**DEFERRED:** unchanged. A18 is one mailbox-walk away.

---

## Take 17 — 2026-08-19 — First-run experience, walked as the user

Walked the RUNBOOK as Jacob would and found the first thing a new user sees is
**two red failed runs**: pasting `build.yml` triggers a build on its own paste,
and again on the bootstrap paste, both before any tools exist. Fixed with a
push **paths filter** matching exactly what the seed delivers (BUILD, src/,
tools/, regions.json, package files, signing/) plus `workflow_dispatch` for
manual runs — a fresh repo now shows nothing until bootstrap seeds it, and the
seed commit itself lights the first build. Landmine 43. Also added a
`concurrency` group (superseded pushes cancel) and per-job timeouts so a hung
agency endpoint cannot eat the Actions allowance.

**Bootstrap now gates the seed before committing.** The runner runs
`tools/gate.py` against the unzipped tree; a truncated upload or stale zip is
refused instead of becoming the repo's first commit.

**`apex-setup.html`** — the real deliverable: a self-contained, offline page
that walks every tap. Type the GitHub username once and every link templates
itself (including `releases/new?tag=seed-1`, which pre-fills the tag); both
workflows are embedded with one-tap Copy buttons (clipboard API with an
execCommand fallback); the two device tests end with exactly the four numbers
to report. Downloads drop from four files to two: this page and the seed.

APK rebuilt as `apex-offroad-take-17.apk` (Gradle warm — seconds, not
minutes). Smoke both modes green.

**DEFERRED:** unchanged — A14, A17, Phase 1b background tracking, and A18
until the Fold speaks.

---

## Take 16 — 2026-08-19 — A real APK exists

**Shipped:** `apex-offroad-take-16.apk` — 4.8 MB, release-signed
(CN=APEX Off-road, O=SergeantSlabs, cert SHA-256 52f61c46…), package
`com.sergeantslabs.apex`, with the entire neml-bullgap region verified inside
`assets/public/` by unzip. Built **in the container**, not imagined in YAML.

### The apk job was the take-2 spike, in the workflow this time

Its "Write build config" step still wrote a `bullgap-spike` package.json.
Landmine 35's third appearance, now in CI. The job is rewritten to call
`tools/android.py` — the same tool that just produced the working APK — and the
gate refuses a workflow that stops calling it.

### tools/android.py — one tool for CI and hand

Idempotent: writes package.json + capacitor.config.json, npm install
(Capacitor 7 + Geolocation + Haptics), `cap add android`, then patches what the
template does not know this app needs: location/wake/vibrate permissions,
`density` added to configChanges (**landmine 7 — the Fold changes density when
it folds; without it Android restarts the activity and drops the ride**),
`FLAG_KEEP_SCREEN_ON` in MainActivity (a nav screen that sleeps mid-trail is a
safety failure), and release signing.

**The keystore is committed, deliberately.** Anyone with the repo can sign an
update that installs over this app; for a personal sideloaded tool that is the
right trade against the alternative — a fresh CI debug key per run, meaning
every new take refuses to install over the last. Recorded in AGENDA A21;
revisit before any public distribution.

### The app grew its phone half

- **Live GPS.** `▶ Ride it` starts a `watchPosition` that feeds the *same*
  startRecording → record → checkOffRoute chain the simulator proved. The sim
  is the test double, GPS is production, and they share every line after the
  fix arrives. file:// (and the smoke harness with `--no-gps`) fall back to the
  simulator with a plain explanation.
- **Haptics bridged.** Android's WebView does not implement
  `navigator.vibrate` — silently. The off-route alert's buzz would have been
  dead in the APK. `buzz()` now prefers Capacitor Haptics.
- Permission requested once at map load when running inside Capacitor.

Smoke gained a live-GPS scenario: the harness owns the fix stream, asserts the
watch starts, 28 fixes accumulate 1.4 mi of breadcrumb through the real chain,
and stop clears the watch. The pipeline now runs smoke twice — GPS and
`--no-gps`.

### Toolchain lessons, paid for in failed builds

`java` ran but `javac` did not exist — a JRE is not a JDK, and the first Gradle
run died on it. ubuntu-latest runners preinstall the Android SDK and
setup-java provides a full JDK; **a container has neither, which is exactly why
the build had to be proven in one** (landmine 40).

### Getting it onto GitHub from a phone

34 files is too many to hand-create in a mobile browser. The flow is now three
artifacts: paste `build.yml`, paste `bootstrap.yml`, upload `apex-seed.zip` as
a release asset — then run bootstrap once and it commits the whole tree.
The seed **excludes `.github/`** because GITHUB_TOKEN cannot push workflow
files (landmine 42); the two workflows are precisely the two hand-pastes.

**DEFERRED:** background tracking / foreground service (screen-on riding makes
it Phase 1b, after A18); A14, A17. **A18 amended, not closed:** an APK exists
and verifies internally — battery, sunlight, gloves, One UI and the fold seam
remain zero-evidence until it runs on the Fold.

---

## Take 15 — 2026-08-19 — The shipped app runs, and running it corrected the record

**The gap:** `www/app.js` — the exact file CI packages — had only ever been
*parsed*, never *executed*. verify6-11 mirror the algorithms in Python; a mirror
can prove the maths and still miss the wiring. `tools/smoke.mjs` now stubs the
browser and drives the real file against a real bundle: search, Return Home,
directions, ride, retrace, dispatch, basemap, partial-region, both regions.

**First execution ever. Three shipped bugs, in severity order:**

### 1. Every Phase-4 distance call has been invoking the number 0 since take 7

`var ORDER=[...],mi=0` (take 6, machine index) collides with `function mi(a,b)`
(take 7, distance). Function declarations hoist; the `mi=0` assignment then
overwrites the function at startup. Back-to-truck, breadcrumb gating, retrace
distance, off-route detection, dispatch ranges — all dead on first use, hidden
because `syncSafety` early-returns until a truck pin exists. **The take-7 and
take-8 handoffs claimed these "verified"; that was true of the mirrored maths
and false of the shipped wiring.** This entry corrects those claims. Renamed to
`machIdx`.

### 2. Labels and place names have been wired dead since take 9

The LABELS block (GLYPH_URL, PLACES, placeFC) accreted hundreds of lines BELOW
the map constructor and the pins that consume it. `var` hoisting made every
reference `undefined` instead of an error: `style.glyphs=undefined`, places
source `data:undefined`. verify9 proved the glyph *pack* byte-perfect while the
*wiring* was dead. Take 14's `anchorOf` upgraded the silence to a fatal crash —
which is what the smoke test hit on its first run. Block moved above first use,
with a comment marking definition order as load-bearing.

### 3. A bundle's imagery could never be placed without scratch files

The georeference lived only in `imagery_meta.json` in the working directory —
never in the bundle. A bundle alone (the on-device case) fell back to
`[0,0,0,0]`. The manifest now carries `imagery_bounds`; `bundle.py verify`
refuses imagery without it; the loader reads it from the manifest; the app
guards `SAT_OK` so an imagery-less or georef-less region locks the basemap to
Map instead of feeding MapLibre a degenerate image source.

### And the parent-scratch fallback contaminated sthelen a second time

`bundle.py`/`build_app.py` still fell back to the directory above ROOT — stale
take-10 artifacts — and quietly rebuilt sthelen from neml files when scratch was
empty. The take-14 geometry check caught it; the fallback is now deleted rather
than survived.

**Smoke is load-bearing now:** pipeline's final step, and a gate check that runs
the app whenever a built bundle exists. Negative control: reintroducing the `mi`
collision in `www/app.js` fails the gate. 22 assertions green on neml, green on
sthelen, and the partial-imagery path verifies PARTIAL badge + named missing
layer + basemap locked to Map.

**DEFERRED:** A14 3D/slope. A17 voice. A18 stands — and stands corrected: before
today, "the app works" was a claim about Python mirrors of it.

---

## Take 14 — 2026-08-19 — Regions are real, and a second one proved it

**The AOI was hardcoded in ten places across seven files.** Adding a riding area
meant a coordinated edit nobody would get right twice — the same class of problem
as landmine 32, state kept in sync by hand.

`regions.json` is now the single definition: bbox, centre, imagery zoom, anchors,
note. `tools/region.py` reads it; every tool imports `R`. `pipeline.py --region
<id>` runs the lot.

### A second region, built from nothing

**St. Helen / Roscommon** — a different DNR management unit, deliberately, so the
pipeline could not be quietly shaped around one place.

| | Bull Gap | St. Helen |
|---|---|---|
| features | 648 | 294 |
| edges | 16,345 | 8,590 |
| connected | 99.4% | 99.4% |
| relief | 199 m | 204 m |
| network climb | 88.9k ft | 46.2k ft |
| bundle | 1.88 MB | 1.19 MB |
| app | 3.17 MB | 2.46 MB |

The app is region-agnostic now: chips, place labels, home and me pins, map centre,
max bounds and the pan-test route all come from the manifest. **Zero Bull Gap
coordinates remain in `src/app.html`.**

### Four bugs, each found by doing rather than reading

1. **Overpass rate-limits.** A 429 killed the whole pipeline. Retries with
   backoff now — it is a volunteer-run service and deserves the manners anyway.
2. **`fetch_osm` skipped when `aoi.json` existed**, so building region B straight
   after A would have silently used A's OSM data. `ensure_workspace()` makes the
   working directory single-region: switch, and everything derived is cleared.
3. **`build_app` picked the alphabetically-first bundle**, so a St. Helen page
   carried Bull Gap's manifest. And `--region` was being swallowed as the output
   path.
4. **The worst one: a St. Helen bundle containing Bull Gap's graph.** Every hash
   correct, every size correct, wrong place entirely. Hashes prove files are
   *intact*; they do not prove files are *for this region*.

### The check that class deserved

`bundle.py verify` now decodes the graph and asserts its nodes lie inside the
declared bbox. On the contaminated bundle it reported **7,179 of 9,285 nodes
outside bbox, data spanning -84.37,44.36 to -83.87,44.75** — the wrong region,
named exactly. That is the check that would have caught it in one run.

The gate also refuses a bare lat/lon literal anywhere in `tools/` outside
`regions.json`, so the AOI cannot leak back into code.

**DEFERRED this cycle:** A14 3D terrain and slope. A17 voice. A18 remains the
standing blocker — nothing has run on the Fold.

---

## Take 13 — 2026-08-19 — The pipeline runs clean, and four things were broken

Ran the full sequence from a checkout containing **only committed files**, for
the first time in thirteen takes. It failed four times. Every failure was
invisible because artifacts survived on disk from earlier runs — landmine 32,
which I had already written down and still walked into.

### 1. The Overpass fetch had been silently reverted

Added at take 10. At take 11 I ran `cp /home/claude/ingest.py tools/ingest.py`,
overwriting the patched file with an older copy. Nothing failed, because
`aoi.json` was already on disk and stayed there for takes 11 and 12.

**The gate showed the signal and I read past it.** Declared provisioning hosts
fell from 6 to 5 between takes 11 and 12; I printed that line in both takes and
did not notice. The gate now **fails** on a declared-but-unreached host, because
that is precisely the fingerprint of a vanished pipeline step.

### 2. Overpass returns 406 to urllib's default user-agent

Only ever hit because take 5's fetch was a hand-written `curl` that set one.
Fixed with a proper identifying UA, which is also just good manners on a
volunteer-run service.

### 3. The hillshade trim lived in a throwaway script

`terrain.py` emitted 428 KB; the 227 KB version shipped in takes 8-12 came from
an ad-hoc resize I ran once and never committed. A clean run produced a shade
nearly twice the intended size and nothing complained. `terrain.py` now emits its
final size directly.

### 4. Nothing produced the water layer at all

`water_payload.json` came from a one-off snippet. On a clean run there is no
water, and the bundle verifies as **PARTIAL** — correctly, quietly, and not as
intended. `pack.py` is now a real step producing exactly what the app still takes
straight from OSM. Everything else it draws comes from the routable graph, so the
old `payload.json` was dead weight and is gone.

### tools/pipeline.py

The sequence now lives in one runnable file rather than scattered through YAML,
so CI and a laptop cannot diverge. The workflow calls it.

**Clean run: 57 seconds**, all six artifacts, bundle COMPLETE, `www/app.js`
parses, all five verifiers pass, gate green.

| step | time |
|---|---|
| ingest (DNR + USFS + 2,787 OSM elements) | 8.0s |
| pack (242 water polys, 180 lines) | 0.1s |
| graph (conflate, node, 16,345 edges) | 1.2s |
| emit_graph (1,053 KB payload) | 0.3s |
| terrain (110 DEM tiles, 229 KB shade) | 3.8s |
| glyphs (107 SDF glyphs) | 0.4s |
| imagery (380 tiles, budget table) | 30.7s |
| bundle + build_app | 0.1s |

### The lesson, honestly

I wrote landmine 32 at take 10 — *"a pipeline with a hand step in the middle is
not a pipeline"* — and then shipped three more hand steps across takes 11 and 12
without noticing, because everything kept working. **Writing a landmine down does
not prevent it. Only running the thing from scratch does.**

Recorded as landmine 36 with a rule attached: any take that adds a pipeline step
must be followed by a clean run before shipping.

**DEFERRED this cycle:** A14 3D terrain and slope. A17 voice. The APK still needs
a device — but a clean checkout now genuinely produces the app.

---

## Take 12 — 2026-08-19 — The repo now builds the app

**The finding that mattered:** `www/` still held the take-2 spike. Eleven takes of
work lived only in standalone HTML files the repo could not produce, and the CI
workflow was still wired to planetiler and PMTiles. **A push today would have
built an APK of the take-2 spike.**

Nothing caught it. Every gate check asked whether files existed — none asked
whether they were *current*. The pipeline-provenance check passed happily because
`www/app.js` was a real file with no remote origins; it was simply the wrong app.

### One source, two outputs

`src/app.html` is now the only place the app exists. `tools/build_app.py` emits:

- **split** → `www/index.html` + `www/app.js` + `www/bundle/` — what Capacitor packages
- **single** → one self-contained HTML — what can be opened without a build

Same source, so they cannot drift again.

### The bundle model is now live in the app, not just in a tool

Split mode does not inline the payloads. The app boots by reading
`bundle/manifest.json` and honouring its three states (landmine 34):

- **complete** — everything present
- **partial** — required artifacts good, optional absent. Navigates fine, and the
  app *names the missing layers* in the panel and flips the badge to PARTIAL
- **unusable** — a required artifact missing. The region is refused with a plain
  explanation rather than rendered with holes

These are same-origin reads of files already on the device, so the NET guard stays
green — exactly the distinction PROTOCOL §8 was rewritten to make at take 10.

### A bug caught by simulating, not by reading

The loader required kinds `graph / terrain / glyphs`; `bundle.py` emits
`network / terrain / labels`. **Every region would have been refused as
incomplete.** The app would have shipped showing "Region incomplete" on a
perfectly good bundle. Found by feeding real manifests through the state machine
with artifacts removed, not by reading either file. The gate now cross-checks the
loader's required kinds against what `bundle.py` actually emits.

### CI rewritten

The `bundle` job runs the real pipeline — `ingest → graph → emit_graph →
terrain → glyphs → imagery → bundle → build_app` — then gates before packaging.
planetiler and PMTiles are gone; the app renders from the routable graph, so
vector tiles were building something nothing consumed.

### Two new gate checks

- **`check_current`** — `src/app.html` must name the current take, `www/app.js`
  must read a bundle manifest, and the loader's required kinds must exist in
  `bundle.py`.
- **`check_style`** rewritten to scan `src/app.html` for `text-font` rather than a
  `style.json` that no longer exists, preserving landmine 4 and 30 coverage.

**DEFERRED this cycle:** A14 3D terrain and slope. A17 voice. Resumable region
download. The APK itself still needs Jacob's device — but for the first time the
repo would actually build the right thing.

---

## Take 11 — 2026-08-19 — Search, directions, region bundles

**Shipped:** `apex-offroad-take11.html`, 3.16 MB. Offline search, turn-by-turn
directions, and `tools/bundle.py` — the mechanism §8's invariant actually needs.

### A15 CLOSED — offline search

Landmine 19: vector tiles only hold what is in the viewport, so you cannot search
them for somewhere you are not already looking. The index is separate and built
at load from data already in the payload — **2,543 entries** that had been sitting
there unsearchable since take 6:

| kind | count |
|---|---|
| junction descriptors | 1,486 |
| roads | 540 |
| trails | 412 |
| trail numbers | 97 |
| places | 8 |

Ranked exact → string-prefix → word-prefix → substring, then by kind, then by
length. `tmm` finds The Meadows Motorcycle Trail; `h58` finds H58-1; `4460` finds
FR 4460; `pink` finds the Pink Store.

### Turn-by-turn (ROADMAP 5.6)

A blue line is not an instruction. Someone lost and tired needs words they can
read once and act on — and a turn list is also what you would relay over a radio.
Consecutive edges on the same way collapse into one step.

Bull Gap → Pink Store: **47 edges become 5 steps.** *Start on Bull Gap Hill Climb
· 4276 · 0.60 mi / Turn right Weeks Road / Turn left Fowler Road / Turn right
Curtisville Road / Turn left South Mount Tom Road.* Steps flag anything illegal
for the current machine and anything that climbs more than 8 ft.

### A16 — region bundles, with the failure case designed first

`tools/bundle.py` builds a region directory plus a manifest carrying SHA-256 per
artifact, and a bundle hash over the artifact hashes so a manifest cannot be
edited to match a corrupted file.

**The interesting question was never the happy path.** It is what the app does
when a region is half downloaded. Every artifact declares whether it is REQUIRED,
which gives three states:

- **complete** — everything present and hashing correct
- **partial** — required artifacts good, some optional absent. Still navigable,
  and the app must *name* which layers are missing
- **unusable** — a required artifact missing or corrupt. Refuse the region

That distinction is a safety decision, not a UX one. A region without imagery is
perfectly rideable. **A map with holes in it is worse than no map, because you
trust it.**

Current bundle: 1.88 MB — graph 1,053 KB, terrain 257, glyphs 61 required;
water, hillshade, imagery optional. Both failure modes were exercised: appending
one byte to `graph.json` gives UNUSABLE and exit 1; deleting `imagery.jpg` gives
PARTIAL and exit 0.

### Verified (`tools/verify11.py`)

Search ranking mirrored in Python and spot-checked across ten queries. Directions
checked structurally: the leg walk **ends on the routed target node**, and step
mileage matches routed mileage to **1.78e-15**. A wrong turn instruction is worse
than none — it reads as authoritative and gets followed.

**DEFERRED this cycle:** A14 3D terrain and slope. On-device provisioning UX —
`bundle.py` defines the format and the states, but nothing consumes it yet.
Voice for the turn list. Nothing toward the APK.

---

## Take 10 — 2026-08-19 — PROTOCOL §8 revised · satellite · A8 closed

**Shipped:** `apex-offroad-take10.html`, 3.16 MB. Satellite basemap, still zero
runtime requests.

### The protocol was wrong and Jacob caught it

§8 said no shipped asset may reach a remote origin, full stop. That conflated two
different phases and was quietly incoherent — every tile, DEM sample and agency
record has to come from somewhere, and `tools/` had been fetching all along while
the gate only policed `www/`.

**Rewritten:** provisioning may use the network; the field may not. What makes
that safe rather than aspirational is the invariant — *after provisioning
completes and verifies, the app must be provably complete, tested by a cold start
in airplane mode* — plus three controls: no remote origins in runtime assets, the
runtime NET guard, and **every provisioning host declared** in `docs/PROVISION.md`
with purpose, licence and refresh cadence.

`tools/manifest.py` generates that manifest and scans every tool and workflow for
hosts. The gate now refuses an undeclared one. An undeclared fetch is precisely
the thing that passes on the bench with wifi on.

### A8 CLOSED — measured, not extrapolated

USGS ImageryOnly, NAIP-derived, public domain. Five tiles sampled per zoom across
the AOI rather than one:

| zoom | m/px | tiles | AOI | statewide |
|---|---|---|---|---|
| z13 | 13.6 | 110 | 2 MB | 0.4 GB |
| z14 | 6.8 | 380 | 8 MB | 1.8 GB |
| z15 | 3.4 | 1,482 | 37 MB | 8.6 GB |
| **z16** | **1.70** | **5,772** | **159 MB** | **36.6 GB** |

**z16 is the useful ceiling and it costs 159 MB for a riding area** — one wifi
download the night before. Statewide at the same zoom is 36.6 GB, which settles
it permanently: imagery is per-region, always. z12-13 are cheap enough to ship
with the app as a fallback.

My take-8 estimate for the AOI at z16 was ~200 MB; measured is 159 MB. Close, but
the statewide figure is the one that actually decides the architecture and it was
never computed before.

**Correction:** the take-8 m/px figures in my own notes were wrong by a factor of
256 — I divided by tile size twice. z16 is 1.70 m/px, not 0.01.

### Satellite in the app

Basemap chip cycles Map / Satellite / Hybrid. In satellite mode a pale casing
goes under every trail line, because dark ink on dark jack pine is unreadable and
a trail you cannot see is not on the map. Hillshade drops to 0.16 over imagery
rather than off — relief still reads, it just stops fighting.

### The manifest found a hole immediately

Overpass was declared but nothing in the pipeline fetched it: `aoi.json` had been
produced by an ad-hoc curl at take 5 and every take since read a file a clean
checkout could not rebuild. The pipeline-provenance gate passed the whole time
because the *file* existed. `ingest.py` now fetches OSM. **A pipeline with a hand
step in the middle is not a pipeline** — landmine 32.

**A gate bug too:** the new provisioning check was named `check_manifest`, which
shadowed the existing Android-manifest check. Both were in the call tuple, so one
ran twice and the other never. Renamed to `check_provision`. Two checks, one
silently gone — landmine 33.

**DEFERRED this cycle:** A14 3D terrain and slope. A15 offline search. Region
bundle download UX (1.2/1.3/2.9), which §8 now makes the central architecture
rather than a nicety. Nothing toward the APK.

---

## Take 9 — 2026-08-19 — Labels · A3 closed

**Shipped:** `apex-offroad-take9.html`, 2.79 MB. **The map has text.** Plus
nearest-pavement and the about screen from A13.

**A3 CLOSED — the gap I had called #1 since take 1 while shipping 1,049 unused
names.** Landmine 4: MapLibre fetches glyph ranges from a `glyphs` URL and ships
no fallback, so symbol layers with no glyphs render silently blank. A CDN is
forbidden (PROTOCOL §8), so the pack had to be generated.

`tools/glyphs.py` builds SDF glyphs from a TTF and hand-encodes the Mapbox glyph
protobuf — varints and length-delimited fields, no protobuf dependency. 107
glyphs, 46 KB, 61 KB as base64.

**Served from a static `data:` URI, not a protocol handler.** MapLibre substitutes
`{fontstack}/{range}` only when the placeholders are present; without them it
requests the URL as-is and gets the same pack every time. One fontstack makes
that work and removes a moving part between the map and its text. `data:` is
already allowed by the offline guard.

**Typeface: NationalPark-Bold**, the face cut for National Park Service routed
signage. On a map of the Huron National Forest that is the subject's own
vernacular rather than a default sans. OFL, so it ships inside an APK legally.

**Two bugs the label work exposed, both at source:**

1. **Doubled parentheses on 1,066 edges.** `short()` wrapped a trailing code in
   parens without checking whether it already had them, producing *"The Meadows
   Motorcycle Trail ((TMM))"*. It had been in the data since take 5 and was
   invisible until something rendered it. Fixed with an `isalnum()` guard; 0
   remaining.
2. **Database names are not sign names.** *"The Meadows Motorcycle Trail (TMM)"*
   will not fit along a two-track at z14. Map labels now use the abbreviation
   plus the USFS number — **"TMM · H58-8"**, **"MAT · H57-6"**, **"RCT"** — which
   is shorter *and* closer to what is actually nailed to the post. The inspect
   card still shows the full name. Median label length dropped to 10 characters.

**Text carries provenance too.** Designated line gets its name and number;
advisory OSM line gets neither. **12,387 of 16,345 edges carry text.**

**Also shipped from A13:** 4.6 nearest pavement (straight-line bearing to the
closest thing a truck can reach you on — answers "which way do I walk" when the
bike will not move, and needs no router), and 4.12 the about screen, which states
plainly that this is not an emergency device, that the MVUM is the legal
authority, and that private property lines are not shown.

**Verified (`tools/verify9.py`):** the pack round-trips — thresholding the SDF at
192 reproduces the rendered glyph mask with **100.00% agreement**, worst case
100.00%. Zero bitmap size mismatches. And every one of the **68 distinct
characters** the map can render is present in the pack — a missing glyph renders
as a silent gap with no fallback offline, so coverage is proven rather than
assumed.

**DEFERRED this cycle:** A14 3D terrain and slope. A5 tiles in app storage.
Offline search (5.1) despite now having 1,049 indexed names. Turn-by-turn.
Nothing toward the APK — takes 5 through 9 are all viewers.

---

## Take 8 — 2026-08-19 — Terrain · A12 closed

**Shipped:** `apex-offroad-take8.html`, 2.72 MB. Hillshade, elevation everywhere,
climb-aware routing, elevation profiles. Still zero outbound requests.

**A12 CLOSED.** Public Terrarium-encoded DEM tiles (3DEP over CONUS) at z13,
110 tiles covering the AOI at ~13.6 m/px. **One ingest, four products** — node
elevations, per-edge climb, elevation profiles, and the hillshade underneath.
That is landmine 20 handled deliberately rather than discovered late.

**Relief across the AOI is 199 m — 879 to 1503 ft.** Enough to matter. Bull Gap
is a sand hill climb; a router that ignores elevation ignores the thing riders
actually feel.

**Shipped this take:**
- Hillshade inline as a 227 KB JPEG image source, multiplied under the sand at
  0.42 opacity so trails stay the loudest thing on screen. Toggle with ⛰ Relief.
- `Easiest` is now climb-aware: 1 m of climb is charged like 12 m of distance.
- New **Least climbing** profile charging climb at 45×.
- Elevation profile sparkline on every route card. A 12 mi route with 900 ft of
  climbing is a different ride from 12 mi with 200, and the shape lands where the
  number does not.
- ETA now includes climbing time, roughly a minute per 100 ft up.
- Elevation on the coordinate readout, the dispatch card and the inspect card.

**The 724 KB hillshade problem.** First render came out 724 KB — unusable inline.
Cause was not resolution: Terrarium quantises to 1/256 m and resampled 3DEP
carries stair-step noise, so shading it raw produced high-frequency speckle that
JPEG cannot compress. Fix was to **blur the elevation, not the shade**, which
improved the look and the size together. 227 KB at 850 px. Node sampling still
reads the unblurred grid, so distances and climb stay honest. Landmine 28.

**PIL cannot Gaussian-blur a float image**, which forced a rewrite of the decode,
blur and shade path in numpy. That turned out better anyway — vectorised, and the
whole pipeline is now about twenty lines instead of three nested loops.

**Verified headlessly (`tools/verify8.py`):**
- 9,285 nodes sampled, zero null or zero samples.
- Landmarks read true: Mio 965 ft (lowest — it sits in the Au Sable valley),
  Bull Gap 1070, Mack Lake 1175, Rose City 1217, Pink Store 1240.
- **Climb conservation exact: 0/16,345** profiles disagree with their stored
  gain/loss totals.
- Profile endpoints against node elevations: median mismatch 0 m, p95 1 m.
- Network total gain 88.9k ft.

**Honest limitation, landmine 29:** the steepest *segment-averaged* grade in the
network is 3.4%, which is not what Bull Gap feels like. Long edges average a short
steep pitch into nothing. Per-edge climb is right; per-edge *grade* understates.
Anything that reports "steepness" must work from the profile, not the average.

**DEFERRED this cycle:** 3D terrain (needs the encoded DEM shipped, not just the
shade). Slope shading. A13's four unbuilt Phase 4 items. Nothing toward the APK —
takes 5 through 8 are all viewers.

---

## Take 7 — 2026-08-19 — Phase 4 safety core

**Shipped:** `apex-offroad-take7.html`, 2.17 MB. Breadcrumb recording, back-to-truck,
retrace, off-route alert, dispatch card. All offline, all verified headlessly.

**Built in AGENDA A11 order, not roadmap order.** A11 said retrace ships before
anything else in Phase 4 because it needs no router, no network and no agency data.
That held: `retrace` touches nothing but the recorded track. If the graph were
corrupt, the tiles missing and the DNR service gone, it would still get you out.

**Shipped this take:**

| Task | What it does |
|---|---|
| 4.1 | Breadcrumb records automatically, 7 m jitter gate |
| 4.2 | Truck pin drops itself where recording starts |
| 4.3 | Back-to-truck distance + compass bearing, live on the rail |
| 4.4 | Off-route alert at ~260 m, haptic first then visual |
| 4.7 | Dispatch card |
| 4.11 | REC badge counts crumbs — a silent recorder is a failed one |
| 4.14 | **Retrace** |

**A7 gets a better answer than digitising.** Junction numbers are not published
(closed negative, take 4) and inventing our own would produce numbers nobody could
check against a post. Instead junctions are named by what meets there:
*"Ogemaw Hills Route (OHR) × Rose City Trail (RCT)"*. Verifiable from the map and
from the ground, needs no digitising. **3,706 junctions named** — 3,332 with two
ways meeting, 374 with three.

**Limitation, recorded as landmine 26:** these descriptors are not unique. OHR
crosses RCT in several places, so the same string appears more than once. The
dispatch card always leads with decimal degrees and gives the junction as
supporting detail, never as the primary fix.

**Ride simulator added** — a harness, not a product feature, for the same reason
`verify6.py` exists. Phase 4 cannot be exercised without a bike and a tank of gas
otherwise. `▶ Ride it` follows the selected route laying a track;
`😖 Wrong turn` diverts at the next junction so the off-route alert can be seen
firing rather than assumed to work.

**Verified headlessly (`tools/verify7.py`):**
- Bearings reciprocal: Bull Gap → Pink Store 217.1° SW, reverse 37.1° NE.
- Retrace lossless: forward 3.5791 mi, reversed 3.5791 mi, delta 0.00e+00, and
  the reversed track ends exactly on the truck.
- Jitter gate: 240 noisy fixes over a 3.579 mi track produced 77 crumbs and
  3.659 mi — **+2.2%** inflation under heavy noise.

**A bug caught by the syntax check:** an earlier patch double-escaped an apostrophe
inside a JS string literal, which terminated the string and broke the entire
script. Nothing about the page would have hinted at the cause. Extracting the
inline script and running `node --check` against stubs is now part of the build.

**DEFERRED this cycle:** terrain and elevation entirely — no DEM, so no climb
costs, no elevation profiles, no hillshade. 4.5 (nearest pavement), 4.9 (low
power), 4.20 fuel is take 6 only. Nothing toward the APK.

---

## Take 6 — 2026-08-19 — Conflation solved · routable graph · Return Home works

**Shipped:** `apex-offroad-take6.html`, 2.10 MB. Routing, machine legality and
Return Home, all offline, all from agency data.

### Conflation — PROVEN, and the answer was not what I assumed

Densified every line to 20 m and measured USFS against DNR within 25 m:

| | total | duplicated | |
|---|---|---|---|
| USFS trails | 116.5 mi | 110.4 mi | **94.8%** |
| USFS roads | 386.8 mi | 48.9 mi | **12.6%** |

The two agencies are not redundant the way landmine 11 implied. USFS *trails* are
almost entirely the same physical lines the DNR already publishes — Michigan
designates trails running on Huron NF ground, so both publish them. USFS *roads*
are 87% additive and are most of the network's mileage.

**So the rule is asymmetric:** drop duplicate USFS trails, keep every USFS road,
carry the USFS trail number onto the DNR feature it matched. 43 duplicates
dropped, **41 trail ids merged** — DNR trails now know they are H57-7, H58-1 and
so on, which is what you would read to a dispatcher. Neither source alone had both
the closure status and the number.

### Routable graph — PROVEN

Vertices snapped to a ~12 m grid, lines split where two or more meet, then 132
dangling ends pulled onto junctions within 30 m. Result: **9,285 nodes, 16,345
edges, 2,114 network miles, 49 components — the largest holding 99.4% of edges and
99.2% of mileage.** One connected network, which is the precondition for routing
at all and was genuinely uncertain beforehand.

### Return Home — ROADMAP 4.13-4.24, working

Four profiles over that graph: Fastest, Easiest, Pavement soonest, Shortest.
Bull Gap to the Pink Store on a dirt bike: 12.3 mi / 27 min fastest against
11.6 mi / 33 min shortest, and the shortest spends 7.5 mi off pavement versus 2.3.
The tradeoff is real, not decorative.

Also shipped: fuel range (4.20) flagging routes past what is in the tank, sunset
maths (4.21) warning about arriving after dark, route confidence (4.23) reporting
how much of a route is designated versus an OSM guess.

**Machine legality (7.1 / 7.4) is live**, driven by MVUM and DNR width data rather
than inference. Closed segments are never routed through.

### A bug the headless verifier caught, not the browser

`nearestNode` snapped to the geometrically closest node regardless of machine, so
a 72" side-by-side landed on a 50" trailhead and every profile returned "no legal
route". Wrong, and confidently wrong — a legal route existed. Fixed by snapping
only to nodes carrying at least one edge legal for the machine. Side-by-side now
routes 11.6 mi / 20 min. Cards also disclose off-network distance to the pins.

Written up as **landmine 24**. `tools/verify6.py` mirrors the JS cost functions in
Python precisely so the two can disagree out loud.

### Process note

The take-6 doc write silently did not run on the first attempt: a shell `&&` chain
short-circuited on a failed copy and skipped the whole block. The gate caught it —
five stamp failures — which is the second time in three takes it has caught
something invisible to reading. This is exactly what PROTOCOL §7 is for.

**DEFERRED this cycle:** retrace (4.14) needs a recorded track and take 6 is a
viewer. Turn-by-turn. Junction digitising. Imagery. Nothing toward the APK.

---

## Take 5 — 2026-08-19 — Real agency data in the app · A9 closed

**Shipped:** `apex-offroad-take5.html`, 1.45 MB, self-contained. First build with
authoritative data rather than OSM alone.

**A9 CLOSED — USFS MVUM, PROVEN:**
`apps.fs.usda.gov/arcx/rest/services/EDW/EDW_MVUM_01/MapServer`, layer 1 roads /
2 trails. In the AOI: **366 roads, 46 trails.**

**MVUM is richer than the DNR for legality.** Per-vehicle-class open/closed with
date ranges, all populated: `motorcycle` 46/46 open, `atv` 37/46, and the >50"
classes 3/46. `id` carries trail designations (H57, H58-1, H58-8) and `name`
resolves (MEADOWS - MCCCT, MACK LAKE LOOP TRAIL, MEADOWS-M33 TRAIL). This makes
ROADMAP 7.4 vehicle-profile filtering a data join, not an inference — the DNR's
single width field can't express "motorcycle yes, ATV no" and the MVUM can.

**Ingest built** (`tools/ingest.py`): pulls DNR layers 11/12/13/14 and MVUM 1/2,
normalises to one schema, stamps `src` and `auth` on every feature.
**648 features, 648 named.** After RDP: 651 lines, 11,081 coords, 191 KB.

**Provenance rendering proved (ROADMAP 7.2).** OSM tracks and paths now draw pale
and dashed as advisory; DNR and USFS lines draw solid and coloured by designation
class. Standing next to each other, the difference between "legally designated"
and "somebody drew this in OSM" is visible at a glance. This was scheduled for
Phase 7 and came almost free once provenance was in the schema.

**Tap-to-inspect added**, which proves the attribute pipeline end to end: name,
source, trail id, width class, per-vehicle status, season, licence.

**PROVEN:** 246 DNR + 412 USFS features coexist in one style with no conflation
yet, and the duplicate-geometry problem is now visible rather than theoretical —
landmine 11 confirmed by eye at Bull Gap.

**DEFERRED this cycle:** conflation itself (3.11). Junction digitising (3.8).
Imagery sizing. Nothing built for the APK path; take 5 is a viewer, not the app.

---

## Take 4 — 2026-08-19 — Named APEX Off-road · DNR data reconnaissance · Return Home

**Named.** APEX Off-road. appId `com.apexoffroad.app`.

**Reconnaissance — the point of this take.** Jacob can't build or test for a while,
so the unblocked work is data. Went to the live Michigan DNR ArcGIS service and
inspected it rather than reading about it.

**Service — PROVEN:**
`https://gisagodnr.state.mi.us/arcgis/rest/services/DNR/DNRTrailsOPENDATA/FeatureServer`
23 layers. Six matter: 11 ORV Routes, 12 ORV Trails, 13 Motorcycle Trails,
14 MCCCT, 0 Temporary Closures, 1 Temporary Reroutes.

**AOI coverage — PROVEN by query:**

| Layer | Features in AOI |
|---|---|
| ORV Routes (72") | 15 |
| ORV Trails (50") | 159 |
| Motorcycle Trails (24") | 25 |
| MCCCT | 47 |
| Temporary Closures | 20 |

164.1 miles of ORV trail. Named trails resolve correctly: Mack Lake Motorized
(MAT), The Meadows (TMT), Rose City (RCT), Meadows-to-Rose City (MRT), Ambrose
Lake-to-Rose City (ART), Alcona County (ACT).

**Attributes that are genuinely populated — PROVEN:**
- `TrailWidthFeet` — 116x "50 Inches Or Less", 43x "12 Feet And Over".
  ROADMAP 3.6 and 7.1 need no derivation. The data is just there.
- `OpenClosedStatusORV` — 148 Open, 11 Temporarily Closed. Live closures, 7.3.
- `LicenseType` — ORV licence + trail permit vs snowmobile permit. 7.7.
- `TrailOnRoad` — distinguishes National Forest Road / State Forest Road. This is
  a direct assist to conflation (3.11), which I had assumed would be pure geometry.

**Attributes that are dead — PROVEN, and this is a trap:**
- `TrailTreadType` — 159/159 null (`-1`)
- `SpecialRestrictionType` — 159/159 null (`-1`)
- `SurfaceType` — 159/159 "Dirt Natural". No sand vs hardpack distinction, which
  is exactly the distinction that matters here. ROADMAP 6.5 cannot use this.

**A7 ANSWERED — NEGATIVE.** No junction/marker number field exists in any of the
23 layers, and the DNR services folder contains only trails and survey corners —
there is no marker point layer. Junction numbers live on the printed PDF maps and
the physical posts, not in the published GIS. ROADMAP 3.8 is therefore not a
schema question, it is a digitising job. Rescoped and downgraded; still worth
doing, but it is no longer nearly free.

**Return Home added** at Jacob's request as ROADMAP 4.13–4.24, with fuel range
and daylight awareness, which neither onX nor AllTrails does.

**DEFERRED this cycle:** USFS MVUM reconnaissance (same treatment, next). No tiles
built from DNR data yet. No conflation attempted. Imagery still unmeasured.

---

## Take 3 — 2026-08-18 — Cross-project scrub + full feature backlog

**Scrubbed.** PROTOCOL.md carried five references to a prior unrelated project as
provenance for its rules. Removed — the rules now stand on their own terms. Also
renamed the Capacitor appId from a carried-over identifier to `com.offroadmi.app`
and retitled the CI artefacts.

**Why it mattered:** provenance in a rules document is not neutral. It invites a
future reader to go look up context that has nothing to do with this app, and it
made the protocol read as borrowed rather than owned.

**ROADMAP rewritten as a full backlog.** Now carries an explicit feature-parity
matrix against onX Offroad and AllTrails, since Jacob's stated bar is "if either
of them has it, I probably want it." Phases grew from 6 to 9: basemaps/imagery
and search/navigation were previously folded into other phases and were too big
to sit there.

**Reframed around the actual driver.** Jacob has been lost in these woods. Phase 4
is renamed and expanded accordingly, and off-route alerting was promoted from
"nice to have" to a named exit criterion.

**Workflow AOI corrected** to the take-2 settled bbox `-84.30,44.42,-83.90,44.72`,
`TILES_KEY` bumped to `neml-v1` so the stale Bull-Gap-only cache is not reused.
This was called out as deferred in take 2.

**PROVEN this take:** nothing new about the system. No device test has run.

**DEFERRED this cycle:** all Phase 1+ implementation. Satellite imagery sizing is
estimated, not measured (landmine 18). No DNR or USFS data has been touched yet.

---

## Take 2 — 2026-08-18 — Standalone inline build

**Shipped:** `bullgap-mio-rosecity.html`, 1.27 MB, fully self-contained.
MapLibre, CSS, data and logic all inlined. Zero runtime requests.

**Why:** Jacob has no laptop. Needed something testable on the phone today
without CI, sideloading or a server.

**AOI settled at `-84.30, 44.42, -83.90, 44.72`.** First proposal was
`-84.25,44.50,-83.85,44.75` (missed Rose City). Jacob's screenshot implied
`-84.40,44.27,-83.65,44.71`, which pulled 12,054 features — too big to inline.
Landed on the same footprint as the original, nudged south. Covers Bull Gap,
the Meadows, Mio, Luzerne, Mack Lake, the Pink Store, Rose City.

**Data:** Overpass, 2,787 features / 55,693 coords. RDP at ~8 m and 1e-5
quantisation cut it to 21,640 coords. Delta-encoded ints -> 182 KB payload.

**PROVEN this take:**
- Chrome blocks geolocation on `file://` (landmine 2).
- The full screenshot block is ~4.3x the feature count of the AOI — the point
  where inline GeoJSON stops being viable (landmine 8).

**UNKNOWN, unchanged:** everything in Phase 0.2–0.5. No device numbers yet.

**DEFERRED this cycle:** the APK path entirely. Labels. Any DNR or USFS data.
The Fold inner-screen layout, by Jacob's explicit instruction.

---

## Take 1 — 2026-08-18 — Spike scaffold + CI

**Shipped:** `bullgap-spike/` — Capacitor + MapLibre + PMTiles scaffold, and a
GitHub Actions workflow (bundle -> pages -> apk) that builds tiles with
planetiler, deploys Stage 0 to Pages and publishes a signed-debug APK to
Releases. Phone-only: four hand-created files, no laptop.

**Architecture chosen:** Capacitor + MapLibre GL JS + PMTiles, shipped as a
sideloaded APK. Rejected: PWA (fails background GPS under One UI), Kotlin +
MapLibre Native (better ceiling, whole new language), Flutter (new language, no
gain).

**Deliberate design:** the spike splits its unknowns instead of testing them
together. Stage 0 (browser) answers renderer perf; Stage 1 (APK) answers Range
support. Testing both at once would leave a failure unattributable.

**DEFERRED:** labels, ORV data, routing, everything in Phases 1–6.
