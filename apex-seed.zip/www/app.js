/* Boot from the region bundle. PROTOCOL §8: provisioning may use the
   network, the field may not -- these are same-origin reads of files already on
   the device, which is why the NET guard stays green.

   The manifest drives it. A region missing an optional layer still rides
   (landmine 34); a region missing a required one is refused rather than shown
   with holes, because a map you cannot trust is worse than no map. */
(function(){
var WATER,GR,TR,SHADE,SAT,SATB,GLYPHS,BUNDLE={state:'unknown',absent:[]};

function j(u){return fetch(u).then(function(r){
  if(!r.ok)throw new Error(u+' '+r.status);return r.json()})}
function blob(u){return fetch(u).then(function(r){
  if(!r.ok)throw new Error(u+' '+r.status);return r.blob()})
  .then(function(b){return URL.createObjectURL(b)})}

function fatal(msg,detail){
  document.body.innerHTML='<div style="padding:26px;font:400 14px/1.6 Barlow,'+
   'system-ui,sans-serif;color:#F5EFE2;background:#14120F;height:100%">'+
   '<div style="font:700 12px/1 Barlow,system-ui,letter-spacing:.17em;text-transform:uppercase;'+
   'color:#E2570F;margin-bottom:14px">APEX ORV</div>'+
   '<b style="font-size:17px">'+msg+'</b><br><br>'+
   '<span style="color:#9A9184">'+detail+'</span></div>'}

/* These names must match the `kind` column in tools/bundle.py ARTIFACTS.
   They did not at take 12 — the loader wanted graph/terrain/glyphs while the
   manifest emitted network/terrain/labels, so every region would have been
   refused as incomplete. Caught by simulating a partial bundle, not by reading. */
var REQ={network:1,terrain:1,labels:1};
var OPT=['imagery','relief','hydro'];

j('bundle/manifest.json').then(function(man){
  var have={};man.artifacts.forEach(function(a){have[a.kind]=a.path});
  var missingReq=Object.keys(REQ).filter(function(k){return !have[k]});
  if(missingReq.length){
    fatal('Region incomplete',
      'This region is missing '+missingReq.join(', ')+'. It has not been shown '+
      'rather than shown with gaps in it — a map with holes is worse than no map. '+
      'Re-download the region on wifi.');
    throw new Error('required artifact missing');}
  BUNDLE.absent=OPT.filter(function(k){return !have[k]});
  BUNDLE.state=BUNDLE.absent.length?'partial':'complete';
  BUNDLE.name=man.name;BUNDLE.built=man.built;BUNDLE.centre=man.centre;
  BUNDLE.bbox=man.bbox;BUNDLE.anchors=man.anchors||[];BUNDLE.region=man.region;
  BUNDLE.hash=man.bundle_sha256;BUNDLE.tiles=man.imagery_tiles||null;
  return Promise.all([
    j('bundle/'+have.network), j('bundle/'+have.terrain), j('bundle/'+have.labels),
    have.hydro?j('bundle/'+have.hydro):Promise.resolve({l:{}}),
    have.relief?blob('bundle/'+have.relief):Promise.resolve(''),
    have.imagery?blob('bundle/'+have.imagery):Promise.resolve(''),
    Promise.resolve({b:man.imagery_bounds||[0,0,0,0]}),
    have.context?j('bundle/'+have.context):Promise.resolve(null),
    have.address?j('bundle/'+have.address):Promise.resolve(null),
    have.other?j('bundle/'+have.other):Promise.resolve(null),
    /* A110. Optional and absent-safe: an older bundle has no places artifact
       and the app simply draws no pins, rather than refusing the region. */
    have.places?j('bundle/'+have.places):Promise.resolve(null),
    /* A87. Optional and absent-safe, exactly like places: an older bundle has
       no contour artifact and the map simply has no contour lines. */
    have.contour?j('bundle/'+have.contour):Promise.resolve(null),
    /* A115. Optional and absent-safe like the rest. */
    have.paddle?j('bundle/'+have.paddle):Promise.resolve(null),
    have.ground?j('bundle/'+have.ground):Promise.resolve(null)]);
}).then(function(r){
  GR=r[0];TR=r[1];GLYPHS=r[2];WATER=r[3];SHADE=r[4];SAT=r[5];SATB=r[6].b;CTX=r[7];ADDR=r[8];SHOW=r[9];
  POIS=r[10];CONT=r[11];PADDLE=r[12];LAND=r[13];
  start();
}).catch(function(e){
  if(String(e.message).indexOf('required artifact')<0)
    fatal('Could not load this region',String(e.message)+
     '<br><br>The bundle may be corrupt. Re-download it on wifi.');
});

function start(){
var el=function(i){return document.getElementById(i)};
var remoteHits=0,netB=el('b-net');

function isRemote(r){try{var u=new URL(r,location.href);
 if(['data:','blob:','file:'].indexOf(u.protocol)>=0)return false;
 return u.origin!==location.origin}catch(e){return false}}
function watch(r){if(!isRemote(r))return;remoteHits++;
 netB.textContent='NET '+remoteHits+' REMOTE';netB.className='badge bad'}
var nf=window.fetch&&window.fetch.bind(window);
if(nf)window.fetch=function(i,o){watch(typeof i==='string'?i:(i&&i.url)||'');return nf(i,o)};
var no=XMLHttpRequest.prototype.open;
XMLHttpRequest.prototype.open=function(m,u){watch(u);return no.apply(this,arguments)};
netB.textContent='NET CLEAN';netB.className='badge good';

function decode(a){var p=[],x=0,y=0;for(var i=0;i<a.length;i+=2){x+=a[i];y+=a[i+1];
 p.push([x/1e5,y/1e5])}return p}

/* ── graph ─────────────────────────────────────────────────────────────── */
/* ══ MACHINE LEGALITY ═══════════════════════════════════════════════════════
   Take 80. `MACHINE[m].ok` is a CLASS allow-list and it encodes the DNR's rules
   correctly, because the DNR expresses width in the layer a feature comes from:
   a 24" trail is class moto24, a 50" trail is trail50, and the allow-lists
   follow. Nothing to fix there.

   The Forest Service does not work that way. It publishes ONE class of trail
   and puts the per-vehicle rules in the attributes. In this region 25 fstrail
   edges (3.13 mi) carry `moto: open` with `atv` unset, and their MVUM symbol
   reads "Trails open to motorcycles, Yearlong". A quad is allowed on class
   fstrail, so the router would put one on a motorcycle trail — and the feature
   card printed "Moto open" beside it, so the app was displaying the fact and
   ignoring it at the same time.

   Where the source states a per-vehicle rule, that rule governs. Where it does
   not, the class rule stands. Both the router and the snapper go through here,
   because a snap that lands on an illegal node reports "no route" when a legal
   one exists, or worse, starts you on one (take 24).

   sxs has no stored flag: the MVUM's `other_ohv_gt50inches` and
   `highclearancevehicle` are fetched by ingest and dropped before the bundle.
   It falls back to the class rule, which excludes fstrail entirely, so it is
   conservative rather than wrong. Recorded as open — see A86. */
var MACH_FLAG={bike:'moto',quad:'atv',sxs:null};

/* ══ SPECIAL RESTRICTIONS (A101) ════════════════════════════════════════════
   The DNR publishes a free-text restriction on 180 features statewide. It is
   real law: 67 of them read "Off road motorcycles are prohibited", which is
   Jacob's machine.

   ENUMERATED, not pattern-matched. There are exactly nine distinct strings in
   the whole state — a table I can read and check by eye, against a regex on
   legal prose that would silently mis-classify the tenth. When the DNR adds
   one, it lands in `unknown` below and is SHOWN to the rider rather than
   guessed at.

   THE RULE: this table may only ever take access away, never grant it. A string
   we do not recognise restricts nothing and is displayed verbatim, because
   telling a rider what the sign says is honest and inventing a reading of it is
   not. Zero features in the Bull Gap box carry one — this exists so the
   machinery is here before A72 widens the region, not after. */
var RESTRICT=[
  {m:'Off road motorcycles are prohibited',
   ban:['bike'], season:'May 1 – Nov 1',
   say:'Off-road motorcycles are prohibited. ORVs under 65 inches, May 1 – Nov 1.'},
  {m:'including off road motorcycles only between the dates of May 16th and March 14th',
   ban:['sxs'], season:'May 16 – Mar 14',
   say:'ORVs under 65 inches including motorcycles, May 16 – Mar 14.'},
  {m:'including off road motorcycles only',
   ban:['sxs'], say:'ORVs under 65 inches, including motorcycles.'},
  {m:'ORVs Less Than 65 Inches Only',
   ban:['sxs'], say:'ORVs under 65 inches only.'},
  {m:'MDOT ROW',
   ban:[], season:'May 1 – Nov 30',
   say:'Highway right-of-way connector, open May 1 – Nov 30.'},
  {m:'4x4 And High Clearance Required',
   ban:[], say:'4x4 and high clearance required — rough going.'},
  {m:'High Clearance Required',
   ban:[], say:'High clearance required — rough going.'},
  {m:'Snowmobile Season',
   ban:[], say:'Snowmobile season December 1 – March 31.'}
];

function restrictOf(e){
  var a=attrs(e),t=a.rst;
  if(!t)return null;
  for(var i=0;i<RESTRICT.length;i++)
    if(t.indexOf(RESTRICT[i].m)>=0)return RESTRICT[i];
  /* Unrecognised: show the source's own words. Never guess. */
  return {m:null,ban:[],say:t,unknown:true}}

function machineLegal(e){
  if(MACHINE[machine].ok.indexOf(e.c)<0)return false;
  /* A101: a published restriction may only ever take access away. An
     unrecognised one bans nothing and is displayed instead (take 95). */
  var _r=restrictOf(e);
  if(_r&&_r.ban&&_r.ban.indexOf(machine)>=0)return false;
  if(e.c==='closed'||e.c==='fsclosed')return false;
  var fl=MACH_FLAG[machine];
  if(!fl)return true;                       /* no per-vehicle field for it */
  var v=B[e.bi>=0?e.bi:0];
  if(e.bi<0||!v)return true;                /* no attributes: class rule stands */
  var mi=BK.indexOf('moto'),ai=BK.indexOf('atv');
  var has=(mi>=0&&v[mi])||(ai>=0&&v[ai]);
  if(!has)return true;                      /* source states nothing per-vehicle */
  var k=BK.indexOf(fl);
  if(k<0)return true;
  var val=v[k];
  /* "open" is the only value the MVUM uses for permitted. Anything else —
     absent, "closed", a seasonal string we do not parse — is not a licence to
     ride, and this is not the place to be generous (invariant: nothing may
     route a rider onto a trail they may not legally ride). */
  return String(val||'').toLowerCase()==='open'}

var NODES=decode(GR.n), CLS=GR.cls, NM=GR.nm, BK=GR.bk, B=GR.b;
/* A60: `d` is "draw this one". Every edge stays in EDGES and in ADJ, so
   routing, snapping, loops, retrace and every cost function see the whole
   network exactly as before — route both, draw one. Older payloads have no
   eighth field; treat their absence as "draw", so a stale bundle degrades to
   the pre-A60 picture rather than to a blank map. */
var EDGES=GR.e.map(function(e,i){return {a:e[0],b:e[1],L:e[2],c:CLS[e[3]],
  n:e[4]>=0?NM[e[4]]:null,id:e[5]>=0?NM[e[5]]:null,bi:e[6],i:i,
  d:e.length<8||e[7]!==0,
  /* A75: the posted route number. Older payloads have no ninth field. */
  rf:(e.length>8&&e[8]>=0)?NM[e[8]]:null}});
function attrs(e){var o={};if(e.bi<0)return o;
  var v=B[e.bi];for(var k=0;k<BK.length;k++)if(v[k])o[BK[k]]=v[k];return o}

var ADJ=[];for(var i=0;i<NODES.length;i++)ADJ.push([]);
EDGES.forEach(function(e){ADJ[e.a].push(e);ADJ[e.b].push(e)});

el('b-src').textContent='GRAPH '+EDGES.length;
el('b-src').className='badge good';

/* Machine legality. This is ROADMAP 7.4 driven by real MVUM and DNR width data,
   not a guess: a 24" motorcycle trail is illegal for a quad, and a side-by-side
   belongs on 72" routes and roads only. */
/* Jacob rides a NARROW dirt bike, so in practice he is on the `bike` profile and
   every width and per-vehicle rule below is permissive for him — the take-81
   quad exclusion touches nothing he will ever ride. Recorded because it matters
   for debugging: if a route looks wrong on his phone, machine legality is not
   the first place to look. It becomes live for anyone else, and for A72. */
var MACHINE={
  bike:{lbl:'🏍 Dirt bike 24"',ok:['route72','trail50','moto24','mccct','fstrail','fsroad','paved','minor','track']},
  quad:{lbl:'🛻 Quad 50"',ok:['route72','trail50','mccct','fstrail','fsroad','paved','minor','track']},
  sxs:{lbl:'🚙 Side-by-side 72"',ok:['route72','fsroad','paved','minor']}
};
/* machIdx, not `mi` — take 15: `mi=0` here silently overwrote the mi(a,b)
   distance function (hoisted from the safety block below), so every Phase-4
   distance call was invoking the number 0 from take 7 onward. The Python
   verifiers mirror the maths and structurally cannot catch a wiring collision
   like this; only executing the shipped file did. */
var ORDER=['bike','quad','sxs'],machIdx=0,machine='bike';
var SPEED={route72:25,fsroad:22,trail50:16,fstrail:14,mccct:11,moto24:11,
  paved:45,minor:28,track:14};
var EFFORT={paved:1,route72:1.05,fsroad:1.1,minor:1.15,trail50:1.5,fstrail:1.7,
  track:1.8,mccct:2.3,moto24:2.6};
var PAVED={paved:1,minor:1};
var HARD=['paved','minor','route72','fsroad','track','trail50','fstrail','mccct','moto24'];

/* ── render straight off the graph — one source of truth, conflation applied ── */
var wf=[],wlab=[];
Object.keys(WATER.l).forEach(function(c){var poly=(c==='water');
  var nms=(WATER.nm&&WATER.nm[c])||[];
  WATER.l[c].forEach(function(e,ix){var r=decode(e);
    wf.push({type:'Feature',properties:{c:c},
      geometry:poly?{type:'Polygon',coordinates:[r]}:{type:'LineString',coordinates:r}});
    /* A77. 175 of these carry a name and the payload used to drop every one, so
       the map drew Shaw Lake and the Au Sable as anonymous blue shapes. A lake
       you can name is a landmark you can navigate by; a blue blob is scenery.
       Lakes get a point at the centroid, rivers get the line itself — a river
       label has to follow the water or it reads as belonging to something else.
       Older payloads have no `nm`, so this simply produces nothing. */
    var nm=nms[ix];
    if(!nm)return;
    if(poly){
      /* area-weighted centroid, so a long crooked lake labels near its bulk
         rather than at the average of its vertices */
      var A=0,cx=0,cy=0;
      for(var k=0;k<r.length-1;k++){
        var f=r[k][0]*r[k+1][1]-r[k+1][0]*r[k][1];
        A+=f;cx+=(r[k][0]+r[k+1][0])*f;cy+=(r[k][1]+r[k+1][1])*f}
      var pt;
      if(Math.abs(A)>1e-12){pt=[cx/(3*A),cy/(3*A)]}
      else{pt=r[(r.length/2)|0]}          /* degenerate ring: fall back to a vertex */
      wlab.push({type:'Feature',properties:{n:nm,c:c},
        geometry:{type:'Point',coordinates:pt}});
    }else{
      wlab.push({type:'Feature',properties:{n:nm,c:c},
        geometry:{type:'LineString',coordinates:r}});
    }})});

/* Map labels use what the sign says, not the database name. "The Meadows
   Motorcycle Trail (TMM)" will not fit along a two-track at z14; "TMM · H58-1"
   is both shorter and closer to what is nailed to the post. The inspect card
   still shows the full name. */
function labelFor(e){
  if(!e.n&&!e.id)return '';
  var n=e.n||'';
  var m=n.match(/\(([A-Z0-9]{2,5})\)\s*$/);
  if(m)n=m[1];
  else if(n.length>24)n=n.replace(/\s+(Trail|Route|Road)$/i,'');
  if(e.id&&e.id!==n&&n)return n+' · '+e.id;
  return n||e.id}
/* "M 33;M 72;F-32" is how OSM records a road carrying three designations.
   Splitting happens HERE, where it is drawn, rather than at ingest — the raw
   value is what the source said and is worth keeping intact upstream. Two is
   the most that fits along a road at riding zoom; a third would be truncated
   into nonsense, so it is dropped rather than clipped. */
function refLabel(r){
  if(!r)return null;
  var parts=r.split(';').map(function(x){return x.trim()}).filter(Boolean);
  return parts.length?parts.slice(0,2).join(' · '):null}

var nf2=EDGES.filter(function(e){return e.d}).map(function(e){return {type:'Feature',
  properties:{c:e.c,i:e.i,lb:labelFor(e),rf:refLabel(e.rf)},
  geometry:{type:'LineString',coordinates:decode(GR.g[e.i])}}});

/* ══ LABEL STROKES ══════════════════════════════════════════════════════════
   Line-placed labels need a line long enough to carry the text. The graph is
   split into ROUTING edges — median 76 m, and 76% under the 230 px symbol
   spacing — so each edge is its own feature and almost none can host a label.
   The result: 2-3 names for up to 102 trail segments on screen. Every trail
   edge has a label in the data; nearly none of them were being shown.

   Chain consecutive edges that share a label into maximal strokes, and place
   labels on those instead. Built once at load over 16k edges. */
/* Metres along a stroke. A 740 ft trailhead cannot fit "M-33 Bull Gap
   Trailhead" at 60 px symbol-spacing, so MapLibre placed nothing and Jacob had
   to TAP the trailhead to learn its name (take 66). Short features get their own
   layer with symbol-placement:line-center — exactly one label, centred. */
function strokeLen(pts){
  var m=0;
  for(var i=1;i<pts.length;i++){
    var dx=(pts[i][0]-pts[i-1][0])*79000,dy=(pts[i][1]-pts[i-1][1])*111320;
    m+=Math.sqrt(dx*dx+dy*dy)}
  return Math.round(m)}

/* `key` picks what a stroke is chained BY. Trail names use labelFor(); route
   numbers use the posted ref. Parameterised rather than copied, because a
   second walker is a second thing to keep in step and they would drift the way
   the palette did (landmine 107). */
/* A110. "0.8 mi NE of you" is the question a rider actually has about a pin.
   Reuses mi() and compass(), both verified outside the code that produced them
   at take 69 — a bearing nobody checked is how you send someone the wrong way. */
function placeDist(p){
  if(!ME)return '';
  var d=mi(ME,p);
  return d.toFixed(d<10?1:0)+' mi '+compass(bearing(ME,p))+' of you';}

function chainStrokes(key){
  key=key||labelFor;
  var byKey={};
  EDGES.forEach(function(e){
    /* Undrawn edges must be excluded HERE too. A label chain built from the
       full set walks through geometry that is not on the map, and the name
       lands on empty ground — the failure A60's note does not mention and the
       reason this take touches two places, not one. */
    if(!e.d)return;
    var lb=key(e); if(!lb)return;
    var k=e.c+'\u0000'+lb;
    (byKey[k]||(byKey[k]=[])).push(e)});
  var feats=[];
  Object.keys(byKey).forEach(function(k){
    var list=byKey[k],cls=k.split('\u0000')[0],lb=k.split('\u0000')[1];
    var adj={},used={};
    list.forEach(function(e){
      (adj[e.a]||(adj[e.a]=[])).push(e);(adj[e.b]||(adj[e.b]=[])).push(e)});
    function walk(from,e){
      /* follow this label as far as it goes, never reusing an edge */
      var pts=decode(GR.g[e.i]).slice(),cur=(e.a===from?e.b:e.a);
      used[e.i]=1;
      if(e.a!==from)pts.reverse();
      for(;;){
        var nx=null,cand=adj[cur]||[];
        for(var i=0;i<cand.length;i++)if(!used[cand[i].i]){nx=cand[i];break}
        if(!nx)break;
        used[nx.i]=1;
        var g=decode(GR.g[nx.i]);
        if(nx.a!==cur)g.reverse();
        pts=pts.concat(g.slice(1));
        cur=(nx.a===cur?nx.b:nx.a)}
      return pts}
    /* start at dead ends first so strokes run end to end, then mop up loops */
    var starts=[];
    Object.keys(adj).forEach(function(n){if(adj[n].length===1)starts.push(+n)});
    starts.forEach(function(n){
      (adj[n]||[]).forEach(function(e){if(!used[e.i]){
        var co=walk(n,e);
        feats.push({type:'Feature',properties:{c:cls,lb:lb,px:strokeLen(co)},
          geometry:{type:'LineString',coordinates:co}})}})});
    list.forEach(function(e){if(!used[e.i]){
      var co2=walk(e.a,e);
      feats.push({type:'Feature',properties:{c:cls,lb:lb,px:strokeLen(co2)},
        geometry:{type:'LineString',coordinates:co2}})}});
  });
  return feats}
/* ══ SHOW-ONLY ROUTES ═══════════════════════════════════════════════════════
   Trails that EXIST but a dirt bike may not legally ride: hiking, equestrian,
   ski, snowmobile, non-motorised NFS, and OSM paths. Jacob rides to camp and
   wants to know every route in the area — a footpath to a lake is worth seeing.
   They are held out of the routing graph entirely by graph.py, so no cost
   function, snap or loop can reach them; here they are only drawn. */
var SHOWN={foot:'foot / hike',horse:'equestrian',snow:'ski',snowmob:'snowmobile',
  nfsmoto:'NFS trail — MVUM governs',cycle:'cycleway',race:'raceway',
  bike:'bike trail',mou:'permit / MOU',railtrail:'rail trail'};
var showFeats=(SHOW&&SHOW.r?SHOW.r:[]).map(function(r){
  return {type:'Feature',properties:{c:r.c,n:r.n||'',u:r.u||SHOWN[r.c]||r.c},
    geometry:{type:'LineString',coordinates:r.g}}});

/* ══ PLACES (A110) ══════════════════════════════════════════════════════════
   Somewhere to ride TO. Kinds are ordered by how much a rider in trouble cares:
   fuel and a trailhead are useful when the day is going wrong, a picnic table
   is not. That order drives both the colour and which pin wins a collision.

   No icons: the glyph pack is ASCII 32-126 (glyphs.py CHARS), so an emoji or a
   sprite would render as a box. A coloured dot with a text label costs nothing,
   scales on the GPU, and is legible at 2 px — landmine 30 in advance rather
   than after. */
/* ── CATEGORY BADGES (take 113 · T3, reference study) ─────────────────────
   AllTrails' POI system, transcribed: a category-coloured circle with a white
   glyph, label in the SAME colour with a white halo. The glyph names which
   badge image to draw (makeBadges below); colours are the reference family —
   deep green for nature, brown for camping, blue for water access — with fuel
   and trailheads keeping their higher-urgency reds/oranges. */
var POIKIND={
  fuel:     {c:'#C1121F', h:'Fuel',        r:1, g:'fuel'},
  trailhead:{c:'#D2500C', h:'Trailhead',   r:1, g:'flag'},
  camp:     {c:'#7A5B3A', h:'Campground',  r:2, g:'tent'},
  launch:   {c:'#2E7FA8', h:'Boat launch', r:2, g:'boat'},
  beach:    {c:'#C9A227', h:'Beach',       r:3, g:'sun'},
  dayuse:   {c:'#3D6B35', h:'Day use',     r:3, g:'tree'},
  store:    {c:'#6B4FA0', h:'Store',       r:3, g:'bag'},
  food:     {c:'#6B4FA0', h:'Food',        r:4, g:'cup'},
  view:     {c:'#3D6B35', h:'Viewpoint',   r:4, g:'eye'},
  info:     {c:'#4A5560', h:'Information', r:5, g:'i'},
  water:    {c:'#2E7FA8', h:'Drinking water', r:5, g:'drop'},
  toilet:   {c:'#4A5560', h:'Toilets',     r:6, g:'i'},
  shelter:  {c:'#4A5560', h:'Shelter',     r:6, g:'tent'}
};

function makeBadges(){
  /* Tiny glyphs drawn by hand on a canvas: at 8 px inside a 26 px badge a
     stroke sketch outlives any imported path. Registered once per kind. */
  var G={
    tree:function(x){x.moveTo(13,6);x.lineTo(8,15);x.lineTo(18,15);x.closePath();
      x.moveTo(13,15);x.lineTo(13,19)},
    tent:function(x){x.moveTo(6,18);x.lineTo(13,7);x.lineTo(20,18);x.closePath();
      x.moveTo(13,18);x.lineTo(13,12)},
    boat:function(x){x.moveTo(6,15);x.lineTo(20,15);x.lineTo(17,19);x.lineTo(9,19);
      x.closePath();x.moveTo(13,15);x.lineTo(13,6);x.lineTo(18,12);x.lineTo(13,12)},
    fuel:function(x){x.rect(8,7,7,12);x.moveTo(15,11);x.lineTo(18,11);
      x.lineTo(18,17)},
    flag:function(x){x.moveTo(9,20);x.lineTo(9,6);x.lineTo(18,9);x.lineTo(9,12)},
    sun:function(x){x.arc(13,13,4,0,6.283);x.moveTo(13,5);x.lineTo(13,7);
      x.moveTo(13,19);x.lineTo(13,21);x.moveTo(5,13);x.lineTo(7,13);
      x.moveTo(19,13);x.lineTo(21,13)},
    drop:function(x){x.moveTo(13,6);x.bezierCurveTo(9,12,8,14,8,16);
      x.arc(13,16,5,3.1416,0,true);x.bezierCurveTo(18,14,17,12,13,6)},
    bag:function(x){x.rect(8,10,10,9);x.moveTo(10,10);x.arc(13,10,3,3.1416,0)},
    cup:function(x){x.moveTo(8,8);x.lineTo(8,16);x.arc(11,16,3,3.1416,0,true);
      x.moveTo(14,8);x.lineTo(14,14);x.moveTo(14,10);x.arc(14,12,2,-1.57,1.57)},
    eye:function(x){x.moveTo(6,13);x.bezierCurveTo(9,8,17,8,20,13);
      x.bezierCurveTo(17,18,9,18,6,13);x.moveTo(15,13);
      x.arc(13,13,2,0,6.283)},
    i:function(x){x.moveTo(13,11);x.lineTo(13,18);x.moveTo(13,7);x.lineTo(13,8)},
    dam:function(x){x.moveTo(7,7);x.lineTo(13,18);x.lineTo(19,7);
      x.moveTo(13,10);x.lineTo(13,13)}
  };
  var done={};
  function one(name,color,glyph){
    if(done[name]||!map.addImage)return;
    /* headless stubs have elements without a 2d context — a badge is polish,
       and polish must never be the reason the map refuses to load (take 113) */
    if(!document.createElement('canvas').getContext)return;
    done[name]=1;
    var S=2,c=document.createElement('canvas');c.width=c.height=26*S;
    var x=c.getContext('2d');x.scale(S,S);
    x.beginPath();x.arc(13,13.6,11,0,6.283);x.fillStyle='rgba(0,0,0,.22)';x.fill();
    x.beginPath();x.arc(13,13,11,0,6.283);x.fillStyle=color;x.fill();
    x.lineWidth=1.6;x.strokeStyle='#FFFFFF';x.stroke();
    x.beginPath();x.lineWidth=1.7;x.lineCap='round';x.lineJoin='round';
    (G[glyph]||G.i)(x);x.stroke();
    try{map.addImage(name,x.getImageData(0,0,26*S,26*S),{pixelRatio:S})}catch(e){}}
  Object.keys(POIKIND).forEach(function(k){
    one('bdg-'+k,POIKIND[k].c,POIKIND[k].g)});
  one('bdg-pad-launch','#2E7FA8','boat');one('bdg-pad-access','#2E8B99','boat');
  one('bdg-pad-camp','#7A5B3A','tent');one('bdg-pad-parking','#4A5560','i');
  one('bdg-dam','#C1121F','dam');
  /* The Michigan trunkline diamond — the black-on-white rotated square every
     Michigander reads as "M-road" before the number registers. Both reference
     apps draw it correctly; a Michigan-only app has no excuse not to. */
  if(!done['mi-diamond']&&map.addImage&&document.createElement('canvas').getContext){done['mi-diamond']=1;
    var S2=2,cv=document.createElement('canvas');cv.width=cv.height=30*S2;
    var g=cv.getContext('2d');g.scale(S2,S2);g.translate(15,15);g.rotate(Math.PI/4);
    var h=9.6;
    g.beginPath();g.rect(-h,-h,h*2,h*2);
    g.fillStyle='#FFFFFF';g.fill();
    g.lineWidth=1.8;g.strokeStyle='#1C1A16';g.stroke();
    try{map.addImage('mi-diamond',g.getImageData(0,0,30*S2,30*S2),{pixelRatio:S2})}catch(e){}}}
var poif=((POIS&&POIS.p)||[]).map(function(r,i){
  var k=POIKIND[r.k]||{c:'#4A443B',h:r.k,r:7};
  return {type:'Feature',
    properties:{i:i,k:r.k,h:k.h,c:k.c,r:k.r,
      /* A beach has no name in OSM and is still a destination — it ships
         unnamed and is labelled by KIND. Saying "Beach" is honest; inventing
         "Island Lake Beach" from the day-use area 6 m away is not
         (poi.py explains the exception). */
      n:r.n||k.h,named:r.n?1:0},
    geometry:{type:'Point',coordinates:r.p}}});

/* A87 · contour lines, a fifth product of the DEM ingest that already runs.
   Delta-encoded exactly like water and graph geometry, so decode() reads it
   with no new code. Index contours (every 200 ft) carry the elevation label;
   the intermediates are drawn thinner and unlabelled, which is how every topo
   map is read. */
/* A76 · named summits. Four in this region, and three of them match the figures
   on a commercial map to within three feet — Auger Hill, Mio Mountain, Wagon
   Wheel Hill. The name is OSM's; the elevation is OUR DEM's, the same source as
   every other height the app shows, so a summit label cannot disagree with the
   readout under your wheels. Bull Gap is hill-climb country; named high ground
   is the landmark people actually navigate by here. */
/* ══ PADDLE CORRIDORS (A115/A112) ══════════════════════════════════════════
   Six rivers, 390 miles, chosen by evidence rather than by anyone's list: every
   named river in Michigan scored by how many boat and canoe access points people
   have built on it, and those with three or more near this region kept.

   A corridor is drawn as SEPARATE REACHES because that is what it is. The river
   way stops at each impoundment and resumes below it, so the breaks land exactly
   on the dams — and joining them would draw a river you cannot paddle.

   THE PORTAGES ARE NOT DECORATION. Seven dams sit on the Au Sable. A map that
   drew one continuous blue line from Grayling to Lake Huron without marking them
   would be actively dangerous, and A112 makes that a ship-blocker, not a
   nice-to-have. They are drawn on top of everything, in the closure colour, and
   they are never hidden by anything else on this layer. */
var padf=[],padpin=[];
((PADDLE&&PADDLE.c)||[]).forEach(function(c){
  (c.g||[]).forEach(function(reach,i){
    padf.push({type:'Feature',properties:{n:c.n,reach:i},
      geometry:{type:'LineString',coordinates:reach}})});
  /* The impoundment midpoints are NOT drawn. A portage marker a kilometre from
     the dam it belongs to is two pins for one hazard, and the dam is the thing
     you must not miss. The distances are in the payload and printed at build
     time; they belong on the dam's card, not as a second pin. */
  (c.f||[]).forEach(function(f){
    padpin.push({type:'Feature',
      properties:{k:f.k,n:f.n||null,mi:f.mi,riv:c.n,
        lb:(f.n||({dam:'Dam',launch:'Boat launch',access:'Canoe access',
                   camp:'Campground',parking:'Parking'}[f.k]||f.k))},
      geometry:{type:'Point',coordinates:f.p}})})});

/* ══ THE PADDLE CARD (A115) ═════════════════════════════════════════════════
   A pin that only says its own name answers nothing. What a shuttle needs is
   what is ABOVE and BELOW it, and whether there is a dam in between — because
   you drop boats at one access and pick them up at another, and getting that
   order wrong is the whole trip.

   The mileage is the mapped centreline's, which under-measures (0.53x the local
   outfitter above Mio, 0.78x near it). It is shown as "about" and the card says
   so once, plainly, rather than the app pretending to a precision it does not
   have. The ORDER, which is what the card is really for, is exact. */
var PADKIND={dam:'Dam',launch:'Boat launch',access:'Canoe access',
             camp:'Campground',parking:'Parking'};

/* ══ HOW LONG IT TAKES (A122) ══════════════════════════════════════════════
   Take 102 shipped these distances with an apology: they came out about 0.55x
   the local outfitter's published table, so the card said they ran short and
   only the ORDER could be trusted.

   The apology was wrong. Take 106 pulled the same river from USGS NHD — the
   federal authoritative hydrography, an entirely independent survey — and it
   agrees with OpenStreetMap to within 4%:

       Burtons -> Wakeley     NHD  9.2   OSM  9.3   outfitter 16
       Wakeley -> Camp Ten    NHD 26.2   OSM 26.3   outfitter 50
       Camp Ten -> Comins     NHD 11.1   OSM 10.7   outfitter 15

   Two independent surveys agreeing that closely are not both wrong by 45%. The
   outfitter's MILEAGES run high — and Jacob, who has paddled these floats with
   them, says their HOURS are about right. Both can be true, and together they
   settle the pace:

       Burtons->Mio   38.5 mi / 15 hrs   = 2.57 mph
       Stephan->Mio   33.7 mi / 13 hrs   = 2.59 mph
       Wakeley->Mio   29.2 mi / 11.5 hrs = 2.54 mph
       McMasters->Mio 21.4 mi / 8.5 hrs  = 2.51 mph

   2.5 mph is what a canoe does on a river with light current. Their own figures
   imply 4.7, which nobody paddles. So the distances were right all along and the
   card was apologising for the wrong number.

   The estimate is shown as a RANGE and the assumption is stated, because pace is
   the part we are guessing at — flow, wind, how much you stop. What we are not
   guessing at is the distance. */
var PADDLE_MPH=2.5, PADDLE_SPREAD=0.5;

function paddleHours(miles){
  var slow=miles/(PADDLE_MPH-PADDLE_SPREAD), fast=miles/(PADDLE_MPH+PADDLE_SPREAD);
  var fmt=function(h){
    if(h<1)return Math.round(h*60)+' min';
    var w=Math.floor(h),mn=Math.round((h-w)*60);
    if(mn===60){w+=1;mn=0}
    return w+' hr'+(mn?' '+mn+' min':'')};
  return fmt(fast)+'\u2013'+fmt(slow)}

/* ══ THE RUN (A121) ═════════════════════════════════════════════════════════
   The card answers one hop. A shuttle needs the whole float: pick a put-in, pick
   a take-out, and get what is between them — every dam you must portage, every
   campground you could stop at, and which way round it goes.

   You cannot paddle upstream, so tap order does not decide direction: the
   upstream stop is the put-in whichever you picked first, and the card says so
   rather than refusing a reasonable gesture. */
var RUNFROM=null;

function runClear(){RUNFROM=null}

/* ══ COMPASS (A119) ═════════════════════════════════════════════════════════
   The ride HUD has carried a compass ribbon since take 78, but only while a
   ride is running. Standing at a junction with the engine off — which is when
   you actually get out the map — the app had no heading at all and no bearing
   to anything but the truck.

   This is a rose you can read at a glance plus the bearings that matter: the
   truck, home, and every waypoint you have saved. It is a TOOL, not a widget:
   it opens from Tools, it says plainly when it has no heading rather than
   drawing a needle pointing at nothing, and it updates as fixes arrive.

   A phone lying flat has no heading until it moves. Android reports
   `coords.heading` as null when stationary and the crumb-trail fallback needs
   two fixes apart — so "no heading yet" is the normal state at a standstill and
   is said in those words. */
var CMP_ON=false, MAG=null, MAG_OK=null;

/* ══ THE MAGNETOMETER (take 109) ════════════════════════════════════════════
   Jacob, on the take-108 compass: "I don't think compass works". It was working
   exactly as designed and the design was wrong. It read GPS course-over-ground,
   which does not exist standing still — so a compass you open at a junction
   with the engine off showed a rose with no needle and a sentence explaining
   why. That is a correct answer to a question nobody asked.

   The phone has a magnetometer and the Android WebView exposes it through
   `deviceorientationabsolute` with no Capacitor plugin and no permission — the
   plugin list on his Fold is Geolocation, Device, Haptics, Cookies, WebView,
   Share, Http, and none of them are needed for this.

   GPS heading still wins WHILE MOVING, because course-over-ground is what you
   are actually doing and a magnetometer near an engine is not to be trusted.
   Standing still the magnetometer takes over, which is the case that was broken.

   If the sensor never reports, MAG_OK stays null and the compass says so rather
   than pretending — the same rule as everything else here. */
function magStart(){
  if(MAG_OK!==null)return;
  MAG_OK=false;
  var onEv=function(e){
    var deg=null;
    if(typeof e.webkitCompassHeading==='number')deg=e.webkitCompassHeading;
    else if(e.absolute===true&&typeof e.alpha==='number')deg=(360-e.alpha)%360;
    else if(typeof e.alpha==='number')deg=(360-e.alpha)%360;
    if(deg===null||isNaN(deg))return;
    /* Stored raw; converted where it is read, so the raw sensor value stays
       available if this ever needs to show both. */
    MAG_OK=true;MAG=(deg+360)%360;
    if(CMP_ON)cmpPaint()};
  try{window.addEventListener('deviceorientationabsolute',onEv,true)}catch(e){}
  try{window.addEventListener('deviceorientation',onEv,true)}catch(e){}
  /* iOS needs a gesture-gated permission; Android does not. Asked for only if
     the API exists, and never blocking. */
  try{
    var D=window.DeviceOrientationEvent;
    if(D&&typeof D.requestPermission==='function')D.requestPermission().catch(function(){});
  }catch(e){}}

/* Which heading to believe: moving, trust the GPS course; stopped, trust the
   compass. Returns null only when neither has anything. */
/* ── TWO NORTHS (A128, take 111) ──────────────────────────────────────────
   Take 109 shipped a compass that reads GPS course while moving and the
   magnetometer while stopped. Those are not the same north.

   GPS course-over-ground is TRUE north. A magnetometer points at MAGNETIC
   north, which in north-east Michigan sits about 7 degrees WEST of true. So the
   same needle meant different things depending on whether the bike was rolling,
   and worse: every bearing in the list — "Home WNW 300 deg · 109 deg left" — is
   computed from coordinates and is therefore TRUE. Comparing a magnetic heading
   against a true bearing put the turn figure out by 7 degrees.

   Everything is converted to TRUE at the source, so one number means one thing.

   The value is a constant, not a model: WMM changes slowly and this app covers
   one region of one state. Stated, dated, and cheap to revise — an approximate
   correction applied consistently beats an exact one applied to half the app. */
var DECL_W = 7.0;      /* degrees west, NE Michigan, 2026 */

function magToTrue(deg){
  if(deg===null||deg===undefined)return null;
  return (deg-DECL_W+360)%360}

function headingNow(){
  var moving=HUD.spd!==null&&HUD.spd>1.2;   /* ~2.7 mph */
  if(moving&&HUD.hdg!==null)return {deg:HUD.hdg,src:'course'};
  if(MAG!==null)return {deg:magToTrue(MAG),src:'compass'};
  if(HUD.hdg!==null)return {deg:HUD.hdg,src:'course'};
  return null}

function cmpRose(deg){
  var ticks='',i,a,x1,y1,x2,y2,r=46;
  for(i=0;i<16;i++){
    a=(i*22.5-(deg||0))*Math.PI/180;
    var major=(i%4===0),len=major?9:5;
    x1=50+Math.sin(a)*r; y1=50-Math.cos(a)*r;
    x2=50+Math.sin(a)*(r-len); y2=50-Math.cos(a)*(r-len);
    ticks+='<line x1="'+x1.toFixed(1)+'" y1="'+y1.toFixed(1)+'" x2="'+x2.toFixed(1)+
      '" y2="'+y2.toFixed(1)+'" stroke="'+(major?'#F2ECE0':'#9C9384')+
      '" stroke-width="'+(major?1.6:1)+'"/>'}
  var lbl='',C=['N','E','S','W'];
  for(i=0;i<4;i++){
    a=(i*90-(deg||0))*Math.PI/180;
    lbl+='<text x="'+(50+Math.sin(a)*31).toFixed(1)+'" y="'+(50-Math.cos(a)*31+3.4).toFixed(1)+
      '" text-anchor="middle" font-size="10" font-weight="700" fill="'+
      (i===0?'#E2570F':'#F2ECE0')+'">'+C[i]+'</text>'}
  return '<svg viewBox="0 0 100 100" width="128" height="128" aria-hidden="true">'+
    '<circle cx="50" cy="50" r="47" fill="none" stroke="rgba(255,255,255,.22)"/>'+
    ticks+lbl+
    (deg===null?'':'<path d="M50 8 L45 20 L55 20 Z" fill="#E2570F"/>')+
    '<circle cx="50" cy="50" r="2.4" fill="#F2ECE0"/></svg>'}

function cmpRows(hdg){
  var out=[];
  if(hdg===undefined){var H=headingNow();hdg=H?H.deg:null}
  function row(label,at){
    if(!at||!ME)return;
    var b=bearing(ME,at),d=mi(ME,at);
    /* A bearing to where you are standing is not a bearing. Marking this spot
       and then opening the compass produced "N 0 deg · 0.00 mi · 49 deg left",
       which is true, looks like an answer and is noise — the same shape as the
       0.0 mi neighbour on the paddle card (landmine 164). Under ~100 ft you are
       on it, and the row says that instead. */
    if(d<0.02){out.push('<b>'+label+'</b> <span style="color:#9C9384">'+
      'you are here</span>');return}
    var rel=hdg===null?null:((b-hdg+540)%360-180);
    out.push('<b>'+label+'</b> '+compass(b)+' '+Math.round(b)+'\u00B0 · '+
      (d<10?d.toFixed(2):Math.round(d))+' mi'+
      (rel===null?'':' · '+(Math.abs(rel)<8?'straight ahead'
        :(rel<0?Math.round(-rel)+'\u00B0 left':Math.round(rel)+'\u00B0 right'))))}
  row('Truck',TRUCK);
  row('Home',HOME);
  wpLoad().filter(function(x){return !x.r||!BUNDLE.region||x.r===BUNDLE.region})
    .slice(0,6).forEach(function(x){row(x.n,x.p)});
  return out}

function cmpPaint(){
  var box=el('cmpbox');
  if(!box||!CMP_ON)return;
  var H=headingNow(),hdg=H?H.deg:null,rows=cmpRows(hdg);
  box.innerHTML='<div style="text-align:center">'+cmpRose(hdg)+
    '<div style="font:700 var(--t-lg)/1 Barlow,Roboto,system-ui,sans-serif;margin-top:4px">'+
    (hdg===null?'<span style="color:#9C9384;font-size:var(--t-sm)">'+
       (MAG_OK===false?'this phone is not reporting a compass \u2014 start moving '+
         'and it will use your GPS course instead'
        :'waiting for the compass\u2026')+'</span>'
     :compass(hdg)+' <span style="color:#9C9384">'+Math.round(hdg)+'\u00B0 true \u00B7 '+
       (H.src==='compass'?'compass':'course')+'</span>')+
    '</div></div>'+
    (rows.length?'<div style="margin-top:9px;line-height:1.7">'+rows.join('<br>')+'</div>'
     :'<div class="sub" style="margin-top:9px">Nothing to take a bearing to yet — '+
      'pin the truck, set home, or save a waypoint.</div>')}

function runCard(a,b,riv){
  var c=null,i;
  for(i=0;i<((PADDLE&&PADDLE.c)||[]).length;i++)
    if(PADDLE.c[i].n===riv){c=PADDLE.c[i];break}
  if(!c)return;
  var lo=Math.min(a.mi,b.mi),hi=Math.max(a.mi,b.mi);
  var putIn=(a.mi<=b.mi?a:b), takeOut=(a.mi<=b.mi?b:a);
  var swapped=(a!==putIn);
  var mid=c.f.filter(function(f){return f.mi>lo+0.05&&f.mi<hi-0.05});
  var dams=mid.filter(function(f){return f.k==='dam'});
  var camps=mid.filter(function(f){return f.k==='camp'});
  var acc=mid.filter(function(f){return f.k==='launch'||f.k==='access'});
  var nm=function(f){return f.n||PADKIND[f.k]||f.k};

  var rows=[];
  rows.push('Put in <b>'+nm(putIn)+'</b>');
  rows.push('Take out <b>'+nm(takeOut)+'</b>');
  rows.push('About <b>'+(hi-lo).toFixed(1)+' mi</b> of river between them');
  if(dams.length)
    rows.push('<b style="color:#C1121F">'+dams.length+' dam'+(dams.length>1?'s':'')+
      ' on the way — '+dams.map(nm).join(', ')+'. You must take out and portage '+
      (dams.length>1?'each one':'it')+'.</b>');
  else
    rows.push('<b>No dams between them.</b>');
  if(acc.length)
    rows.push(acc.length+' other access point'+(acc.length>1?'s':'')+
      ' on the way'+(acc.length<=4?': '+acc.map(nm).join(', '):''));
  if(camps.length)
    rows.push(camps.length+' campground'+(camps.length>1?'s':'')+
      (camps.length<=4?': '+camps.map(nm).join(', '):' along it'));
  if(swapped)
    rows.push('<span class="sub">Tapped in the other order — a river only runs '+
      'one way, so this is the run.</span>');
  rows.push('Roughly <b>'+paddleHours(hi-lo)+'</b> of paddling'+
    (dams.length?' plus the portage'+(dams.length>1?'s':''):'')+
    ' <span class="sub">at 2\u20133 mph, which is what these floats work out at '+
    'against the liveries\u2019 own times</span>');
  logAct('act  run '+nm(putIn)+' -> '+nm(takeOut));
  show('<div class="tn">The run \u2014 <span class="sub">'+riv+'</span></div>'+
    rows.join('<br>')+
    '<div class="sub" style="margin-top:8px">'+
    '<button class="chip" id="pd-clear">'+ic('close')+'<span>Clear</span></button></div>',
    dams.length?'fail':'pass');
  var cb=el('pd-clear');
  if(cb)cb.addEventListener('click',function(){runClear();show('Run cleared.','')});
  RUNFROM=null}

function paddleCard(ft){
  var pr=ft.properties, riv=pr.riv||pr.n, mi=+pr.mi;
  var c=null,i;
  for(i=0;i<((PADDLE&&PADDLE.c)||[]).length;i++)
    if(PADDLE.c[i].n===riv){c=PADDLE.c[i];break}
  if(!c)return show('<b>'+(pr.lb||'On the river')+'</b>','');
  logAct('tap  paddle '+(pr.n||pr.k));

  var stops=c.f.filter(function(f){return f.k!=='parking'});
  var here=null,bi=-1;
  for(i=0;i<stops.length;i++){
    if(Math.abs(stops[i].mi-mi)<0.02&&(stops[i].n||null)===(pr.n||null)){here=stops[i];bi=i;break}}
  if(bi<0){for(i=0;i<stops.length;i++)if(Math.abs(stops[i].mi-mi)<0.02){here=stops[i];bi=i;break}}

  var isDam=pr.k==='dam';
  var head=(pr.n?pr.n:(PADKIND[pr.k]||'On the river'))+
    ' <span class="sub">'+riv+'</span>';
  var rows=[];
  if(isDam){
    rows.push('<b style="color:#C1121F">DAM — you must take out and portage.</b>');
    var atDam=stops.filter(function(f){
      return f.k!=='dam'&&Math.abs(f.mi-mi)<0.35});
    if(atDam.length)
      rows.push('At the dam: '+atDam.map(function(f){
        return f.n||PADKIND[f.k]||f.k}).slice(0,3).join(', '));
  }
  rows.push((PADKIND[pr.k]||pr.k)+' · about <b>'+mi.toFixed(1)+' mi</b> down the river');

  /* what is upstream and downstream, and what is between */
  function between(a,b){
    var d=[];
    for(var j=Math.min(a,b)+1;j<Math.max(a,b);j++)
      if(stops[j].k==='dam')d.push(stops[j].n||'a dam');
    return d}
  function side(dir){
    var j=bi+dir;
    /* Skip dams — they are reported separately as the thing between — and skip
       anything at the SAME point. A dam usually has an access on each bank
       projecting to the same river mile, so the first neighbour was "about
       0.0 mi" in both directions, which answers nothing (take 103). */
    while(j>=0&&j<stops.length&&
          (stops[j].k==='dam'||Math.abs(stops[j].mi-mi)<0.06))j+=dir;
    if(j<0||j>=stops.length)return null;
    var t=stops[j],gap=Math.abs(t.mi-mi),dams=between(bi,j);
    return (dir<0?'Above: ':'Below: ')+'<b>'+(t.n||PADKIND[t.k]||t.k)+'</b> · '+
      (gap<0.1?'at the same spot':gap.toFixed(1)+' mi · '+paddleHours(gap))+
      (dams.length?' · <b style="color:#C1121F">'+dams.join(', ')+' in between — portage</b>'
                 :' · no dam between')}
  if(bi>=0){
    var up=side(-1),dn=side(1);
    if(up)rows.push(up);
    if(dn)rows.push(dn);
    if(!up)rows.push('<span class="sub">Nothing mapped above this — it is the top of the run.</span>');
    if(!dn)rows.push('<span class="sub">Nothing mapped below this — it is the end of the run.</span>');
  }
  rows.push('<span class="sub">River miles from OpenStreetMap, cross-checked '+
    'against the USGS survey — they agree within 4%.</span>');

  /* Pick two and get the float between them. Only offered where it can mean
     something: a stop we found on the river, with a mile to measure from. */
  var acts='';
  if(here){
    acts=RUNFROM&&RUNFROM.riv===riv&&Math.abs(RUNFROM.mi-here.mi)>0.05
      ? '<button class="chip" id="pd-to">'+ic('route')+'<span>Run from '+
        (RUNFROM.n||PADKIND[RUNFROM.k]||'there')+' to here</span></button> '+
        '<button class="chip" id="pd-cancel">'+ic('close')+'<span>Cancel</span></button>'
      : '<button class="chip" id="pd-from">'+ic('route')+'<span>Plan a run from here</span></button>';}
  show('<div class="tn">'+head+'</div>'+rows.join('<br>')+
    (acts?'<div class="sub" style="margin-top:8px">'+acts+'</div>':''),
    isDam?'fail':'');
  var f1=el('pd-from');
  if(f1)f1.addEventListener('click',function(){
    RUNFROM={mi:here.mi,n:pr.n,k:pr.k,riv:riv};
    logAct('act  run from '+(pr.n||pr.k));
    show('<b>'+(pr.n||PADKIND[pr.k]||'Here')+'</b> is the first end.<br>'+
      'Now tap the other end of the run on the '+riv+'.','')});
  var f2=el('pd-to');
  if(f2)f2.addEventListener('click',function(){
    runCard(RUNFROM,{mi:here.mi,n:pr.n,k:pr.k},riv)});
  var f3=el('pd-cancel');
  if(f3)f3.addEventListener('click',function(){runClear();show('Run cancelled.','')});
}

var peakf=((CONT&&CONT.pk)||[]).map(function(p){
  return {type:'Feature',
    properties:{n:p.n,ft:p.ft,lb:p.n+'\n'+p.ft.toLocaleString()+' ft'},
    geometry:{type:'Point',coordinates:p.p}}});

var contf=((CONT&&CONT.l)||[]).map(function(l){
  return {type:'Feature',
    properties:{ft:l.ft,i:l.i,lb:l.ft+' ft'},
    geometry:{type:'LineString',coordinates:decode(l.c)}}});

var strokes=chainStrokes();
/* A75. Route numbers chain by the posted ref, so "M 33" becomes one long line
   instead of 157 routing edges none of which is long enough to carry a label.
   Same walker, different key. */
var refstrokes=chainStrokes(function(e){return refLabel(e.rf)});
/* "M-33 Bull Gap Trailhead" is 23 characters and its feature is 740 ft — about
   90 px at riding zoom. No line label of any size fits, so line-center drew
   nothing and Jacob had to TAP the trailhead to find out what it was. A POINT
   label at the middle of the stroke wraps onto two or three lines and fits
   (take 66). */
var shortPts={type:'FeatureCollection',features:strokes.filter(function(f){
    return f.properties.lb && f.properties.px<420 &&
           f.geometry.coordinates.length>1})
  .map(function(f){
    var c=f.geometry.coordinates,m=c[Math.floor(c.length/2)];
    return {type:'Feature',properties:{lb:f.properties.lb,c:f.properties.c},
            geometry:{type:'Point',coordinates:m}}})};

/* ══ PALETTE ═══════════════════════════════════════════════════════════════
   ONE table. The style paints from it and the activity picker reads from it, so
   the legend cannot drift from the map — which it had. Take 61 set two-track to
   #A9702F, take 64 dimmed the LAYER to #9C7343, take 67 wrote the swatch from
   the take-61 value, and nothing connected the two: dE 12.9 apart, four times
   the just-noticeable difference, and #A9702F appeared nowhere in the style at
   all. A legend generated from a COPY of the palette is a hand-written legend
   with extra steps (landmine 98).

   Every value below was chosen by measurement against 1,048,576 real satellite
   pixels sampled from this region's own z15 tiles, scored on FOUR axes at once
   (take 77):
     · separation from the sand basemap        — the app opens on Map
     · separation from the darkest canopy      — the rider uses Hybrid
     · separation from its siblings            — the hierarchy must read
     · separation from every NON-RIDABLE class — landmine 88, and the one that
       actually changed an answer: #B0722B scored best for two-track on
       visibility and sits dE 12.5 from nfsmoto amber, a trail whose ridability
       the MVUM governs. Rejected on legality, not on looks.

   What the measurement REFUSED to give: a colour that makes `fsroad` legible.
   The sand basemap is light (228,215,188) and canopy is dark (91,106,84), so
   any single mid-tone loses to one of them — lighter candidates gained on
   satellite exactly as fast as they lost on sand. fsroad is fixed with a
   CASING, the same answer as designated trail and two-track, not with paint. */
var PAL={
  /* designated ORV line, by difficulty. green / blue / black is what every
     trail map on earth uses, so it is learnable before it is explained. */
  route72:'#0FAE57',                    /* easy   · was #2F7D4F, dE 26->49 vs canopy */
  trail50:'#0B7FE8', fstrail:'#0B7FE8', /* mod    · was #2585D8, dE 62->74 */
  mccct:'#1C1A16',  moto24:'#1C1A16',   /* hard   · unchanged; the halo carries it */
  /* ridable dirt */
  track:'#96562A',                      /* was #9C7343, dE 29->42; clears nfsmoto by 28 */
  fsroad:'#8A7C66',                     /* unchanged — see the casing note above */
  /* roads: background by design */
  /* Take 113 · T3: on the light green ground, roads are WHITE with a hairline
     casing — the AllTrails treatment — and white also reads correctly over the
     dimmed hybrid imagery, so one value serves both styles. */
  minor:'#FFFFFF', paved:'#FFFFFF',
  /* closed to everything */
  closed:'#C1121F', fsclosed:'#C1121F',
  /* show-only: drawn so the map is honest about what exists, dashed because
     dashed means "not yours to ride". */
  foot:'#7CB342', horse:'#8E6BB5', snow:'#4FB3C9', snowmob:'#4FB3C9',
  nfsmoto:'#C98A2E',
  showother:'#5E6B7A'  /* was #7C6F5A — dE 5.2 from fsroad, so an unmatched
                          show-only route was almost indistinguishable from a
                          forest road the rider MAY use. Now 25.5. */
};

function w(a,b,c){return ['interpolate',['linear'],['zoom'],10,a,14,b,17,c]}
/* MapLibre forbids more than ONE zoom-based interpolate per expression, so
   ['case', cond, w(...), w(...)] is invalid — and an invalid expression makes
   MapLibre reject the ENTIRE style, which is why not a single layer drew from
   take 9 to take 22. Keep the zoom curve on the outside and branch inside it
   (landmine 52). */
function wCase(cond,t,f){
  return ['interpolate',['linear'],['zoom'],
    10,['case',cond,t[0],f[0]],
    14,['case',cond,t[1],f[1]],
    17,['case',cond,t[2],f[2]]]}
function lyr(id,cls,col,wd,dash){var o={id:id,type:'line',source:'net',
  filter:['==',['get','c'],cls],layout:{'line-cap':dash?'butt':'round','line-join':'round'},
  paint:{'line-color':col,'line-width':wd}};if(dash)o.paint['line-dasharray']=dash;return o}

/* ══ LABELS ═════════════════════════════════════════════════════════════════
   MOVED at take 15. This block accreted at take 9 hundreds of lines BELOW the
   map constructor and the pins that use PLACES. `var` hoisting made every
   reference `undefined` instead of an error, so style.glyphs and the places
   source were silently dead from take 9 onward — verify9 proved the glyph PACK
   perfect while nothing checked the WIRING — and take 14's anchorOf turned the
   silence into a fatal crash. Found by the first actual execution of the
   shipped file (tools/smoke.mjs). Definition order is load-bearing here.
══
   Landmine 4: MapLibre fetches glyph ranges from a `glyphs` URL and ships no
   fallback, so a style with symbol layers and no glyphs renders silently blank.
   A CDN is not allowed (PROTOCOL §8), so the SDF pack is generated in
   tools/glyphs.py and inlined here.

   ONE fontstack, served from a static data: URI. MapLibre substitutes
   {fontstack}/{range} only if the placeholders are present; without them it
   requests the URL as-is and gets the same pack every time. That avoids needing
   a custom protocol handler for glyph requests, which would be one more thing
   between the map and its text. data: is allowed by the offline guard. */
/* MapLibre REQUIRES the glyphs url to be a template carrying {fontstack} and
   {range} — a bare data: URI fails STYLE VALIDATION, which rejects the whole
   style, which is why not one layer drew on the Fold (take 22 engine message:
   'glyphs url must include a "{fontstack}" token'). Shipped broken since take 9.

   A custom protocol keeps everything in memory, so this works identically in the
   single-file build and in the APK, with no font files on disk and no network. */
var GLYPH_BUF=(function(){var b=atob(GLYPHS.APEX),n=b.length,u=new Uint8Array(n);
  for(var i=0;i<n;i++)u[i]=b.charCodeAt(i);return u})();
maplibregl.addProtocol('apexfont',function(){
  return Promise.resolve({data:GLYPH_BUF.buffer.slice(0)})});
var GLYPH_URL='apexfont://{fontstack}/{range}.pbf';

/* Anchors come from the region manifest, not from here. Take 14 made regions a
   real concept; an app that knows the names of one riding area is a demo of that
   area, not a tool. */
var CTR=BUNDLE.centre||(BUNDLE.bbox?
  [(BUNDLE.bbox[0]+BUNDLE.bbox[2])/2,(BUNDLE.bbox[1]+BUNDLE.bbox[3])/2]:[0,0]);
var PLACES=(BUNDLE.anchors&&BUNDLE.anchors.length?BUNDLE.anchors:
  [[BUNDLE.name||'Region',CTR[0],CTR[1],'town']]);
var placeFC={type:'FeatureCollection',features:PLACES.map(function(p){
  return {type:'Feature',properties:{n:p[0],k:p[3]||'town'},
    geometry:{type:'Point',coordinates:[p[1],p[2]]}}})};

/* Satellite is optional. With no imagery (partial region) or no georeference,
   the source still needs valid geometry and the basemap chip must not offer
   what cannot be shown. */
var TILES=BUNDLE.tiles||null;
var TILEURL='bundle/imagery/{z}/{x}/{y}.jpg';
var SAT_OK=!!TILES||!!(SAT&&SATB&&(SATB[2]-SATB[0])>1e-6&&(SATB[3]-SATB[1])>1e-6);
var SATBOX=SAT_OK?SATB:(BUNDLE.bbox||[0,0,1,1]);
var SATURL=SAT_OK?SAT:'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
var map=new maplibregl.Map({container:'map',style:{version:8,glyphs:GLYPH_URL,
  sources:{
    /* Real tiles when the bundle has them: MapLibre fetches only what is on
       screen, so z15 over the whole region costs 45 MB on disk but bounded
       memory. The single 1500 px mosaic it replaces was 22.1 m/px — a
       two-track is one metre wide, which is why the satellite layer was
       unusable (take 42). The mosaic stays as the fallback for the
       single-file build, which cannot carry 2,000 files. */
    sat:TILES?{type:'raster',tiles:[TILEURL],tileSize:256,
      minzoom:TILES.zmin,maxzoom:TILES.zmax,
      bounds:[SATBOX[0],SATBOX[1],SATBOX[2],SATBOX[3]],
      attribution:'USGS'}
     :{type:'image',url:SATURL,
      coordinates:[[SATBOX[0],SATBOX[3]],[SATBOX[2],SATBOX[3]],[SATBOX[2],SATBOX[1]],[SATBOX[0],SATBOX[1]]]},
    hs:{type:'image',url:SHADE,
      coordinates:[[TR.b[0],TR.b[3]],[TR.b[2],TR.b[3]],[TR.b[2],TR.b[1]],[TR.b[0],TR.b[1]]]},
    ground:{type:'geojson',data:(function(){
      /* forest / wetland / park polygons plus the NF boundary wash, extracted
         from the same OSM file everything else comes from. Absent-safe. */
      var f=(LAND&&LAND.f||[]).map(function(a){
        return {type:'Feature',properties:{k:a.k},
          geometry:{type:'Polygon',coordinates:a.g}}});
      return {type:'FeatureCollection',features:f}})()},
    wtr:{type:'geojson',data:{type:'FeatureCollection',features:wf}},
    wlbl:{type:'geojson',data:{type:'FeatureCollection',features:wlab}},
    refs:{type:'geojson',data:{type:'FeatureCollection',features:refstrokes}},
    poi:{type:'geojson',data:{type:'FeatureCollection',features:poif}},
    cont:{type:'geojson',data:{type:'FeatureCollection',features:contf}},
    wpts:{type:'geojson',data:{type:'FeatureCollection',features:[]}},
    peaks:{type:'geojson',data:{type:'FeatureCollection',features:peakf}},
    paddle:{type:'geojson',data:{type:'FeatureCollection',features:padf}},
    padpin:{type:'geojson',data:{type:'FeatureCollection',features:padpin}},

    net:{type:'geojson',data:{type:'FeatureCollection',features:nf2}},
    strokes:{type:'geojson',data:{type:'FeatureCollection',features:strokes}},
    shortpts:{type:'geojson',data:shortPts},
    showonly:{type:'geojson',data:{type:'FeatureCollection',features:showFeats}},
    state:{type:'geojson',data:{type:'FeatureCollection',features:[]}},
    lakes:{type:'geojson',data:{type:'FeatureCollection',features:[]}},
    approach:{type:'geojson',data:{type:'FeatureCollection',features:[]}},
    alt:{type:'geojson',data:{type:'FeatureCollection',features:[]}},
    route:{type:'geojson',data:{type:'FeatureCollection',features:[]}},
    crumb:{type:'geojson',data:{type:'FeatureCollection',features:[]}},
    back:{type:'geojson',data:{type:'FeatureCollection',features:[]}},
    places:{type:'geojson',data:placeFC}
  },
  layers:[
    /* ── THE GROUND (take 113 · T2, reference study) ────────────────────
       AllTrails' light map: warm light-grey base, landcover doing the work.
       The tan that drew a national forest as a desert dies here. */
    {id:'bg',type:'background',paint:{'background-color':'#F2F3F0'}},
    /* USGS ImageryOnly, NAIP-derived, public domain. Landmine 22: Esri, Google,
       Bing and Mapbox imagery are licensed and may not ship offline. */
    /* Public-land wash first (the Huron NF boundary — AllTrails' deeper tone
       over federal ground), then the specific covers on top of it. All of it
       sits UNDER relief, water and the network: the ground is what the map is
       read against, never what competes with it. */
    {id:'lc-public',type:'fill',source:'ground',
      filter:['==',['get','k'],'public'],
      paint:{'fill-color':'#E9F0DE','fill-opacity':0.85}},
    {id:'lc-forest',type:'fill',source:'ground',
      filter:['==',['get','k'],'forest'],
      paint:{'fill-color':'#D9E7C9','fill-opacity':0.9}},
    {id:'lc-wetland',type:'fill',source:'ground',
      filter:['==',['get','k'],'wetland'],
      paint:{'fill-color':'#D3E4DA','fill-opacity':0.9}},
    {id:'lc-park',type:'fill',source:'ground',
      filter:['==',['get','k'],'park'],
      paint:{'fill-color':'#C9E2B6','fill-opacity':0.9}},
    /* The onX satellite trick is INVERSION: dim and desaturate the imagery so
       the network becomes the brightest thing on screen. Dark ground, luminous
       data (take 113, reference study). */
    {id:'sat',type:'raster',source:'sat',layout:{visibility:'none'},
      paint:{'raster-opacity':1,'raster-fade-duration':0,
        'raster-saturation':-0.35,'raster-brightness-max':0.82,
        'raster-contrast':0.06}},
    /* Relief under the map, multiplied into the sand rather than laid over it,
       so trails stay the loudest thing on screen. */
    {id:'hillshade',type:'raster',source:'hs',
      paint:{'raster-opacity':0.42,'raster-contrast':0.12,'raster-fade-duration':0}},
    /* A87 · contours sit directly above the hillshade and BELOW water and the
       network — terrain is the thing you read the map on top of, never the
       thing competing with the trail you are riding. Off by default: this is a
       reference layer, and the map should open the way it always has.
       Brown, because contours have been brown since the USGS decided so, and a
       rider who has seen a paper quad reads it without being told. */
    {id:'cont-line',type:'line',source:'cont',minzoom:12.4,
      layout:{visibility:'none','line-join':'round'},
      filter:['==',['get','i'],0],
      paint:{'line-color':'#9A7B52','line-width':w(0.4,0.9,1.7),
        'line-opacity':0.62}},
    {id:'cont-index',type:'line',source:'cont',minzoom:11.6,
      layout:{visibility:'none','line-join':'round'},
      filter:['==',['get','i'],1],
      paint:{'line-color':'#8A6A42','line-width':w(0.9,1.7,2.8),
        'line-opacity':0.8}},
    {id:'water',type:'fill',source:'wtr',filter:['==',['get','c'],'water'],
      paint:{'fill-color':'#A9D3E6'}},
    {id:'wway',type:'line',source:'wtr',filter:['==',['get','c'],'waterway'],
      paint:{'line-color':'#A9D3E6','line-width':w(0.5,1.8,4)}},
    /* A white casing under every trail. This is the single thing that makes a
       coloured network readable over satellite imagery, and it was switched OFF
       except in satellite mode — so on the default map the trails had no
       separation from the roads at all. */
    {id:'casing',type:'line',source:'net',
      layout:{'line-cap':'round','line-join':'round'},
      filter:['in',['get','c'],['literal',['route72','trail50','moto24','mccct','fstrail']]],
      /* Wider than it was. Near-black singletrack on dark canopy is only
         legible because of this halo — "dirtbike trails are hard to see". */
      paint:{'line-color':'#FFFFFF','line-opacity':0.95,'line-width':w(3.2,7.2,15)}},
    /* Two-track gets its OWN, narrower casing. Sharing the designated-trail
       casing swamped it — a 1.6 px brown line under a 6 px white halo reads as a
       cream line, which is how the two-track disappeared entirely (take 61). */
    {id:'casing-track',type:'line',source:'net',
      layout:{'line-cap':'round','line-join':'round'},
      filter:['==',['get','c'],'track'],
      paint:{'line-color':'#FFFFFF','line-opacity':0.75,'line-width':w(1.7,3.8,8)}},
    /* Forest road gets a casing too, and take 77 measured why it had to. Colour
       alone cannot fix this one: the sand basemap is light and canopy is dark,
       so every lighter candidate gained on satellite exactly as fast as it lost
       on sand. At #8A7C66 it sits dE 15.8 from median ground with NOTHING under
       it — the least legible drawn class on the map, and the only ridable one
       with no halo.
       Deliberately the faintest of the three casings, so the hierarchy take 61
       established still reads: designated trail 0.95 / two-track 0.75 / forest
       road 0.55, each narrower than the last. A road you drive a truck down
       should be findable, not loud. */
    {id:'casing-fsroad',type:'line',source:'net',
      layout:{'line-cap':'round','line-join':'round'},
      filter:['==',['get','c'],'fsroad'],
      paint:{'line-color':'#FFFFFF','line-opacity':0.55,'line-width':w(1.2,2.6,5.5)}},
    /* PAVED and MINOR are roads and read as background. TRACK and FSROAD are
       not: forest two-track and USFS road are 1,169 of the 2,246 miles here —
       52% — and they are exactly what a dirt bike rides. Styled as grey dashes
       they read as "not for you", which is why Jacob said the trails he rides
       had no colour (take 58). They are ridable dirt: a warm tan, solid, thinner
       than designated trail so the hierarchy still reads. */
    /* Hairline casing UNDER the white fill — without it a white road on a
       light ground is invisible, and the casing is what gives the reference
       maps their quiet road hierarchy (take 113). */
    lyr('minor-case','minor','#C9C8C2',w(1.2,2.1,3.8)),
    lyr('paved-case','paved','#BFBEB8',w(1.9,3.4,6.6)),
    lyr('minor','minor',PAL.minor,w(0.4,0.9,2.2)),
    lyr('paved','paved',PAL.paved,w(0.9,2,4.8)),
    /* fsroad and track were the same brown at take 58, and Jacob's own example
       shows why that is wrong: "East Wagner Lake Road" is minor and "E. Wagner
       Lake Rd" is fsroad — the SAME road, split in the source. A Forest Service
       road is something you drive a truck down; a two-track is something you
       ride. Muted grey-tan for the road, warm brown for the two-track, and only
       the two-track gets a casing (take 61). */
    lyr('fsroad','fsroad',PAL.fsroad,w(0.6,1.4,3.2)),
    lyr('track','track',PAL.track,w(0.7,1.8,3.9)),
    /* Trails, by difficulty. Widest/easiest drawn first so the hard singletrack
       sits on top where it matters. */
    lyr('route72','route72',PAL.route72,w(1.7,4.1,9.5)),
    lyr('fstrail','fstrail',PAL.fstrail,w(1.4,3.4,8)),
    lyr('trail50','trail50',PAL.trail50,w(1.5,3.7,8.6)),
    lyr('mccct','mccct',PAL.mccct,w(1.5,3.7,8.6)),
    lyr('moto24','moto24',PAL.moto24,w(1.5,3.7,8.6)),
    lyr('closed','closed',PAL.closed,w(1.2,3,7),[2,1.3]),
    lyr('fsclosed','fsclosed',PAL.fsclosed,w(1.2,3,7),[2,1.3]),
    /* Both of these were written twice and never landed: my patches anchored on
       'route-line', and the layer is called 'routeline'. The SOURCES were
       created and fed data, so every check I wrote — which measured setData —
       passed while nothing drew. Sources without layers are invisible data
       (take 43, landmine 68). Order matters: alternates under the choice,
       approach legs over it so the dashes stay readable. */
    {id:'show-line',type:'line',source:'showonly',minzoom:11.5,
      layout:{'line-cap':'round'},
      /* One grey for every non-ORV route told Jacob nothing — a hiking trail and a
         snowmobile route looked identical, and both looked like "some line".
         Colour by use; dashed still means "not yours to ride" (take 66). */
      paint:{'line-color':['match',['get','c'],
          'foot',PAL.foot,'horse',PAL.horse,'snow',PAL.snow,
          'snowmob',PAL.snowmob,'nfsmoto',PAL.nfsmoto,PAL.showother],
        'line-width':w(1.1,2,3.2),
        'line-dasharray':[2,2],'line-opacity':0.9}},
    {id:'alt-line',type:'line',source:'alt',
      layout:{'line-cap':'round','line-join':'round'},
      paint:{'line-color':'#5F574B','line-width':w(2.6,3.8,5.2),'line-opacity':0.72}},
    {id:'routeline',type:'line',source:'route',
      layout:{'line-cap':'round','line-join':'round'},
      paint:{'line-color':'#00A8E8','line-width':w(3,6,13),'line-opacity':.7}},
    {id:'approach-line',type:'line',source:'approach',
      layout:{'line-cap':'round'},
      paint:{'line-color':'#3FA7E0','line-width':w(2.0,2.8,3.6),
        'line-dasharray':[1.6,1.6],'line-opacity':0.95}},
    {id:'crumbline',type:'line',source:'crumb',
      layout:{'line-cap':'round','line-join':'round'},
      paint:{'line-color':'#111','line-width':w(1.6,3,6),'line-opacity':.85,
        'line-dasharray':[0.6,1.1]}},
    {id:'backline',type:'line',source:'back',
      layout:{'line-cap':'round','line-join':'round'},
      paint:{'line-color':'#FFD166','line-width':w(3,6,13),'line-opacity':.95}}    ,
    /* Trail names ride along the line, the way a routed sign sits beside it.
       Designated line gets its name and number; advisory OSM line gets neither,
       so text itself carries provenance. */
    /* Land filled, water left as the page ground: that contrast is what makes
       the mitten read as the mitten. Both fade out before the real data. */
    {id:'state-fill',type:'fill',source:'state',maxzoom:9.6,
      paint:{'fill-color':'#EFE7D6',
        'fill-opacity':['interpolate',['linear'],['zoom'],5,1,8.6,0.75,9.6,0]}},
    {id:'state-line',type:'line',source:'state',maxzoom:9.6,
      paint:{'line-color':'#8A8175',
        'line-width':['interpolate',['linear'],['zoom'],5,1.0,7,1.4,9.5,1.8],
        'line-opacity':['interpolate',['linear'],['zoom'],5,0.9,8.6,0.7,9.6,0]}},
    {id:'lake-label',type:'symbol',source:'lakes',maxzoom:8.4,
      layout:{'text-field':['get','n'],'text-font':['APEX'],
        'text-size':['interpolate',['linear'],['zoom'],5,9.5,7.5,12],
        'text-letter-spacing':0.18,'text-max-width':9},
      paint:{'text-color':'#5C7C8A','text-halo-color':'#E4D7BC','text-halo-width':1.8,
        'text-opacity':['interpolate',['linear'],['zoom'],5,0.95,7.8,0.8,8.4,0]}},
    {id:'lbl-place',type:'symbol',source:'places',
      layout:{'text-field':['get','n'],'text-font':['APEX'],
        'text-size':wCase(['==',['get','k'],'town'],[12,15,18],[10.5,13,15.5]),
        'text-transform':['case',['==',['get','k'],'town'],'uppercase','none'],
        'text-letter-spacing':['case',['==',['get','k'],'town'],0.16,0.04],
        'text-anchor':'center','text-allow-overlap':false,'text-padding':6},
      paint:{'text-color':['case',['==',['get','k'],'town'],'#1C1A17','#7A3F0C'],
        'text-halo-color':'#EFE6D2','text-halo-width':2.2,'text-halo-blur':0.5}},
    {id:'lbl-trail',type:'symbol',source:'strokes',minzoom:10.8,
      filter:['in',['get','c'],['literal',['route72','trail50','moto24','mccct','fstrail']]],
      layout:{'symbol-placement':'line','text-field':['get','lb'],
        'text-font':['APEX'],'text-size':w(9.5,11.5,14),
        /* 32 degrees placed ZERO labels on this network: ORV trails bend far more than
         that inside the width of a name, and MapLibre rejects the placement
         outright. Measured sweep at z14.5 over 29 candidate strokes:
         a32 s230 -> 0 · a60 s230 -> 3 · a60 s120 -> 4 · a85 s90 -> 5.
         75/100 keeps most of the gain without text wrapping round hairpins. */
        /* Swept at the REAL viewport (411x960), not the 900x1400 the harness used
           to run — that overstated density threefold. Measured at z14.5:
           75/100/pad2 -> 4 names · 85/60/pad1 -> 5 · with smaller text -> 6.
           Past that it flattens, so more aggression buys nothing (take 57). */
        'text-max-angle':85,'symbol-spacing':60,'text-letter-spacing':0.02,
        'text-padding':1},
      /* White on a dark halo rather than dark on light: it survives sand,
         hillshade and satellite equally, which dark-on-light does not. */
      paint:{'text-color':'#FFFFFF','text-halo-color':'rgba(20,18,15,0.92)',
        'text-halo-width':1.9,'text-halo-blur':0.2}},
    /* AFTER lbl-trail. MapLibre gives earlier symbol layers priority in collision,
       so this sat in front and a non-ridable path ("Mack's Sault") was named
       while the trail loop a rider was standing on was not (take 57). Names you
       may ride come first. */
    /* Short named features — trailheads, connectors, spurs — get ONE centred
       label. Without this a 740 ft trailhead is unlabelled at every zoom. */
    {id:'lbl-trail-short',type:'symbol',source:'shortpts',minzoom:13.4,
      layout:{'text-field':['get','lb'],'text-font':['APEX'],
        'text-size':w(9,10.5,12),'text-max-width':9,'text-line-height':1.15,
        'text-padding':2,'text-anchor':'center','text-allow-overlap':false},
      paint:{'text-color':'#FFFFFF','text-halo-color':'rgba(20,18,15,0.92)',
        'text-halo-width':1.9,'text-halo-blur':0.2}},
    {id:'lbl-show',type:'symbol',source:'showonly',minzoom:13.0,
      layout:{'symbol-placement':'line','text-field':['get','n'],
        'text-font':['APEX'],'text-size':w(8.5,9.5,11),'text-max-angle':75,
        'symbol-spacing':160,'text-padding':2},
      paint:{'text-color':'#6E6152','text-halo-color':'#EFE6D2','text-halo-width':1.5}},
    {id:'lbl-fsroad',type:'symbol',source:'strokes',minzoom:11.6,
      filter:['==',['get','c'],'fsroad'],
      layout:{'symbol-placement':'line','text-field':['get','lb'],
        'text-font':['APEX'],'text-size':w(8.5,10,12),
        'text-max-angle':70,'symbol-spacing':180,'text-padding':2},
      paint:{'text-color':'#4A423A','text-halo-color':'#EFE6D2','text-halo-width':1.5}},
    /* A110 · places. Circle plus label, no sprite sheet — see POIKIND. The
       dot appears before the name so a pin is visible at a zoom where its
       label will not fit, and `symbol-sort-key` puts fuel and trailheads ahead
       of picnic tables when they compete for space. */
    /* Badges, not dots (take 113 · T3): the id keeps 'poi-dot' because the
       layers panel and checks address it, but it is now the category badge. */
    {id:'poi-dot',type:'symbol',source:'poi',minzoom:11.4,
      layout:{'icon-image':['concat','bdg-',['get','k']],
        'icon-size':w(0.52,0.72,0.95),'icon-allow-overlap':true,
        'symbol-sort-key':['get','r']},
      paint:{}},
    {id:'poi-label',type:'symbol',source:'poi',minzoom:12.8,
      layout:{'text-field':['get','n'],'text-font':['APEX'],
        'text-size':w(8.5,10,11.5),'text-max-width':9,
        'text-offset':[0,1.15],'text-anchor':'top','text-padding':3,
        'symbol-sort-key':['get','r']},
      paint:{'text-color':['get','c'],'text-halo-color':'#FFFFFF',
        'text-halo-width':1.7}},
    /* Only the INDEX contour carries a number. Labelling every 40 ft line puts
       sixteen numbers on one hillside; labelling every 200 ft is what a paper
       quad does and is readable. */
    {id:'cont-label',type:'symbol',source:'cont',minzoom:13.2,
      layout:{visibility:'none','symbol-placement':'line',
        'text-field':['get','lb'],'text-font':['APEX'],
        'text-size':w(7.5,8.5,9.5),'text-max-angle':30,
        'symbol-spacing':600,'text-padding':6,'text-letter-spacing':0.04},
      filter:['==',['get','i'],1],
      paint:{'text-color':'#7A5C36','text-halo-color':'#EFE6D2',
        'text-halo-width':1.6}},
    /* A115 · the paddle corridor. Off by default — this is a different activity
       from the one the app opens on, and a river drawn over the trail network
       uninvited is clutter. Under the water layers so it reads as the river it
       is, above the contours that describe the ground it cuts through. */
    {id:'pad-case',type:'line',source:'paddle',minzoom:8,
      layout:{visibility:'none','line-join':'round','line-cap':'round'},
      paint:{'line-color':'#FFFFFF','line-width':w(3.2,5.5,9),'line-opacity':0.75}},
    {id:'pad-line',type:'line',source:'paddle',minzoom:8,
      layout:{visibility:'none','line-join':'round','line-cap':'round'},
      paint:{'line-color':'#1E6FA8','line-width':w(1.8,3.2,5.5)}},
    /* A76 · summits. A triangle because that is what a summit is on every map a
       rider has ever seen. Terrain, so it sits below the places you ride to and
       below your own marks — but above the contours that describe it. */
    {id:'peak-dot',type:'symbol',source:'peaks',minzoom:10.6,
      layout:{visibility:'none','text-field':'\u25B2','text-font':['APEX'],
        'text-size':w(8,10,12),'text-allow-overlap':true,'text-padding':0},
      paint:{'text-color':'#3A352E','text-halo-color':'#FFFFFF','text-halo-width':1.8}},
    {id:'peak-label',type:'symbol',source:'peaks',minzoom:11.4,
      layout:{visibility:'none','text-field':['get','lb'],'text-font':['APEX'],
        'text-size':w(8,9.5,11),'text-offset':[0,0.85],'text-anchor':'top',
        'text-max-width':10,'text-padding':4,'text-line-height':1.15},
      paint:{'text-color':'#3A352E','text-halo-color':'#FFFFFF','text-halo-width':1.9}},
    /* Access, launches and camps ON the river, each carrying its river mile so
       a shuttle can be planned from the map: which put-in is above which. */
    {id:'pad-dot',type:'symbol',source:'padpin',minzoom:9.5,
      layout:{visibility:'none',
        'icon-image':['concat','bdg-pad-',['get','k']],
        'icon-size':w(0.5,0.68,0.9),'icon-allow-overlap':true},
      paint:{}},
    {id:'pad-lbl',type:'symbol',source:'padpin',minzoom:12.4,
      layout:{visibility:'none','text-field':['get','lb'],'text-font':['APEX'],
        'text-size':w(8,9.5,11),'text-offset':[0,1],'text-anchor':'top',
        'text-max-width':9,'text-padding':4},
      filter:['!=',['get','k'],'dam'],
      paint:{'text-color':'#1C1A16','text-halo-color':'#FFFFFF','text-halo-width':1.9}},
    /* THE HAZARD LAYER. Dams and the impoundments above them, in the closure
       colour, on top of everything else this layer draws. Never filtered, never
       thinned by zoom, never hidden behind a pin. A112: if paddle mode cannot
       show these it does not ship. */
    {id:'pad-dam',type:'circle',source:'padpin',minzoom:8,
      layout:{visibility:'none'},
      filter:['==',['get','k'],'dam'],
      paint:{'circle-radius':w(4,6,8),'circle-color':'#C1121F',
        'circle-stroke-color':'#FFFFFF','circle-stroke-width':2}},
    {id:'pad-damlbl',type:'symbol',source:'padpin',minzoom:10.5,
      layout:{visibility:'none','text-field':['get','lb'],'text-font':['APEX'],
        'text-size':w(9,10.5,12),'text-offset':[0,1.1],'text-anchor':'top',
        'text-allow-overlap':false,'text-padding':2},
      filter:['==',['get','k'],'dam'],
      paint:{'text-color':'#8E0F19','text-halo-color':'#FFFFFF','text-halo-width':2.2}},
    /* A84 · your own marks. Drawn above the world's places: a POI is something
       that is there, a waypoint is something YOU decided mattered, and when
       they collide yours wins. */
    {id:'wpt-dot',type:'circle',source:'wpts',minzoom:10.5,
      paint:{'circle-radius':w(3.4,5.2,7),'circle-color':'#E2570F',
        'circle-stroke-color':'#FFFFFF','circle-stroke-width':1.8}},
    {id:'wpt-label',type:'symbol',source:'wpts',minzoom:12.2,
      layout:{'text-field':['get','n'],'text-font':['APEX'],
        'text-size':w(8,9.5,11),'text-offset':[0,1.05],'text-anchor':'top',
        'text-max-width':9,'text-padding':4},
      paint:{'text-color':'#2A2620','text-halo-color':'#FFFFFF','text-halo-width':1.9}},
    /* A75 · posted route numbers. "Two east of M 33" is how a rider says where
       they are, and the number is on every sign where the street name often is
       not. Placed after trail names — the trail you are riding still wins — but
       ahead of water, because a road number orients you and a pond does not.
       Styled as a badge rather than a name: tighter letter spacing, a heavier
       halo, and a colour of its own so a number reads as a number at a glance.
       Real shields would need a sprite sheet the build does not have. */
    /* M-routes wear the diamond, upright regardless of road bearing; every
       other ref keeps the along-line badge. */
    {id:'lbl-shield',type:'symbol',source:'refs',minzoom:10.8,
      filter:['==',['index-of','M-',['get','lb']],0],
      layout:{'symbol-placement':'line','symbol-spacing':420,
        'icon-image':'mi-diamond','icon-rotation-alignment':'viewport',
        'icon-size':w(0.72,0.92,1.05),'icon-allow-overlap':false,
        'text-field':['slice',['get','lb'],2],'text-font':['APEX'],
        'text-size':w(8,9.5,10.5),'text-rotation-alignment':'viewport',
        'text-allow-overlap':false},
      paint:{'text-color':'#1C1A16'}},
    {id:'lbl-ref',type:'symbol',source:'refs',minzoom:11.2,
      filter:['!=',['==',['index-of','M-',['get','lb']],0],true],
      layout:{'symbol-placement':'line','text-field':['get','lb'],
        'text-font':['APEX'],'text-size':w(9,10.5,12.5),
        'text-max-angle':70,'symbol-spacing':340,'text-padding':4,
        'text-letter-spacing':0.02},
      paint:{'text-color':'#1C1A16','text-halo-color':'#FFFFFF',
        'text-halo-width':2.2,'text-halo-blur':0.2}},
    /* A77 · water names. Placed AFTER every trail-name layer, because MapLibre
       resolves symbol collisions in layer order and the trail you are riding
       must always win against a pond. minzoom holds them back until the trail
       labels have stopped competing for space (take 57 tuned that density and
       this must not undo it — render.mjs counts trail names and would say so).
       Italic-feeling letter spacing and the water blue, so they read as terrain
       rather than as something you can ride. */
    {id:'lbl-lake',type:'symbol',source:'wlbl',minzoom:11.6,
      filter:['==',['get','c'],'water'],
      layout:{'text-field':['get','n'],'text-font':['APEX'],
        'text-size':w(8,9.5,11.5),'text-max-width':8,
        'text-letter-spacing':0.06,'text-padding':3},
      paint:{'text-color':'#4E93B8','text-halo-color':'#F2F3F0','text-halo-width':1.5,
        'text-opacity':0.95}},
    {id:'lbl-stream',type:'symbol',source:'wlbl',minzoom:12.6,
      filter:['==',['get','c'],'waterway'],
      layout:{'symbol-placement':'line','text-field':['get','n'],
        'text-font':['APEX'],'text-size':w(7.5,9,10.5),
        'text-max-angle':70,'symbol-spacing':420,'text-padding':4,
        'text-letter-spacing':0.04},
      paint:{'text-color':'#3E6A80','text-halo-color':'#EFE6D2','text-halo-width':1.6,
        'text-opacity':0.9}},
    {id:'lbl-road',type:'symbol',source:'strokes',minzoom:11.0,
      filter:['in',['get','c'],['literal',['paved','minor']]],
      layout:{'symbol-placement':'line','text-field':['get','lb'],
        'text-font':['APEX'],'text-size':w(8.5,10,12.5),
        'text-max-angle':70,'symbol-spacing':300,'text-padding':2},
      paint:{'text-color':'#6E6B66','text-halo-color':'#F5F6F3','text-halo-width':1.4}},
  ]},
  center:CTR,zoom:11.4,maxZoom:17,minZoom:5.2,
  /* Michigan, not just the download. Penning the map to the bundle bbox meant a
     rider 135 mi away could not see where he was relative to the area, and a
     blank screen outside the box read as "broken" instead of "not downloaded"
     (take 27 field report). The coverage outline below carries that meaning. */
  maxBounds:[[-91.5,41.0],[-81.0,49.2]],fadeDuration:0,
  attributionControl:{compact:true,
    customAttribution:'© OpenStreetMap · Michigan DNR · USDA Forest Service · USGS'}});

/* ── pins ──────────────────────────────────────────────────────────────── */
/* ══ ICONS (take 99) ════════════════════════════════════════════════════════
   Thirty-eight emoji were doing the work of an icon set. 😖 for "Wrong turn"
   renders as a different picture on every phone, 🏍 is a different bike on
   Samsung than on Pixel, and none of them share a weight or a grid — which is
   most of why the app read as unfinished next to a commercial one.

   Drawn instead: one 24x24 grid, 1.75 stroke, round caps, `currentColor` so an
   icon inherits whatever the control it sits in is doing. Inline SVG — no
   sprite sheet, no font, no fetch, and nothing to go missing offline.

   Deliberately NOT drawn: the machine (bike/quad/side-by-side). A recognisable
   motorcycle at 24 px in stroke is beyond what I can draw well, and a bad one
   is worse than none — the label already says "Dirt bike 24\"". It gets a
   generic vehicle mark and the words carry the meaning. */
var ICONS={
/* ── LUCIDE (take 113) ─────────────────────────────────────────────────────
   Professionally drawn open-source icons (ISC licence, lucide.dev) replacing
   every hand-drawn path. Jacob's field reports caught the hand-drawn set twice
   (broken wheels take 109; "the svgs don't look that good"). Icon geometry is a
   specialist craft; both reference apps use professional sets, so this one does
   too. Values are inner-SVG markup, inlined at build time from lucide-static —
   the app bundles nothing and calls nowhere. */
  layers:'<path d="M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z" /> <path d="M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12" /> <path d="M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17" />',
  vehicle:'<path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2" /> <circle cx="7" cy="17" r="2" /> <path d="M9 17h6" /> <circle cx="17" cy="17" r="2" />',
  home:'<path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8" /> <path d="M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />',
  here:'<line x1="2" x2="5" y1="12" y2="12" /> <line x1="19" x2="22" y1="12" y2="12" /> <line x1="12" x2="12" y1="2" y2="5" /> <line x1="12" x2="12" y1="19" y2="22" /> <circle cx="12" cy="12" r="7" />',
  fuel:'<path d="M14 13h2a2 2 0 0 1 2 2v2a2 2 0 0 0 4 0v-6.998a2 2 0 0 0-.59-1.42L18 5" /> <path d="M14 21V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v16" /> <path d="M2 21h13" /> <path d="M3 9h11" />',
  play:'<path d="M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z" />',
  stop:'<rect width="18" height="18" x="3" y="3" rx="2" />',
  alert:'<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3" /> <path d="M12 9v4" /> <path d="M12 17h.01" />',
  locate:'<line x1="2" x2="5" y1="12" y2="12" /> <line x1="19" x2="22" y1="12" y2="12" /> <line x1="12" x2="12" y1="2" y2="5" /> <line x1="12" x2="12" y1="19" y2="22" /> <circle cx="12" cy="12" r="7" /> <circle cx="12" cy="12" r="3" />',
  clock:'<circle cx="12" cy="12" r="10" /> <path d="M12 6v6l4 2" />',
  info:'<circle cx="12" cy="12" r="10" /> <path d="M12 16v-4" /> <path d="M12 8h.01" />',
  loop:'<path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8" /> <path d="M21 3v5h-5" />',
  star:'<path d="M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z" />',
  shield:'<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" />',
  search:'<path d="m21 21-4.34-4.34" /> <circle cx="11" cy="11" r="8" />',
  map:'<path d="M14.106 5.553a2 2 0 0 0 1.788 0l3.659-1.83A1 1 0 0 1 21 4.619v12.764a1 1 0 0 1-.553.894l-4.553 2.277a2 2 0 0 1-1.788 0l-4.212-2.106a2 2 0 0 0-1.788 0l-3.659 1.83A1 1 0 0 1 3 19.381V6.618a1 1 0 0 1 .553-.894l4.553-2.277a2 2 0 0 1 1.788 0z" /> <path d="M15 5.764v15" /> <path d="M9 3.236v15" />',
  sat:'<path d="m13.5 6.5-3.148-3.148a1.205 1.205 0 0 0-1.704 0L6.352 5.648a1.205 1.205 0 0 0 0 1.704L9.5 10.5" /> <path d="M16.5 7.5 19 5" /> <path d="m17.5 10.5 3.148 3.148a1.205 1.205 0 0 1 0 1.704l-2.296 2.296a1.205 1.205 0 0 1-1.704 0L13.5 14.5" /> <path d="M9 21a6 6 0 0 0-6-6" /> <path d="M9.352 10.648a1.205 1.205 0 0 0 0 1.704l2.296 2.296a1.205 1.205 0 0 0 1.704 0l4.296-4.296a1.205 1.205 0 0 0 0-1.704l-2.296-2.296a1.205 1.205 0 0 0-1.704 0z" />',
  target:'<circle cx="12" cy="12" r="10" /> <line x1="22" x2="18" y1="12" y2="12" /> <line x1="6" x2="2" y1="12" y2="12" /> <line x1="12" x2="12" y1="6" y2="2" /> <line x1="12" x2="12" y1="22" y2="18" />',
  phone:'<path d="M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384" />',
  close:'<path d="M18 6 6 18" /> <path d="m6 6 12 12" />',
  check:'<path d="M20 6 9 17l-5-5" />',
  pin:'<path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0" /> <circle cx="12" cy="10" r="3" />',
  truck:'<path d="M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2" /> <path d="M15 18H9" /> <path d="M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14" /> <circle cx="17" cy="18" r="2" /> <circle cx="7" cy="18" r="2" />',
  route:'<circle cx="6" cy="19" r="3" /> <path d="M9 19h8.5a3.5 3.5 0 0 0 0-7h-11a3.5 3.5 0 0 1 0-7H15" /> <circle cx="18" cy="5" r="3" />',
};

function ic(n,sz){
  var d=ICONS[n];
  if(!d)return '';
  /* Lucide entries are full inner markup (paths, circles, lines), not a single
     d-string — so they are embedded, not wrapped in one <path>. Stroke width 2
     is what the set is drawn for. */
  return '<svg class="ic" width="'+(sz||15)+'" height="'+(sz||15)+'" viewBox="0 0 24 24" '+
    'fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" '+
    'stroke-linejoin="round" aria-hidden="true">'+d+'</svg>'}

/* Twelve places rewrite a chip's label with textContent, which would wipe the
   icon inside it. One helper, so a chip's icon survives every state change. */
/* The markup carries __IC_name__ placeholders so the SVG is defined once, in
   ICONS, rather than pasted into fifteen buttons. */
function paintIcons(){
  /* Replace each BUTTON'S OWN children, never a shared parent's innerHTML.
     The first version rewrote #shell.innerHTML, which would have destroyed
     every event listener in the app — a fresh DOM with the same markup and
     nothing wired to it, and the map would still have drawn perfectly. */
  Array.prototype.forEach.call(document.querySelectorAll('#shell button'),
    function(b){
      if(b.innerHTML.indexOf('__IC_')<0)return;
      b.innerHTML=b.innerHTML.replace(/__IC_([a-z]+)__/g,
        function(_,n){return ic(n)})})}

function setChip(id,icon,label,on){
  var b=el(id);
  if(!b)return;
  b.innerHTML=ic(icon)+'<span>'+label+'</span>';
  /* The app already tests classes with indexOf on className everywhere else;
     using classList here would have added an API to the harness stub for a
     single call. Follow the convention the codebase has (take 99). */
  var base=(' '+b.className+' ').indexOf(' basebtn ')>=0?'basebtn':'chip';
  b.className=base+(on?' on':'')+(b.id==='c-act'?' actbtn':'')}

try{paintIcons()}catch(e){}

function mk(cls,txt){var d=document.createElement('div');d.className='pin '+cls;
  d.textContent=txt;return d}
/* Start pins on real anchors from whichever region loaded. */
function anchorOf(kind,skip){
  for(var i=0;i<PLACES.length;i++){var p=PLACES[i];
    if(p[3]===kind&&(!skip||p[0]!==skip))return [p[1],p[2]]}
  for(var i=0;i<PLACES.length;i++){var p=PLACES[i];
    if(!skip||p[0]!==skip)return [p[1],p[2]]}
  return CTR}
var HOME=anchorOf('town'),
    ME=anchorOf('site',PLACES.length?null:undefined);
if(ME[0]===HOME[0]&&ME[1]===HOME[1])ME=CTR.slice();
var hM=new maplibregl.Marker({element:mk('home','⌂')}).setLngLat(HOME).addTo(map);
var mM=new maplibregl.Marker({element:mk('me','◎')}).setLngLat(ME).addTo(map);
var arm=null;

el('c-home').addEventListener('click',function(){
  arm=arm==='home'?null:'home';syncArm();
  show(arm?'Tap the map to place <b>home</b>.':'Cancelled.','')});
el('c-me').addEventListener('click',function(){
  arm=arm==='me'?null:'me';syncArm();
  show(arm?"Tap the map to place <b>where you are</b>.":'Cancelled.','')});
function syncArm(){el('c-home').className='chip'+(arm==='home'?' arm':'');
  el('c-me').className='chip'+(arm==='me'?' arm':'')}

el('c-saved').addEventListener('click',function(){
  logAct('act  saved routes');buildSavedPanel()});

el('c-machine').addEventListener('click',function(){
  machIdx=(machIdx+1)%ORDER.length;machine=ORDER[machIdx];
  setChip('c-machine','vehicle',MACHINE[machine].lbl.replace(/^\S+\s/,''));
  applyMachine();
  var no=machineIllegal();
  clearRoute();show('Machine set to <b>'+MACHINE[machine].lbl.replace(/^\S+\s/,'')+
   '</b>. Routing respects what is legal for it, and the map now shows it: '+
   (no.length?'<b>'+no.length+'</b> kind'+(no.length>1?'s':'')+' of line faded '+
     'because they are too narrow for it. They are still real trails \u2014 just '+
     'not yours today.':'nothing on this map is off limits for it.'),'')});

var FUELS=[30,50,80,120,0],fi=1;
el('c-fuel').addEventListener('click',function(){fi=(fi+1)%FUELS.length;
  setChip('c-fuel','fuel',FUELS[fi]?FUELS[fi]+' mi':'off');
  if(last)renderRoutes(last)});

/* ── Dijkstra ──────────────────────────────────────────────────────────── */
/* Snap to the nearest node that has at least one edge this machine may legally
   use. Snapping to the geometrically nearest node strands a 72" side-by-side on
   a 50" trailhead and reports "no route" when a legal one exists 200 m away. */
function nearestNode(ll){
  var best=1e18,bi=-1;
  for(var i=0;i<NODES.length;i++){
    var ad=ADJ[i],legal=false;
    for(var k=0;k<ad.length;k++){
      /* the same predicate the router uses — a snap onto a node whose only
         edges are illegal for this machine either reports "no route" when a
         legal one exists, or starts the rider on one (take 24, take 80) */
      if(machineLegal(ad[k])){legal=true;break}}
    if(!legal)continue;
    var dx=NODES[i][0]-ll[0],dy=NODES[i][1]-ll[1],d=dx*dx*0.51+dy*dy;
    if(d<best){best=d;bi=i}}
  return bi}

function snapMiles(ll,ni){if(ni<0)return 0;
  var dx=(NODES[ni][0]-ll[0])*0.714*69,dy=(NODES[ni][1]-ll[1])*69;
  return Math.sqrt(dx*dx+dy*dy)}

function route(from,to,cost){
  var N=NODES.length,dist=new Float64Array(N),prev=new Int32Array(N),
      pe=new Int32Array(N),done=new Uint8Array(N);
  dist.fill(Infinity);prev.fill(-1);pe.fill(-1);dist[from]=0;
  var heap=[[0,from]];
  function push(v){heap.push(v);var i=heap.length-1;
    while(i>0){var p=(i-1)>>1;if(heap[p][0]<=heap[i][0])break;
      var t=heap[p];heap[p]=heap[i];heap[i]=t;i=p}}
  function pop(){var top=heap[0],last=heap.pop();
    if(heap.length){heap[0]=last;var i=0;
      for(;;){var l=2*i+1,r=l+1,s=i;
        if(l<heap.length&&heap[l][0]<heap[s][0])s=l;
        if(r<heap.length&&heap[r][0]<heap[s][0])s=r;
        if(s===i)break;var t=heap[s];heap[s]=heap[i];heap[i]=t;i=s}}
    return top}
  while(heap.length){var cur=pop(),d=cur[0],u=cur[1];
    if(done[u])continue;done[u]=1;if(u===to)break;
    var ad=ADJ[u];
    for(var k=0;k<ad.length;k++){var e=ad[k];
      if(e.c==='closed'||e.c==='fsclosed')continue;   /* never route through a closure */
      if(!machineLegal(e))continue;                    /* class AND per-vehicle (take 80) */
      var v=e.a===u?e.b:e.a;if(done[v])continue;
      var nd=d+cost(e);
      if(nd<dist[v]){dist[v]=nd;prev[v]=u;pe[v]=e.i;push([nd,v])}}}
  if(!isFinite(dist[to]))return null;
  var path=[],u=to;while(u!==from&&prev[u]>=0){path.push(EDGES[pe[u]]);u=prev[u]}
  return path.reverse()}

/* Designated ORV trail vs legal forest road vs pavement. All three are legal
   for the selected machine — the router cannot produce anything else — but they
   are very different rides. */
var DESIG={route72:1,trail50:1,moto24:1,mccct:1,fstrail:1};
var DIRT={fsroad:1,track:1};

function summarise(path){
  var mi=0,hrs=0,off=0,adv=0,hardest=0,names={},up=0,dn=0,prof=[],run=0;
  /* How much of this route is DESIGNATED ORV line, how much is legal forest
     road, how much is pavement. Jacob: "routes should show if it's fully
     approved, partly approved, or not" — crossing M-33 is inevitable and fine,
     riding a road for ten miles is a different trip (take 58). */
  var mDes=0,mDirt=0,mRoad=0;
  path.forEach(function(e){var L=e.L/1609.34;mi+=L;hrs+=L/(SPEED[e.c]||14);
    if(DESIG[e.c])mDes+=L; else if(DIRT[e.c])mDirt+=L; else mRoad+=L;
    if(!PAVED[e.c])off+=L;
    var a=attrs(e);if(a.auth!=='legal')adv+=L;
    var h=HARD.indexOf(e.c);if(h>hardest)hardest=h;
    if(e.n)names[e.n]=1;
    up+=UP[e.i];dn+=DN[e.i];
    var ep=edgeProfile(e.i),base=NE[e.a];
    for(var k=0;k<ep.length;k+=2)prof.push(base+ep[k]);
    run+=L});
  /* climbing is time as well as effort -- roughly 1 min per 100 ft up */
  hrs+=(up*3.28084/100)/60;
  return {mi:mi,hrs:hrs,off:off,adv:adv,hard:HARD[hardest],up:up,dn:dn,prof:prof,
          des:mDes,dirt:mDirt,road:mRoad,
          turns:Object.keys(names).length,path:path}}

/* sunset, NOAA short form — enough to answer "am I getting home in the dark" */
function sunset(lat,lon,date){
  var d=Math.floor((date-new Date(date.getFullYear(),0,0))/864e5);
  var g=(360/365.24)*(d+10)*Math.PI/180;
  var decl=-23.44*Math.cos(g)*Math.PI/180, L=lat*Math.PI/180;
  var cosH=(Math.cos(90.833*Math.PI/180)-Math.sin(L)*Math.sin(decl))/(Math.cos(L)*Math.cos(decl));
  if(cosH>1||cosH<-1)return null;
  var H=Math.acos(cosH)*180/Math.PI;
  var eq=229.18*(0.000075+0.001868*Math.cos(g)-0.032077*Math.sin(g)
        -0.014615*Math.cos(2*g)-0.040849*Math.sin(2*g));
  var mins=720+4*(-lon+H)-eq;
  var off=-date.getTimezoneOffset();
  return (mins+off)/60}

var PROFILES=[
  /* Most trail first, because it is what this app is FOR. Every other profile
     optimises for speed or ease, and pavement wins both — Return Home was
     handing back "no designated trail, 8.5 mi paved" to a man on a dirt bike
     (take 58). Designated ORV line is cheap, forest road is fine, pavement is
     expensive but never forbidden: crossing M-33 is inevitable. */
  {k:'trail',h:'Most trail',f:function(e){
     return e.L*(DESIG[e.c]?0.55:DIRT[e.c]?1.3:8)}},
  {k:'fast',h:'Fastest',f:function(e){return e.L/(SPEED[e.c]||14)}},
  {k:'easy',h:'Easiest',f:function(e){return e.L*(EFFORT[e.c]||2)+UP[e.i]*CLIMB_K}},
  {k:'pave',h:'Pavement soonest',f:function(e){return e.L*(PAVED[e.c]?1:9)}},
  {k:'short',h:'Shortest',f:function(e){return e.L}},
  {k:'flat',h:'Least climbing',f:function(e){return e.L*0.35+UP[e.i]*45}}
];

/* ══ SAVED ROUTES ═══════════════════════════════════════════════════════════
   A85, and the last thing take 25 named as missing from A28: "saving and naming
   a planned route so it survives an app restart."

   THE DESIGN DECISION: a saved route stores its INPUTS — the two points, the
   machine, the profile — and is re-routed when you open it. It does NOT store
   the line.

   That is a safety property, not a storage preference. The bundle carries
   twelve temporarily-closed segments and they are refreshed from the DNR on
   every build. A route frozen as geometry in October and replayed in May would
   happily draw you down something that closed in between, with every closure
   check bypassed because the answer was already on disk. Re-routing from the
   inputs runs the current legality filter, the current closures and the current
   machine rules every time.

   The cost is that a reopened route can differ from the one you saved. That is
   the correct behaviour and the app says so when the bundle has changed under it.

   localStorage is not a network call — it is same-origin state on the device,
   which PROTOCOL §8 draws the line around explicitly. Nothing here is sent
   anywhere. */
var SVKEY='apex.routes.v1';
/* ══ WAYPOINTS (A84) ════════════════════════════════════════════════════════
   A dropped pin was ephemeral: one at a time, no name, gone the moment you
   dropped another. "Mark the spot and get back to it" is the whole point of a
   pin on a trail — the truck, the washout, the good hill, where you left the
   gate open.

   Unlike a saved ROUTE, a waypoint IS stored as geometry, and the difference is
   worth stating. A route stores its inputs because closures move and a frozen
   line would replay a legality decision made against stale data (landmine 113).
   A point on the ground does not move and encodes no decision — it is an
   observation, and freezing an observation is what saving it means. */
var WPKEY='apex.waypoints.v1';

/* ══ THE FIRST-RUN GUIDE (A129) ═════════════════════════════════════════════
   Shown once, on first open, and never again on its own. Reachable afterwards
   from Tools -> How to use.

   The flag goes in the same localStorage the waypoints and saved routes use, so
   it survives a force-stop and dies with the app's data — nothing is sent
   anywhere and there is nothing to opt out of. If storage is unavailable the
   guide simply shows every time rather than failing: an extra tap is a smaller
   harm than a first-time rider getting no explanation at all. */
var GUIDEKEY='apex.guide.v1';

function guideSeen(){
  if(!svAvailable())return false;
  try{return localStorage.getItem(GUIDEKEY)==='1'}catch(e){return false}}

function guideShow(){
  var g=el('guide');
  if(!g)return;
  g.hidden=false;
  logAct('act  guide open');}

function guideClose(mark){
  var g=el('guide');
  if(!g)return;
  g.hidden=true;
  if(mark&&svAvailable()){try{localStorage.setItem(GUIDEKEY,'1')}catch(e){}}
  logAct('act  guide close');}

function wpLoad(){
  if(!svAvailable())return [];
  try{var a=JSON.parse(localStorage.getItem(WPKEY)||'[]');
      return Array.isArray(a)?a:[]}catch(e){return []}}

function wpWrite(a){
  if(!svAvailable())return false;
  try{localStorage.setItem(WPKEY,JSON.stringify(a));return true}catch(e){return false}}

function wpAdd(rec){
  var a=wpLoad().filter(function(x){return x.n!==rec.n});
  a.unshift(rec);
  if(a.length>200)a=a.slice(0,200);
  return wpWrite(a)?a:null}

function wpDel(n){return wpWrite(wpLoad().filter(function(x){return x.n!==n}))}

function wpName(at){
  /* One tap, no dialog — gloves, moving bike (take 79). Named from what is
     actually there: the address if we have one, else the nearest trail, else
     the coordinates, which are never a guess. */
  var a=null;
  try{a=addressAt(at)||addressAt(at,true)}catch(e){}
  if(a&&a.line)return a.line.replace(/^Nearest address\s*/i,'').slice(0,42);
  try{
    var e=nearestEdge(at);
    if(e&&e.e&&e.e.n)return e.e.n.slice(0,38)}catch(e2){}
  return at[1].toFixed(4)+', '+at[0].toFixed(4)}

function svAvailable(){
  /* file:// in some browsers throws on ACCESS, not on use, so probe rather than
     feature-detect (landmine 56 — a platform's return type, or its willingness
     to answer at all, is not something to assume) */
  try{var k='__apex_probe';localStorage.setItem(k,'1');localStorage.removeItem(k);
      return true}catch(e){return false}}

function svLoad(){
  if(!svAvailable())return [];
  try{var a=JSON.parse(localStorage.getItem(SVKEY)||'[]');
      return Array.isArray(a)?a:[]}catch(e){return []}}

function svWrite(a){
  if(!svAvailable())return false;
  try{localStorage.setItem(SVKEY,JSON.stringify(a));return true}catch(e){return false}}

function svAdd(rec){
  var a=svLoad();
  /* newest first, and a re-save under the same name replaces rather than
     accumulating near-duplicates the rider then has to tell apart */
  a=a.filter(function(x){return x.n!==rec.n});
  a.unshift(rec);
  if(a.length>40)a=a.slice(0,40);
  return svWrite(a)?a:null}

function svDel(name){
  var a=svLoad().filter(function(x){return x.n!==name});
  return svWrite(a)?a:null}

function svCurrent(name){
  /* What is on screen right now, as INPUTS.
     A loop is not flagged on the option record — I assumed it was and it is
     not (landmine 102). It is identifiable from the state that actually
     exists: buildLoops sets na === nb and the chip handler records LOOP_MI. */
  if(!last||last[sel]===undefined||!last[sel])return null;
  var o=last[sel],isLoop=(o.na===o.nb&&LOOP_MI>0);
  if(!RFROM)return null;
  return {n:name,k:isLoop?'loop':'route',
          f:RFROM.slice(),t:(!isLoop&&RTO)?RTO.slice():null,
          mi:isLoop?LOOP_MI:null,
          m:machine,p:o.k||null,
          r:BUNDLE.region||null,b:BUNDLE.hash||null,
          lbl:DESTLBL||null,ts:Date.now()}}

function svName(){
  /* One tap, no dialog. A rider in gloves on a moving bike should not meet a
     system prompt, so the name is generated from what the route IS and can be
     renamed later from the panel. */
  var o=last&&last[sel];
  if(!o)return 'Route';
  var d=new Date(),md=(d.getMonth()+1)+'/'+d.getDate();
  var isLoop=(o.na===o.nb&&LOOP_MI>0);
  return (isLoop?'Loop ':'')+o.s.mi.toFixed(1)+' mi'+
    (isLoop?'':' to '+(DESTLBL||'there'))+' · '+md}

function svOpen(rec){
  if(!rec)return;
  if(rec.r&&BUNDLE.region&&rec.r!==BUNDLE.region)
    return show('<b>'+rec.n+'</b> was saved in a different region ('+rec.r+
      '). Routes are only meaningful against the map they were planned on.','fail');
  if(!rec.f)return show('<b>'+rec.n+'</b> has no start point saved.','fail');
  /* Re-route, never replay. See the note on SVKEY: closures move between
     builds and a frozen line would bypass every check that exists to catch
     them. Say so when the data has changed underneath. */
  var stale=(rec.b&&BUNDLE.hash&&rec.b!==BUNDLE.hash);
  /* There is no syncMachine() — I called one that does not exist. The chip
     handler sets machIdx, machine and the label inline, so do the same three
     things here rather than inventing a helper (landmine 102: check the code,
     not your memory of it). */
  if(rec.m&&MACHINE[rec.m]){
    machine=rec.m;
    var _mi=ORDER.indexOf(rec.m);if(_mi>=0)machIdx=_mi;
    setChip('c-machine','vehicle',MACHINE[machine].lbl.replace(/^\S+\s/,''))}
  ME=rec.f.slice();if(mM)mM.setLngLat(ME);
  var note=stale?'<br><span class="sub">The map has been rebuilt since you saved '+
    'this — it has been routed again on the current data, so closures and '+
    'reroutes are up to date. The line may differ from the one you saved.</span>':'';
  if(rec.k==='loop'&&rec.mi){
    LOOP_MI=rec.mi;
    show('Rebuilding <b>'+rec.n+'</b>…'+note,'');
    setTimeout(function(){
      var a=nearestNode(ME);
      if(a<0)return show('<b>Nothing legal nearby</b> for that machine at the '+
        'saved start point.','fail');
      RFROM=ME.slice();RTO=ME.slice();
      var out=buildLoops(a,rec.mi);
      if(!out.length)return show('<b>'+rec.n+'</b> will not rebuild — the legal '+
        'network within reach no longer connects back at '+rec.mi+' mi.','fail');
      out.forEach(function(o){o.h+=' · '+o.s.mi.toFixed(1)+' mi';
        if(o.repeat>0.25)o.h+=' ⟲'});
      presentRoutes(out);svPrefer(rec.p)},30);
    return}
  if(!rec.t)return show('<b>'+rec.n+'</b> has no destination saved.','fail');
  routeToPoint(rec.t,rec.lbl||'there');
  setTimeout(function(){svPrefer(rec.p);if(note)el('panel').innerHTML+=note},80)}

function svPrefer(k){
  /* reselect the profile the route was saved with, if it still exists */
  if(!k||!last)return;
  for(var i=0;i<last.length;i++)if(last[i].k===k){
    sel=i;draw(last[i],true);
    Array.prototype.forEach.call(document.querySelectorAll('.rc'),function(d){
      d.className='rc'+(+d.dataset.i===sel?' sel':'')});
    return}}

function buildSavedPanel(){
  var a=svLoad().filter(function(x){return !x.r||!BUNDLE.region||x.r===BUNDLE.region});
  var wp=wpLoad().filter(function(x){return !x.r||!BUNDLE.region||x.r===BUNDLE.region});
  if(!svAvailable())
    return show('<b>Saved routes are unavailable here.</b> This browser will not '+
      'let the page store anything. In the app they work normally.','fail');
  if(!a.length&&!wp.length)
    return show('<b>Nothing saved yet.</b><br>Plan a route or a loop, then tap '+
      '<b>☆ Save</b> on the card you want to keep. It is stored on this phone '+
      'only — nothing is sent anywhere — and reopening it routes again on the '+
      'current map, so closures stay up to date.','');
  var h='<div id="routes">';
  if(wp.length){
    h+='<div class="sub" style="margin:2px 0 6px">'+wp.length+' waypoint'+
       (wp.length===1?'':'s')+'</div>';
    wp.forEach(function(x,i){
      h+='<div class="rc" data-wp="'+i+'"><h5>\u2691 '+x.n+'</h5>'+
         '<div class="sub">'+x.p[1].toFixed(5)+', '+x.p[0].toFixed(5)+'</div>'+
         '<div class="sub"><button class="chip" data-wpgo="'+i+'">Go to</button> '+
         '<button class="chip" data-wpren="'+i+'">Rename</button> '+
         '<button class="chip" data-wpdel="'+i+'">Delete</button></div></div>'})}
  a.forEach(function(r,i){
    h+='<div class="rc" data-sv="'+i+'"><h5>'+r.n+'</h5>'+
       '<div class="sub">'+(r.k==='loop'?'loop · '+r.mi+' mi target':'point to point')+
       ' · '+((MACHINE[r.m]||{}).lbl||r.m||'')+'</div>'+
       '<div class="sub"><button class="chip" data-svopen="'+i+'">Open</button> '+
       '<button class="chip" data-svren="'+i+'">Rename</button> '+
       '<button class="chip" data-svdel="'+i+'">Delete</button></div></div>'});
  show(h+'</div>','');
  var bind=function(attr,fn){
    Array.prototype.forEach.call(document.querySelectorAll('['+attr+']'),function(b){
      b.addEventListener('click',function(e){
        if(e&&e.stopPropagation)e.stopPropagation();
        fn(a[+b.getAttribute(attr)])})})};
  var bindw=function(attr,fn){
    Array.prototype.forEach.call(document.querySelectorAll('['+attr+']'),function(b){
      b.addEventListener('click',function(e){
        if(e&&e.stopPropagation)e.stopPropagation();
        fn(wp[+b.getAttribute(attr)])})})};
  bindw('data-wpgo',function(x){
    logAct('act  go to waypoint '+x.n);
    map.easeTo({center:x.p,zoom:Math.max(map.getZoom(),14),duration:500});
    placeCard(x.p,'wpt','\u2691 '+x.n)});
  bindw('data-wpdel',function(x){
    logAct('act  delete waypoint '+x.n);wpDel(x.n);wpDraw();buildSavedPanel()});
  bindw('data-wpren',function(x){
    var n=null;
    try{n=window.prompt?window.prompt('Name this waypoint',x.n):null}catch(e){n=null}
    if(!n)return;
    var all=wpLoad().map(function(y){return y.n===x.n?(y.n=n,y):y});
    wpWrite(all);wpDraw();buildSavedPanel()});
  bind('data-svopen',function(r){logAct('act  open saved '+r.n);svOpen(r)});
  bind('data-svdel',function(r){logAct('act  delete saved '+r.n);
    svDel(r.n);buildSavedPanel()});
  bind('data-svren',function(r){
    var n=null;
    try{n=window.prompt?window.prompt('Name this route',r.n):null}catch(e){n=null}
    if(!n)return;
    var all=svLoad().map(function(x){return x.n===r.n?(x.n=n,x):x});
    svWrite(all);buildSavedPanel()})}

var last=null,sel=null;
/* Route from ME to any point. Return Home is just this with HOME as the
   destination — take 33 pulled it out so a tapped pin can use the same five
   profiles, the same legality filter and the same closure handling. One router,
   many callers. */
function routeToPoint(dest,label){
  logAct('route to '+(label||'?'));
  RFROM=ME.slice();RTO=dest.slice();
  el('btn-home').disabled=true;show('Routing…','');
  setTimeout(function(){
    var a=nearestNode(ME),b=nearestNode(dest),out=[];
    DESTLBL=label||'there';
    el('btn-home').disabled=false;
    if(a<0||b<0)return show('<b>Nothing legal nearby</b> for a '+
      MACHINE[machine].lbl.replace(/^\S+\s/,'')+'. Every line within reach is off limits for that machine.','fail');
    var sa=snapMiles(ME,a),sb=snapMiles(dest,b);
    PROFILES.forEach(function(p){var pa=route(a,b,p.f);
      if(pa)out.push({h:p.h,k:p.k,s:summarise(pa),snap:sa+sb,na:a,nb:b})});
    if(!out.length)return show('<b>No legal route</b> for a '+
      MACHINE[machine].lbl.replace(/^\S+\s/,'')+' between those two points. Try a wider machine, or move the pins nearer a trail.','fail');
    presentRoutes(out)},30)}

var DESTLBL='home',RFROM=null,RTO=null;

/* Loops and point-to-point routes are the same thing once they exist: a list of
   options, each with a summary. One presenter, so cards, alternates, dashed
   approach legs and the fuel/dark warnings work for both.

   Take 40: the call sites for this were written before the function was, and
   the definition silently never landed — `presentRoutes is not defined` at the
   first tap. Landmine 38, and I did not re-grep after the edit. */
function presentRoutes(out){
  /* identical geometry across options is common on a sparse network — say so
     rather than showing cards that are secretly the same route */
  var seen={};out.forEach(function(o){var k=o.s.path.map(function(e){return e.i}).join(',');
    o.dup=seen[k]||false;seen[k]=true});
  last=out;sel=0;
  logAct('route '+out.length+' options, best '+out[0].s.mi.toFixed(1)+' mi');
  renderRoutes(out);draw(out[0],true)}

/* ══ LOOPS ══════════════════════════════════════════════════════════════════
   The third of "plan, ride, improvise" — you are at the truck with two hours of
   light and want a ride that ENDS where it starts. Point-to-point routing
   cannot express that: the shortest path from a node to itself is nothing.

   Method: place three waypoints on a circle around the start and route through
   them in turn, penalising edges already used so the return leg does not simply
   retrace the outbound. Circumference C = 2*pi*r, so a target of T miles wants
   r = T/(2*pi) — inflated, because trails do not run in circles and the real
   line is always longer than the crow-flight radius.

   Several bearings are tried; the ones that land nearest the target survive.
   They then become ordinary route options, so the cards, the elevation
   profiles, the fuel and dark warnings, the dashed approach legs and the
   alternates all work with no new UI. */
var LOOP_MI=15,LOOP_CHOICES=[6,10,15,20,30,40];

function nodeToward(from,bearingDeg,miles){
  var lat=NODES[from][1],lon=NODES[from][0],b=bearingDeg*Math.PI/180;
  var dLat=(miles/69.0)*Math.cos(b);
  var dLon=(miles/(69.0*Math.cos(lat*Math.PI/180)))*Math.sin(b);
  return nearestNode([lon+dLon,lat+dLat])}

/* cost that makes an already-ridden edge expensive but not forbidden — a
   network this sparse sometimes has exactly one legal way through */
function freshCost(base,used,factor){
  return function(e){return base(e)*(used[e.i]?factor:1)}}

function loopFrom(start,radiusMi,base,bearing0){
  var r=radiusMi, used={}, legs=[], nodes=[start];
  for(var k=0;k<3;k++){
    var n=nodeToward(start,(bearing0+k*120)%360,r);
    if(n<0||n===nodes[nodes.length-1])continue;
    nodes.push(n)}
  nodes.push(start);
  if(nodes.length<3)return null;
  for(var i=0;i<nodes.length-1;i++){
    if(nodes[i]===nodes[i+1])continue;
    var leg=route(nodes[i],nodes[i+1],freshCost(base,used,6));
    if(!leg||!leg.length)return null;
    leg.forEach(function(e){used[e.i]=(used[e.i]||0)+1});
    legs=legs.concat(leg)}
  if(!legs.length)return null;
  /* how much of it is ridden twice — a loop that doubles back is an out-and-back */
  var seen={},rep=0,tot=0;
  legs.forEach(function(e){var L=e.L/1609.34;tot+=L;if(seen[e.i])rep+=L;seen[e.i]=1});
  return {path:legs,repeat:tot?rep/tot:1,mi:tot}}

/* One radius guess is never right: a first cut at T/(2*pi) came back 33-126%
   long on this network, because trail does not run in circles and a
   trail-hungry cost wanders further than a fast one. Distance is close to
   proportional to radius, so scale and retry — four passes gets inside a few
   percent, and the best attempt is kept even if none do. */
function fitLoop(start,targetMi,base,bearing){
  var r=targetMi/(2*Math.PI), best=null;
  for(var i=0;i<4;i++){
    var L=loopFrom(start,r,base,bearing);
    if(!L)return best;
    var err=Math.abs(L.mi-targetMi)/targetMi;
    if(!best||err<best.err)best={err:err,L:L};
    if(err<0.08)break;
    r*=Math.max(0.35,Math.min(2.2,targetMi/L.mi));
  }
  return best}

function buildLoops(startNode,targetMi){
  var out=[];
  /* six bearings, and two cost shapes: quickest, and trail-hungry */
  /* Most trail FIRST, and costed from the same DESIG/DIRT tables the
     point-to-point profiles use. The old weights named moto24 and trail50 by
     hand and missed route72, mccct and fstrail entirely — so an MCCCT loop was
     costed no better than a gravel road — and the loop shown first was the
     fastest, which on a dirt bike means pavement (take 68). */
  var shapes=[
    {h:'Loop · most trail',k:'ltrail',f:function(e){
        return e.L*(DESIG[e.c]?0.55:DIRT[e.c]?1.3:8)}},
    {h:'Loop · fastest',k:'lfast',f:function(e){return e.L/(SPEED[e.c]||14)}}
  ];
  shapes.forEach(function(sh){
    var best=null;
    for(var b=0;b<360;b+=90){
      var f=fitLoop(startNode,targetMi,sh.f,b);
      if(!f)continue;
      /* score: distance error dominates, then how much is ridden twice */
      var score=f.err+f.L.repeat*0.9;
      if(!best||score<best.score){best={score:score,L:f.L}}}
    if(best)out.push({h:sh.h,k:sh.k,s:summarise(best.L.path),snap:0,
                      na:startNode,nb:startNode,repeat:best.L.repeat})});
  return out}
el('btn-home').addEventListener('click',function(){routeToPoint(HOME,'the ⌂ pin')});

function renderRoutes(out){
  var fuel=FUELS[fi],now=new Date(),
      ss=sunset(ME[1],ME[0],now),nowH=now.getHours()+now.getMinutes()/60;
  var html='<div id="routes">';
  out.forEach(function(o,i){
    var s=o.s,mins=Math.round(s.hrs*60),
        arrive=nowH+s.hrs,dark=(ss!==null&&arrive>ss),
        overFuel=(fuel&&s.mi>fuel);
    html+='<div class="rc'+(i===sel?' sel':'')+'" data-i="'+i+'">'+
      '<h5>'+o.h+(o.dup?' ·<span class="sub"> same line</span>':'')+'</h5>'+
      '<div class="big">'+s.mi.toFixed(1)+' <span class="sub">mi</span></div>'+
      '<div class="sub">'+(mins>=60?Math.floor(mins/60)+'h '+(mins%60)+'m':mins+' min')+
        ' · '+s.off.toFixed(1)+' mi off-pavement</div>'+
      /* the composition, in the order a rider cares about */
      (function(){
        var pd=s.mi>0?Math.round(100*s.des/s.mi):0;
        var tag=pd>=95?'<span class="tag legal">all designated trail</span>':
                pd>=50?'<span class="tag legal">'+pd+'% designated</span>':
                pd>0  ?'<span class="tag adv">'+pd+'% designated</span>':
                        '<span class="tag adv">no designated trail</span>';
        var bits=[];
        if(s.des>0.05)bits.push(s.des.toFixed(1)+' trail');
        if(s.dirt>0.05)bits.push(s.dirt.toFixed(1)+' forest road');
        if(s.road>0.05)bits.push(s.road.toFixed(1)+' paved');
        return '<div class="sub">'+tag+' '+bits.join(' · ')+'</div>'})()+
      '<div class="sub">hardest <b>'+label(s.hard)+'</b></div>'+
      spark(s.prof,s.up,s.dn)+
      '<div class="sub">climb <b>'+ft(s.up)+' ft</b> · drop '+ft(s.dn)+' ft</div>'+
      (overFuel?'<div class="sub warn">⛽ '+(s.mi-fuel).toFixed(1)+' mi past your range</div>':
        (fuel?'<div class="sub good">⛽ within range</div>':''))+
      (dark?'<div class="sub warn">☾ arrives after dark</div>':'')+
      (s.adv>0.05?'<div class="sub warn">'+s.adv.toFixed(1)+' mi unverified (OSM)</div>':
        '<div class="sub good">fully on designated line</div>')+
      (o.snap>0.15?'<div class="sub warn">+'+o.snap.toFixed(1)+
        ' mi off-network (dashed) to reach the trail</div>':'')+
      '</div>'});
  html+='</div>';
  /* Below the cards, not inside them: a button nested in a selectable card
     needs stopPropagation on every path, and the thing a rider means by "save"
     is the option currently chosen. */
  /* Jacob, take 82 in the field: "I closed the interface for directions and I
     still see the lines on the map for the last selected path." clearRoute()
     has existed since take 33 and was never bound to anything a rider could
     press — only to side effects of changing machine or moving a pin. Dismissing
     a panel is not the same gesture as discarding a plan, so this is explicit
     rather than automatic. */
  html+='<div class="sub" style="margin-top:7px">'+
    '<button class="chip" id="btn-save">\u2606 Save this route</button> '+
    '<button class="chip" id="btn-clear">\u2715 Clear route</button></div>';
  show(html,'');
  var cb2=el('btn-clear');
  if(cb2)cb2.addEventListener('click',function(){
    logAct('act  cleared route');
    clearRoute();last=null;sel=null;
    show('Route cleared. The map is back to just the network.','')});
  var sb=el('btn-save');
  if(sb)sb.addEventListener('click',function(){
    var rec=svCurrent(svName());
    if(!rec)return show('Nothing to save yet.','fail');
    if(!svAdd(rec))return show('<b>Could not save.</b> This browser will not let '+
      'the page store anything; in the app it works normally.','fail');
    logAct('act  saved route '+rec.n);
    show('Saved as <b>'+rec.n+'</b>.<br><span class="sub">Kept on this phone only. '+
      'Reopening it routes again on the current map, so closures and reroutes '+
      'stay up to date \u2014 the line may differ from today\u2019s.</span>','pass')});
  Array.prototype.forEach.call(document.querySelectorAll('.rc'),function(c){
    c.addEventListener('click',function(){
      sel=+c.dataset.i;logAct('act  picked '+((last[sel]||{}).h||sel));
      /* Toggle the class in place. Re-rendering the strip reset scrollLeft to 0
         on every tap, which is why scrolling felt broken even once it worked. */
      Array.prototype.forEach.call(document.querySelectorAll('.rc'),function(d){
        d.className='rc'+(+d.dataset.i===sel?' sel':'')});
      draw(last[sel],false);
      try{c.scrollIntoView({behavior:'smooth',block:'nearest',inline:'nearest'})}
      catch(e){}})}) }


/* Elevation profile per option. A 12 mile route with 900 ft of climbing is a
   different ride from a 12 mile route with 200, and the number alone does not
   land the way the shape does. */
/* The elevation profile was a 128x26 hairline with no numbers — the shape of
   the ride and nothing else. Filled now, full card width, and it says the low,
   the high, and the climb, because "how much climbing" is a question with an
   answer we already compute (take 68). */
function spark(p,up,dn){
  if(!p||p.length<3)return '';
  var lo=Math.min.apply(null,p),hi=Math.max.apply(null,p),r=Math.max(1,hi-lo);
  var W=250,H=44,step=Math.max(1,Math.floor(p.length/W)),pts=[],n=0,tot=Math.ceil(p.length/step);
  for(var i=0;i<p.length;i+=step,n++){
    pts.push((n*W/tot).toFixed(1)+','+(H-2-((p[i]-lo)/r)*(H-8)).toFixed(1))}

  return '<div class="prof">'+
    '<svg viewBox="0 0 '+W+' '+H+'" preserveAspectRatio="none" '+
      'style="display:block;width:100%;height:44px">'+
      '<polygon points="0,'+H+' '+pts.join(' ')+' '+W+','+H+'" fill="rgba(143,174,99,0.22)"/>'+
      '<polyline points="'+pts.join(' ')+'" fill="none" stroke="#8FAE63" '+
        'stroke-width="1.6" vector-effect="non-scaling-stroke"/></svg>'+
    '<div class="profax"><span>'+ft(lo)+' ft</span>'+
      '<span>'+ft(hi)+' ft</span></div></div>'}

function label(c){return {route72:'ORV route 72"',trail50:'ORV trail 50"',
  moto24:'motorcycle 24"',mccct:'MCCCT',fstrail:'USFS trail',fsroad:'USFS road',
  paved:'pavement',minor:'county road',track:'two-track'}[c]||c}

function geomOf(o){return o.s.path.map(function(e){return {type:'Feature',properties:{},
  geometry:{type:'LineString',coordinates:decode(GR.g[e.i])}}})}

/* fit=true only on the first draw. Re-framing on every card tap read as the map
   "shifting over randomly" while comparing options that share most of their
   corridor — and it hid the very change it was meant to show. */
function draw(o,fit){
  var fs=geomOf(o);
  /* The gap between a pin and the network. The cards have always SAID
     "+0.5 mi off-network to the pins" while the line silently started at the
     nearest node — so a route to a pin in the trees looked broken. Dashed,
     because you are covering it off the designated network. */
  var legs=[];
  function leg(from,to){
    if(!from||!to)return;
    if(mi(from,to)<0.02)return;
    legs.push({type:'Feature',properties:{},
      geometry:{type:'LineString',coordinates:[from,to]}})}
  if(o.na>=0)leg(RFROM,[NODES[o.na][0],NODES[o.na][1]]);
  if(o.nb>=0)leg([NODES[o.nb][0],NODES[o.nb][1]],RTO);
  try{map.getSource('approach').setData({type:'FeatureCollection',features:legs})}catch(e){}
  map.getSource('route').setData({type:'FeatureCollection',features:fs});
  /* Every other option, dimmed underneath. Five routes over the same 3.7 mi
     corridor look identical one at a time; against the alternatives the
     difference is obvious at a glance — the pattern every first-party map uses. */
  var others=[];
  (last||[]).forEach(function(x){if(x!==o)others=others.concat(geomOf(x))});
  map.getSource('alt').setData({type:'FeatureCollection',features:others});
  if(!fit)return;
  var b=new maplibregl.LngLatBounds();
  fs.concat(legs).forEach(function(f){
    f.geometry.coordinates.forEach(function(c){b.extend(c)})});
  /* The chip strip floats over the bottom of the map, so 40 px of padding put
     the end of the route underneath it. Clear the strip's real height. */
  var strip=0;
  try{var r=el('rail-chips')||document.querySelector('.strip');
    if(r)strip=Math.round(r.getBoundingClientRect().height)}catch(e){}
  map.fitBounds(b,{padding:{top:64,bottom:40+strip,left:36,right:36},duration:800})}
function clearRoute(){map.getSource('route').setData({type:'FeatureCollection',features:[]});
  try{map.getSource('alt').setData({type:'FeatureCollection',features:[]});
      map.getSource('approach').setData({type:'FeatureCollection',features:[]})}catch(e){}
  last=null;sel=null}






/* ══ SEARCH ═════════════════════════════════════════════════════════════════
   Landmine 19: vector tiles only hold what is in the current viewport, so you
   cannot search them for somewhere you are not already looking. The index is
   separate and built at load from data already in the payload — 1,049 names and
   3,706 junction descriptors that were sitting there unsearchable. */
var IDX=null;
function buildIndex(){
  if(IDX)return IDX;
  var seen={},rows=[];
  for(var i=0;i<EDGES.length;i++){var e=EDGES[i];
    [[e.n,'trail'],[e.id,'number']].forEach(function(p){
      var s=p[0];if(!s||seen[s])return;seen[s]=1;
      var g=decode(GR.g[i]),m=g[(g.length/2)|0];
      rows.push({t:s,k:(e.c==='paved'||e.c==='minor'||e.c==='fsroad')?'road':p[1],c:m,cls:e.c})})}
  for(var k in JX){var lab=JX[k].map(function(x){return NM[x]}).join(' × ');
    if(seen[lab])continue;seen[lab]=1;
    rows.push({t:lab,k:'junction',c:[NODES[k][0],NODES[k][1]],cls:'jx'})}
  PLACES.forEach(function(p){if(seen[p[0]])return;seen[p[0]]=1;
    rows.push({t:p[0],k:'place',c:[p[1],p[2]],cls:'place'})});
  if(ADDR&&ADDR.names){
    /* one entry per street, positioned on its first segment's midpoint */
    var first={};
    ADDR.segs.forEach(function(g){if(first[g[0]]===undefined)first[g[0]]=g});
    ADDR.names.forEach(function(nm,i){
      if(seen[nm]||first[i]===undefined)return;seen[nm]=1;var g=first[i];
      rows.push({t:nm,k:'street',c:[(g[1]+g[3])/2,(g[2]+g[4])/2],cls:'addr'})})}
  rows.forEach(function(r){r.l=r.t.toLowerCase();
    /* compressed: spaces and punctuation stripped, so "pinkstore" finds
       "Pink Store" and "h5717" finds "H57-17" (take 73) */
    r.z=r.l.replace(/[^a-z0-9]/g,'')});
  IDX=rows;return rows}

var KRANK={address:0,place:1,trail:2,number:3,road:4,street:5,junction:6};
function search(q){
  q=q.trim().toLowerCase();if(q.length<1)return [];
  var rows=buildIndex(),out=[];
  /* a typed street address resolves to a point and leads the results */
  var gc=geocode(q);
  if(gc)out.push([-1,-1,0,{t:gc.t,k:'address',c:gc.c,cls:'addr'}]);
  var qz=q.replace(/[^a-z0-9]/g,'');
  for(var i=0;i<rows.length;i++){var r=rows[i],p=r.l.indexOf(q);
    if(p>=0){
      /* exact, then start-of-string, then start-of-word, then anywhere */
      var s=r.l===q?0:p===0?1:(r.l[p-1]===' '||r.l[p-1]==='(')?2:3;
      out.push([s,(KRANK[r.k]||5),r.t.length,r]);continue}
    /* "pinkstore" -> Pink Store: the query with spacing squeezed out */
    if(qz.length>=3&&r.z.indexOf(qz)>=0)out.push([4,(KRANK[r.k]||5),r.t.length,r])}
  /* one wrong or missing character — the gloved-thumb tier. Only when nothing
     better matched, and only for queries long enough to mean something. */
  if(!out.length&&qz.length>=4){
    for(var i2=0;i2<rows.length;i2++){var r2=rows[i2];
      if(near1(qz,r2.z))out.push([5,(KRANK[r2.k]||5),r2.t.length,r2])}}
  out.sort(function(a,b){return a[0]-b[0]||a[1]-b[1]||a[2]-b[2]});
  return out.slice(0,9).map(function(x){return x[3]})}

/* Does needle occur in hay with at most one substitution, insertion or
   deletion? Bounded prefix scan; 3,353 entries per keystroke is cheap. */
function near1(needle,hay){
  var n=needle.length;
  for(var st=0;st<=Math.max(0,hay.length-n+1);st++){
    var i=0,j=st,miss=0,end=Math.min(hay.length,st+n+1);
    while(i<n&&j<end){
      if(needle[i]===hay[j]){i++;j++;continue}
      if(miss++)break;
      if(needle[i+1]===hay[j]){i++;continue}
      if(needle[i]===hay[j+1]){j++;continue}
      i++;j++}
    if(i>=n&&miss<=1)return true}
  return false}

function renderHits(list){
  if(!list.length){el('hits').innerHTML=
    '<div class="hit">No match. Try a code like <b>TMM</b> or <b>H58</b>.</div>';return}
  el('hits').innerHTML=list.map(function(r,i){
    return '<div class="hit" data-i="'+i+'"><b>'+r.t+'</b><i>'+r.k+'</i></div>'}).join('');
  Array.prototype.forEach.call(document.querySelectorAll('.hit'),function(d){
    if(d.dataset.i===undefined)return;
    d.addEventListener('click',function(){
      var r=list[+d.dataset.i];if(!r)return;
      map.easeTo({center:r.c,zoom:r.k==='place'?13.2:14.6,duration:800});
      el('srch').className='';el('c-search').className='chip';
      /* Every hit becomes a place card, so a searched address can be made home
         or routed to with the same two taps as a dropped pin. */
      dropPin(r.c.slice());
      placeCard(r.c,'drop',r.t)})})}

el('c-search').addEventListener('click',function(){
  var on=el('srch').className.indexOf('on')<0;
  el('srch').className=on?'on':'';el('c-search').className='chip'+(on?' on':'');
  if(on){el('q').focus();
    var q0=el('q').value||'';
    if(q0){renderHits(search(q0))}
    else{show(jumpChipsHTML(),'');wireJumpChips(el('panel'))}}});
el('q').addEventListener('input',function(){
  var q=el('q').value;
  if(!q){show(jumpChipsHTML(),'');wireJumpChips(el('panel'));return}
  renderHits(search(q))});

/* ══ DIRECTIONS ═════════════════════════════════════════════════════════════
   A blue line is not an instruction. Someone who is lost and tired needs words
   they can read once and act on, and a turn list is also what you would relay
   over a radio. Consecutive edges on the same way collapse into one step. */
function turnWord(d){
  var a=((d+540)%360)-180,x=Math.abs(a);
  if(x<22)return ['Continue','↑'];
  if(x<50)return [a<0?'Bear left':'Bear right',a<0?'↖':'↗'];
  if(x<115)return [a<0?'Turn left':'Turn right',a<0?'←':'→'];
  if(x<160)return [a<0?'Sharp left':'Sharp right',a<0?'↰':'↱'];
  return ['Turn around','↻']}

function directions(path,startNode){
  if(!path||!path.length)return [];
  var cur=startNode,legs=[];
  for(var i=0;i<path.length;i++){var e=path[i],g=decode(GR.g[e.i]);
    var fwd=(e.a===cur);if(!fwd)g=g.slice().reverse();
    legs.push({e:e,g:g,name:e.n||label(e.c),id:e.id,
      inB:bearing(g[0],g[Math.min(1,g.length-1)]),
      outB:bearing(g[Math.max(0,g.length-2)],g[g.length-1])});
    cur=fwd?e.b:e.a}
  var steps=[],acc=null;
  for(var i=0;i<legs.length;i++){var L=legs[i];
    var key=L.name+'|'+(L.id||'');
    if(acc&&acc.key===key){acc.mi+=L.e.L/1609.34;acc.up+=UP[L.e.i];acc.out=L.outB;
      continue}
    if(acc)steps.push(acc);
    acc={key:key,name:L.name,id:L.id,cls:L.e.c,mi:L.e.L/1609.34,up:UP[L.e.i],
      inB:L.inB,out:L.outB,at:i}}
  if(acc)steps.push(acc);
  for(var i=0;i<steps.length;i++){
    steps[i].turn=i===0?['Start on','●']:turnWord(steps[i].inB-steps[i-1].out)}
  return steps}

el('btn-steps').addEventListener('click',function(){
  if(!last||sel===null)return show('Pick a <b>Return home</b> route first — directions describe the route you chose.','fail');
  var a=nearestNode(ME),steps=directions(last[sel].s.path,a);
  if(!steps.length)return show('No steps.','fail');
  var tot=0,html='<div id="steps">';
  /* Each step said how long IT is, and nothing said where you are in the ride.
     Mid-ride the question is "I have done about four miles — which step am I
     on", so every step now carries the running total at its START. `tot` was
     already accumulated for the header and thrown away (take 70). */
  steps.forEach(function(s){
    var at=tot;tot+=s.mi;
    /* "Turn left two-track" reads as if the trail is named two-track. It is not
       named at all — say so rather than dressing a class up as a name. */
    var named=s.name&&!/^(two-track|forest road|road|paved|trail)$/i.test(s.name);
    var nm=named?(s.name+(s.id&&s.id!==s.name?' \u00b7 '+s.id:''))
                :('unnamed '+(s.name||'track')+(s.id?' \u00b7 '+s.id:''));
    html+='<div class="st"><div class="ar">'+s.turn[1]+'</div><div class="tx">'+
      s.turn[0]+' '+(named?'<b>'+nm+'</b>':'<i class="unn">'+nm+'</i>')+
      (MACHINE[machine].ok.indexOf(s.cls)<0?' <span class="tag shut">illegal</span>':'')+
      (s.up>8?'<br><span style="color:#C9A227">climbs '+ft(s.up)+' ft</span>':'')+
      '</div><div class="d">'+(s.mi<0.1?(s.mi*5280|0)+' ft':s.mi.toFixed(1)+' mi')+
      (at>0.05?'<div class="at">at '+at.toFixed(1)+' mi</div>':'')+
      '</div></div>'});
  html+='</div>';
  show('<span class="tn">'+steps.length+' steps · '+tot.toFixed(1)+
    ' mi</span><span class="tag legal">'+last[sel].h+'</span>'+html,'')})

/* ══ BASEMAP ════════════════════════════════════════════════════════════════
   PROTOCOL §8 as revised at take 10: provisioning may use the network, the
   field may not. Imagery is the size driver and it is measured, not guessed --
   z16 is 159 MB for a riding area and 36.6 GB statewide, which is what settles
   imagery as a per-region download you do at home the night before.

   In satellite mode a pale casing goes under the trail lines. Dark ink on dark
   jack pine is unreadable, and a trail you cannot see is not on the map. */
/* Every route class, grouped the way a rider thinks about them. `sw` is the
   swatch colour shown in the panel, so the legend cannot drift from the map:
   both read this table. `dash` marks the ones routing will never use. */
/* Every swatch reads PAL — the same object the style paints from — so the
   picker and the map cannot disagree. It used to carry its own copy of the
   colours and had already drifted by dE 12.9 on two-track (take 77).

   `tier` rows are legend-only: they explain a colour without filtering, because
   ORV/dirt-bike is ONE activity drawn in THREE colours and a single blue swatch
   standing for green, blue and black explained none of them. Green/blue/black
   is the universal trail-map grammar; it is learnable the moment it is stated
   once, and until take 77 nothing in the app stated it. */
/* Drawn, and deliberately NOT in the legend. Declared here rather than left as
   a standing note in the gate, because a note that always lists three names
   carries no signal — a fourth would join it silently (landmine 85's family).
   With this list the gate can FAIL on anything drawn that is neither explained
   nor exempt.
   Grey means road. Nobody needs a swatch to be told that, and two more rows
   costs panel height on a 360 px screen for information the map already gives.
   Jacob, take 77, asked directly. */
var LEGEND_EXEMPT=['minor','paved'];

var ACTS=[
  {k:'all',  h:'All routes',        sw:PAL.trail50},
  {k:'orv',  h:'ORV / dirt bike',   sw:PAL.trail50, cls:['route72','trail50','moto24','mccct','fstrail']},
  {k:'_t1',  h:'  easy · 72" route',      sw:PAL.route72, tier:1},
  {k:'_t2',  h:'  moderate · 50" trail',  sw:PAL.trail50, tier:1},
  {k:'_t3',  h:'  difficult · 24" / MCCCT',sw:PAL.mccct,  tier:1},
  {k:'dirt', h:'Two-track',         sw:PAL.track,  cls:['track']},
  {k:'_fr',  h:'  forest road · drivable', sw:PAL.fsroad, tier:1},
  {k:'_cl',  h:'  closed · do not ride',   sw:PAL.closed, tier:1},
  {k:'foot', h:'Hiking',            sw:PAL.foot,   cls:['foot'], dash:1},
  {k:'horse',h:'Equestrian',        sw:PAL.horse,  cls:['horse'], dash:1},
  {k:'snow', h:'Snowmobile / ski',  sw:PAL.snow,   cls:['snow','snowmob'], dash:1},
  {k:'nfs',  h:'NFS trails',        sw:PAL.nfsmoto,cls:['nfsmoto'], dash:1}
];
/* ══ MACHINE LEGALITY ON THE MAP ════════════════════════════════════════════
   A86. The router has refused illegal line since take 7, but the MAP said
   nothing: a 24" motorcycle singletrack and a 72" ORV route were drawn
   identically, so a rider planning on a side-by-side saw a dense network, chose
   a line, and only learned it was off-limits when routing declined. The app
   knew the whole time and did not say.

   DIMMED, not hidden and not dashed. Hidden would be dishonest about what
   exists — the same reason non-ORV trails are drawn at all (landmine 34's
   spirit). Dashed already means "not yours to ride, ever", and a motorcycle
   trail is a perfectly legal ORV trail that simply will not take a 72" machine;
   conflating the two would be a false statement about the world. Opacity says
   what is true: still there, still a trail, not for what you are on today.

   Closed line is left at full strength. It is closed to everything, red already
   says so, and fading it would weaken the one colour that must not be missed. */
var MACH_DIM=0.30;
var MACH_LAYERS=['casing','casing-track','casing-fsroad','minor','paved',
                 'fsroad','track','route72','fstrail','trail50','mccct','moto24'];
var OPA_BASE=null;

function applyMachine(){
  if(!map||!map.getLayer)return;
  /* Base opacities are READ FROM THE STYLE once, never copied into a second
     table. The casings carry 0.95 / 0.75 / 0.55 and those numbers must not
     exist in two places — that is exactly how the legend drifted from the map
     for ten takes (landmine 107). */
  if(!OPA_BASE){
    OPA_BASE={};
    MACH_LAYERS.forEach(function(id){
      if(!map.getLayer(id))return;
      var v=map.getPaintProperty(id,'line-opacity');
      OPA_BASE[id]=(typeof v==='number')?v:1})}
  var ok=(MACHINE[machine]||{}).ok||[];
  MACH_LAYERS.forEach(function(id){
    if(!map.getLayer(id))return;
    var b=OPA_BASE[id];
    if(b===undefined)b=1;
    map.setPaintProperty(id,'line-opacity',
      ['case',['in',['get','c'],['literal',ok]],b,b*MACH_DIM])});
  var lg=el('machnote');
  if(lg)lg.textContent=MACHINE[machine].lbl.replace(/^\S+\s/,'')+
    ' — faded line is legal ORV trail your machine is too wide for';}

function machineIllegal(){
  /* which drawn network classes the current machine may not use — for the
     self-test and the picker, so the count is never asserted from memory */
  var ok=(MACHINE[machine]||{}).ok||[];
  return ['route72','trail50','fstrail','mccct','moto24','track','fsroad']
    .filter(function(c){return ok.indexOf(c)<0})}

var TRAIL_LAYERS=['route72','trail50','moto24','mccct','fstrail'];
var act='all';

function actLabel(){
  var a=ACTS.filter(function(x){return x.k===act})[0];
  setChip('c-act',act==='all'?'vehicle':'target',a.h);
  el('c-act').className='basebtn actbtn'+(act==='all'?'':' on')}

function applyAct(){
  /* Roads stay visible whatever is selected — you still need to know where the
     road is, especially when the answer to "can I ride this" is no. */
  var a=ACTS.filter(function(x){return x.k===act})[0],sel=a.cls||null;
  TRAIL_LAYERS.forEach(function(id){
    map.setLayoutProperty(id,'visibility',
      (!sel||sel.indexOf(id)>=0)?'visible':'none')});
  map.setLayoutProperty('track','visibility',
    (!sel||sel.indexOf('track')>=0)?'visible':'none');
  var showCls=(a.cls||[]).filter(function(c){
    return ['foot','horse','snow','snowmob','nfsmoto'].indexOf(c)>=0});
  if(!sel){map.setFilter('show-line',null);map.setFilter('lbl-show',null);
    map.setLayoutProperty('show-line','visibility','visible');
    map.setLayoutProperty('lbl-show','visibility','visible')}
  else if(showCls.length){
    var f=['in',['get','c'],['literal',showCls]];
    map.setFilter('show-line',f);map.setFilter('lbl-show',f);
    map.setLayoutProperty('show-line','visibility','visible');
    map.setLayoutProperty('lbl-show','visibility','visible')}
  else{map.setLayoutProperty('show-line','visibility','none');
    map.setLayoutProperty('lbl-show','visibility','none')}
  actLabel()}

function buildActPanel(){
  var p=el('actpanel');
  p.innerHTML=ACTS.map(function(a){
    /* tier rows EXPLAIN a colour; they do not filter by it. Rendered without a
       data-k so the binding below skips them — guarding at bind time rather
       than with a :not() selector, because the harness models dataset and
       need not model every CSS selector (landmine 62). */
    return '<button class="actrow'+(a.tier?' tierrow':'')+
      (!a.tier&&a.k===act?' on':'')+'"'+(a.tier?'':' data-k="'+a.k+'"')+'>'+
      '<span class="sw'+(a.dash?' dash':'')+'" style="'+
        (a.dash?'color:'+a.sw+';background-color:transparent':'background-color:'+a.sw)+'"></span>'+
      '<span>'+a.h+'</span></button>'}).join('');
  Array.prototype.forEach.call(p.querySelectorAll('.actrow'),function(b){
    if(!b.dataset||!b.dataset.k)return;
    b.addEventListener('click',function(){
      act=b.dataset.k;applyAct();buildActPanel();p.hidden=true;
      logAct('tap','activity '+act)})})}

var BASEMAPS=['Map','Satellite','Hybrid'],bmi=0;
function setBasemap(i){
  if(!SAT_OK){bmi=0;setChip('c-base','map','Map');
    map.setLayoutProperty('sat','visibility','none');
    return}
  bmi=i%BASEMAPS.length;
  var m=BASEMAPS[bmi],sat=(m!=='Map');
  map.setLayoutProperty('sat','visibility',sat?'visible':'none');
  /* The casing is no longer a satellite-only trick: it separates a
     difficulty-coloured trail from the road network on ANY base, and this
     line was switching it off on the default map (take 46). */
  /* Hide the layer, do not just fade it. A raster layer at opacity 0 is still
     uploaded and drawn every frame — real GPU work for something invisible, and
     battery is the one thing about this app still unmeasured (A18). Relief is
     off by default, so that cost was being paid on every frame by default. */
  /* Ask the map, not a chip that no longer exists. This read the className of
     an element the layers panel replaced and threw on every basemap change
     (take 90). */
  var reliefOn=false;
  try{reliefOn=map.getLayoutProperty('hillshade','visibility')!=='none'}catch(e){}
  map.setLayoutProperty('hillshade','visibility',reliefOn?'visible':'none');
  if(reliefOn)map.setPaintProperty('hillshade','raster-opacity',sat?0.16:0.42);
  /* Satellite used to force every label off — from before labels had a dark
     halo, when dark-on-light was unreadable over jack pine. They are white on
     a halo now and survive it. Worse, lbl-show was NOT in LBL, so on satellite
     the only names left were trails you may NOT ride: "Shore To Shore Trail"
     labelled, the loop under your wheels not (take 57). */
  /* Derived, not listed — and note the comment above records this exact bug
     already happening once at take 57, when lbl-show was missing from the array.
     It happened again at takes 87-89 with six more layers. A copy of a set
     drifts from the set; ask the map (take 90, landmine 107). */
  /* This used to re-apply lbl-trail's visibility to EVERY symbol layer on every
     basemap change. The reason is in the comment above and it expired: labels
     have a dark halo now and survive satellite, so the sync was a no-op in the
     normal case — and a bug for any symbol layer with its own default, which it
     switched on at load. Summits (A76) default OFF and were being turned on by
     this line, one take after the layers panel gave them an off switch.
     Removed rather than special-cased: the Labels control still governs every
     symbol layer through labelLayers(), which is where that belongs (take 94). */
  setChip('c-base',sat?'sat':'map',m);
  el('c-base').className='basebtn'+(sat?' on':'');
}

/* LABELS block moved above the map constructor at take 15 — see the note where
   it now lives. */

/* ══ TERRAIN ════════════════════════════════════════════════════════════════
   One DEM ingest gives four things: node elevations, per-edge climb, elevation
   profiles, and the hillshade underneath. 3DEP via public Terrarium tiles at
   z13 (~13.6 m/px). Relief across the AOI is 199 m — Bull Gap is a sand hill,
   and routing that ignores that ignores what riders actually feel. */
var NE=TR.ne, UP=TR.up, DN=TR.dn;
function edgeProfile(i){var d=TR.pf[i],out=[],v=0;
  for(var k=0;k<d.length;k++){v+=d[k];out.push(v)}return out}
function ft(m){return Math.round(m*3.28084)}

/* Climbing costs more than distance on loose sand. 1 m up is charged like 12 m
   along; the Least-climbing profile charges it like 45 m. */
var CLIMB_K=12;
function elevAt(ll){
  var best=1e9,e=null;
  for(var i=0;i<NODES.length;i+=7){var dx=NODES[i][0]-ll[0],dy=NODES[i][1]-ll[1];
    var d=dx*dx*0.51+dy*dy;if(d<best){best=d;e=NE[i]}}
  return e}


/* 4.6 — nearest pavement. Not a route: a straight-line bearing to the closest
   thing a truck can reach you on. Answers "which way do I walk" when the bike
   will not move, and needs no router. */
function nearestPavement(ll){
  var best=1e9,bp=null,be=null;
  for(var i=0;i<EDGES.length;i++){var e=EDGES[i];
    if(e.c!=='paved'&&e.c!=='minor')continue;
    var g=decode(GR.g[i]);
    for(var k=0;k<g.length;k++){var d=mi(ll,g[k]);
      if(d<best){best=d;bp=g[k];be=e}}}
  return {p:bp,d:best,e:be}}

/* 4.12 — what this app is not. A promise about its own limits, in the app,
   offline, where you would read it. */
var ABOUT='<span class="tn">APEX ORV</span>'+
 '<span class="tag legal">offline</span><span class="tag adv">no account</span><br>'+
 'Michigan DNR + USDA Forest Service designations, OpenStreetMap for context. '+
 'Every line says which.<br><br>'+
 '<b>This is not an emergency device.</b> It cannot call anyone. In country '+
 'like this a satellite messenger does something no map can — carry one.<br>'+
 'The MVUM and DNR signage are the legal authority. This app is not a defence.<br>'+
 'Private property lines are not shown; that data is licensed and not public.';

/* ══ PHASE 4 — the reason this exists ═══════════════════════════════════════
   Everything below is load-bearing (PROTOCOL §9): no network, no map download,
   no subscription check. Retrace in particular needs nothing but the track you
   already recorded — not the router, not the graph, not agency data. */

var JX = GR.jx || {};
var TRUCK=null, tM=null, crumbs=[], crumbMi=0, riding=null, lost=false, offAlert=false;

function mi(a,b){var dx=(b[0]-a[0])*0.714*69,dy=(b[1]-a[1])*69;return Math.hypot(dx,dy)}
function bearing(a,b){var t=Math.PI/180,
  y=Math.sin((b[0]-a[0])*t)*Math.cos(b[1]*t),
  x=Math.cos(a[1]*t)*Math.sin(b[1]*t)-Math.sin(a[1]*t)*Math.cos(b[1]*t)*Math.cos((b[0]-a[0])*t);
  return (Math.atan2(y,x)*180/Math.PI+360)%360}
function compass(d){return ['N','NNE','NE','ENE','E','ESE','SE','SSE','S','SSW','SW','WSW',
  'W','WNW','NW','NNW'][Math.round(d/22.5)%16]}
function buzz(p){
  /* Android WebView does not implement navigator.vibrate — silently. The
     off-route alert's haptic (4.4) would have been dead in the APK. Bridge to
     Capacitor Haptics when present; browsers keep navigator.vibrate. */
  var C=window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.Haptics;
  if(C){var d=Array.isArray(p)?p.reduce(function(a,b){return a+b},0):p;
    try{C.vibrate({duration:d})}catch(e){}return}
  try{navigator.vibrate&&navigator.vibrate(p)}catch(e){}}

/* 4.1 — recording starts with the ride, no button to forget.
   4.2 — the truck drops itself where you started. */
/* ══ RIDE TELEMETRY ═════════════════════════════════════════════════════════
   A18 Stage 1 is the standing blocker and only a real ride can close it: battery
   cost with the screen held on, and GPS quality under jack pine. Neither can be
   measured from a container, and "it felt fine" is not a measurement.

   So the ride measures itself. Everything here is local — battery level from the
   Capacitor Device plugin, fix timing from the watch we already run. Nothing is
   sent anywhere; it ends up in the same report Jacob already shares. */
var RIDE=null;

function batteryNow(){
  var C=window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.Device;
  if(C&&C.getBatteryInfo)return C.getBatteryInfo().then(function(b){
    return {lvl:b.batteryLevel,chg:!!b.isCharging}}).catch(function(){return null});
  if(navigator.getBattery)return navigator.getBattery().then(function(b){
    return {lvl:b.level,chg:!!b.charging}}).catch(function(){return null});
  return Promise.resolve(null)}

function rideStart(at){
  RIDE={t0:Date.now(),fixes:0,gaps:[],acc:[],drops:0,maxGap:0,
        batt0:null,batt1:null,chg:false,last:Date.now(),mi0:0};
  batteryNow().then(function(b){if(RIDE&&b){RIDE.batt0=b.lvl;RIDE.chg=b.chg}});
  RIDE.ticks=0;
  RIDE.pulse=setInterval(function(){
    if(!RIDE)return;
    /* battery moves slowly and the read is not free; the dropout watch is the
       thing that needs to be prompt */
    if(++RIDE.ticks%3===1)batteryNow().then(function(b){
      if(RIDE&&b){RIDE.batt1=b.lvl;RIDE.chg=RIDE.chg||b.chg}});
    /* a fix that has not arrived in 15s is a dropout, not slowness */
    var since=(Date.now()-RIDE.last)/1000;
    if(since>15){RIDE.drops++;RIDE.last=Date.now();
      if(since>RIDE.maxGap)RIDE.maxGap=since;
      logAct('gps  DROPOUT '+Math.round(since)+'s')}},20000)}

function rideFix(acc){
  if(!RIDE)return;
  var now=Date.now(),gap=(now-RIDE.last)/1000;
  RIDE.last=now;RIDE.fixes++;
  if(RIDE.fixes>1){RIDE.gaps.push(gap);if(gap>RIDE.maxGap)RIDE.maxGap=gap}
  if(acc!==null&&acc!==undefined)RIDE.acc.push(acc)}

/* ══ RIDE HUD ═══════════════════════════════════════════════════════════════
   A80/A81/A82. Heading, speed and trip, on screen while riding.

   ONE entry point for both drivers. GPS supplies coords.speed and
   coords.heading when it has them; the simulator supplies its own; and when
   neither does — Android reports heading null while stopped — both fall back to
   differencing the crumb trail, which is the same data the track is drawn from.
   The simulator therefore exercises every line the GPS path does, which is what
   makes it a usable test double (take 16).

   bearing() and compass() are reused rather than reimplemented: take 69 verified
   the four cardinal cases independently, outside the code that produced them,
   after a reversed bearing sent a reader the wrong way. */
var HUD={spd:null,hdg:null,at:null,t:null};

function hudSet(mps,deg,at){
  /* The compass reads the same heading the ride ribbon does, so it updates on
     every fix without a second source of truth (take 105). */
  try{if(CMP_ON)setTimeout(cmpPaint,0)}catch(e){}
  var now=Date.now();
  /* derive from the trail when the fix withholds either — heading is null on
     Android whenever you are stopped, and the simulator has no coords at all */
  if(at&&HUD.at&&HUD.t){
    var d=mi(HUD.at,at),secs=(now-HUD.t)/1000;
    if(deg===null||deg===undefined){if(d>0.0015)deg=bearing(HUD.at,at)}
    if((mps===null||mps===undefined)&&secs>0.4&&secs<30)mps=d*1609.34/secs;
  }
  if(mps!==null&&mps!==undefined&&isFinite(mps)&&mps>=0)HUD.spd=mps;
  if(deg!==null&&deg!==undefined&&isFinite(deg))HUD.hdg=(deg%360+360)%360;
  if(at){HUD.at=at.slice();HUD.t=now}
  hudPaint()}

function hudShow(on){
  var b=el('hudbar'),s=el('hudstats'),c=el('chips');
  if(b)b.hidden=!on;
  if(s)s.hidden=!on;
  /* the place chips jump the camera to a town; during a ride the map recentres
     on the rider every sixth fix, so they undo themselves. The ribbon is worth
     more in that slot than they are. */
  if(c)c.hidden=!!on;
  if(!on){HUD={spd:null,hdg:null,at:null,t:null}}
  hudPaint()}

function hudPaint(){
  var b=el('hudbar');
  if(!b||b.hidden)return;
  /* A ribbon with no heading is a bare orange needle over an empty bar — it
     looks broken because it IS telling you nothing. Say so instead (take 84). */
  var hint=el('hudhint');
  if(hint)hint.hidden=(HUD.hdg!==null);
  var w=b.clientWidth||360,SPAN=180,ppd=w/SPAN,h=HUD.hdg;
  var t=el('hudticks');
  if(t){
    if(h===null){t.innerHTML='';}
    else{
      var out=[],CARD=['N','NE','E','SE','S','SW','W','NW'];
      for(var d=0;d<360;d+=15){
        var off=((d-h+540)%360)-180;
        if(Math.abs(off)>SPAN/2)continue;
        var x=w/2+off*ppd,maj=(d%45===0);
        out.push('<i class="'+(maj?'maj':'')+'" style="left:'+x.toFixed(1)+
          'px;height:'+(maj?11:6)+'px"></i>');
        if(maj)out.push('<b style="left:'+x.toFixed(1)+'px">'+CARD[(d/45)|0]+'</b>');
      }
      t.innerHTML=out.join('');
    }
  }
  var sp=el('hud-spd');
  if(sp)sp.innerHTML=(HUD.spd===null?'—':Math.round(HUD.spd*2.23694))+
    '<span class="hu">mph</span>';
  var tm=el('hud-time');
  if(tm)tm.textContent=RIDE?Math.round((Date.now()-RIDE.t0)/60000)+' min':'—';
  var ds=el('hud-dist');
  if(ds)ds.textContent=crumbMi.toFixed(1)+' mi';}

function rideStop(){
  if(!RIDE)return null;
  clearInterval(RIDE.pulse);
  var R=RIDE,hrs=(Date.now()-R.t0)/3600000;
  var med=function(a){if(!a.length)return null;var b=a.slice().sort(function(x,y){return x-y});
    return b[(b.length/2)|0]};
  R.hrs=hrs;R.medGap=med(R.gaps);R.medAcc=med(R.acc);
  R.drain=(R.batt0!==null&&R.batt1!==null)?(R.batt0-R.batt1):null;
  /* Android reports battery in 1% steps, so a ten-minute ride can show 0% or 1%
     and extrapolate to anything between "forever" and "two hours". Require a
     real sample before quoting a rate: 20 minutes AND at least 2% moved. */
  R.longEnough=(hrs>=0.33&&R.drain!==null&&Math.abs(R.drain)>=0.02);
  R.perHr=R.longEnough?R.drain/hrs:null;
  RIDE=null;LASTRIDE=R;return R}
var LASTRIDE=null;

function rideReport(R){
  var L=[];
  L.push('APEX RIDE · '+(el('title').textContent||'').replace(/\s+/g,' ').trim());
  L.push(new Date().toISOString());
  L.push('');
  L.push('  duration      '+(R.hrs*60).toFixed(0)+' min');
  L.push('  track         '+crumbMi.toFixed(2)+' mi, '+crumbs.length+' points');
  L.push('  fixes         '+R.fixes+(R.medGap!==null?' · median gap '+R.medGap.toFixed(1)+'s':''));
  L.push('  worst gap     '+(R.maxGap?R.maxGap.toFixed(0)+'s':'—')+
    (R.drops?' · '+R.drops+' dropouts over 15s':' · no dropouts'));
  L.push('  accuracy      '+(R.medAcc!==null?'median ±'+Math.round(R.medAcc)+' m':'not reported'));
  L.push('  battery       '+(R.drain!==null?
    (R.drain*100).toFixed(1)+'% used'+(R.perHr!==null?' · '+(R.perHr*100).toFixed(1)+'%/hour':'')+
      (R.chg?' (WAS CHARGING — drain figure is meaningless)':''):
    'not available on this device'));
  if(R.drain!==null&&!R.longEnough&&!R.chg)
    L.push('  battery note  too short to quote a rate — needs 20+ min and 2%+ moved');
  if(R.perHr!==null&&!R.chg&&R.perHr>0)
    L.push('  screen-on est '+(1/R.perHr).toFixed(1)+' hours from full at this rate');
  L.push('');
  L.push('--- end ---');
  return L.join('\n')}

function startRecording(at){
  TRUCK=at.slice(); crumbs=[at.slice()]; crumbMi=0;
  rideStart(at);
  hudShow(true);
  if(!tM)tM=new maplibregl.Marker({element:mk('truck','⛟')}).setLngLat(TRUCK).addTo(map);
  else tM.setLngLat(TRUCK);
  map.getSource('back').setData({type:'FeatureCollection',features:[]});
  syncSafety()}

function record(at){
  if(!crumbs.length)return;
  var prev=crumbs[crumbs.length-1], d=mi(prev,at);
  if(d<0.004)return;                    /* ~7 m — don't log GPS jitter as travel */
  crumbs.push(at.slice()); crumbMi+=d;
  map.getSource('crumb').setData({type:'FeatureCollection',features:[
    {type:'Feature',properties:{},geometry:{type:'LineString',coordinates:crumbs}}]});
  syncSafety()}

/* 4.3 — back to the vehicle. Never more than a glance away, always on the rail. */
function syncSafety(){
  var tv=el('v-truck'), rv=el('v-rec');
  if(!TRUCK){tv.textContent='—';tv.className='v';rv.textContent='—';
    /* a cell with nothing to say takes no space (take 113); parentNode is
       guarded because stub elements have none, and a hidden cell is polish —
       polish must never be why the loader fatals (same rule as the badges) */
    if(tv.parentNode)tv.parentNode.className='cell empty';
    if(rv.parentNode)rv.parentNode.className='cell empty';
    return}
  if(tv.parentNode)tv.parentNode.className='cell';
  if(rv.parentNode)rv.parentNode.className='cell';
  var d=mi(ME,TRUCK), b=bearing(ME,TRUCK);
  tv.textContent=(d<10?d.toFixed(1):Math.round(d))+' '+compass(b);
  tv.className='v'+(d>8?' warn':' good');
  rv.textContent=crumbMi.toFixed(1);
  /* 4.11 — a safety feature that can fail silently needs to show it is alive */
  el('b-src').textContent=crumbs.length?'REC '+crumbs.length:'GRAPH '+EDGES.length;
  el('b-src').className='badge '+(crumbs.length?'good':'good')}

/* 4.4 — off-route alert. Haptic first, because you are looking at the trail. */
function checkOffRoute(){
  if(!last||sel===null||!crumbs.length)return;
  var pts=[];last[sel].s.path.forEach(function(e){pts=pts.concat(decode(GR.g[e.i]))});
  var best=1e9;for(var i=0;i<pts.length;i++){var d=mi(ME,pts[i]);if(d<best)best=d}
  var off=best>0.16;                    /* ~260 m from the planned line */
  if(off&&!offAlert){offAlert=true;buzz([120,80,120,80,220]);
    el('alert').className='on';
    el('alert').innerHTML='Off route — '+(best*5280|0)+' ft from your line'+
      '<small>Tap Retrace to follow your own track back to the truck.</small>'}
  else if(!off&&offAlert){offAlert=false;el('alert').className=''}}

/* 4.14 — Retrace. The one that must never fail: no router, no network, no agency
   data. Just the line you already rode, reversed. */
el('btn-retrace').addEventListener('click',function(){
  if(crumbs.length<2)return show('Nothing recorded yet. Tap <b>▶ Ride it</b> to lay a track, or this fills in from GPS on a real ride.','fail');
  var back=crumbs.slice().reverse(), d=0;
  for(var i=1;i<back.length;i++)d+=mi(back[i-1],back[i]);
  map.getSource('back').setData({type:'FeatureCollection',features:[
    {type:'Feature',properties:{},geometry:{type:'LineString',coordinates:back}}]});
  var b=new maplibregl.LngLatBounds();back.forEach(function(c){b.extend(c)});
  map.fitBounds(b,{padding:50,duration:700});
  el('alert').className='';offAlert=false;
  show('<span class="tn">Retrace</span><br><span class="tag legal">no router · no network</span><br>'+
   '<b>'+d.toFixed(2)+' mi</b> back along the track you actually rode · '+
   compass(bearing(ME,TRUCK))+' to the truck · '+back.length+' points<br>'+
   'Every foot of this is ground you have already covered.','')});

/* 4.7 — the dispatch card. Decimal degrees is what Oscoda and Ogemaw ask for.
   Junctions are named by what meets there, never by a number we invented. */
function nearestEdge(ll){
  var best=1e9,be=null;
  for(var i=0;i<EDGES.length;i++){var g=decode(GR.g[i]);
    for(var k=0;k<g.length;k++){var d=mi(ll,g[k]);if(d<best){best=d;be=EDGES[i]}}}
  return {e:be,d:best}}
function nearestJunction(ll){
  var best=1e9,bn=null;
  for(var k in JX){var n=+k,p=[NODES[n][0],NODES[n][1]],d=mi(ll,p);
    if(d<best){best=d;bn=n}}
  return {n:bn,d:best}}

el('btn-disp').addEventListener('click',function(){
  if(posMode!=='gps')return show('<b>No live position.</b><br>'+
    (posMode==='sim'?'The simulator is driving — those coordinates are invented. ':
     posMode==='away'?'You are about '+Math.round(awayMi)+' mi from this region. ':
     'No GPS fix yet. ')+
    'This card exists to read your <i>actual</i> location to dispatch, so it '+
    'will not print a coordinate you are not standing at. The map centre is '+
    'shown in the readout above if you want a planning reference.','fail');
  show('Locating you on the network…','');
  setTimeout(function(){
    var ne=nearestEdge(ME), nj=nearestJunction(ME);
    var out='<span class="tn">'+ME[1].toFixed(5)+'  '+ME[0].toFixed(5)+'</span>'+
      '<span class="tag legal">decimal degrees</span><br>';
    var bits=[];
    /* The address goes FIRST after the coordinate. A street name and number is
       what a dispatcher types into their own system; the trail name and junction
       are what the responder needs once they are close. Exact if we have one,
       otherwise the bearing-and-distance form from take 69 — and labelled
       "Nearest address" so it is never mistaken for where you are standing. */
    var ad=addressAt(ME)||addressAt(ME,true);
    if(ad)bits.push((ad.near?'Nearest address ':'Address ')+'<b>'+ad.txt+'</b>');
    var cty=countyAt(ME);
    if(cty)bits.push('County <b>'+cty+' County, MI</b>');
    if(ne.e){var a=attrs(ne.e);
      bits.push('On or near '+(ne.e.n?'<b>'+ne.e.n+'</b>'
                               :'an unnamed <b>'+label(ne.e.c)+'</b>')+
        (ne.e.id?' (<b>'+ne.e.id+'</b>)':'')+
        ' — '+(ne.d*5280|0)+' ft'+(a.src?', '+a.src.toUpperCase():''))}
    if(nj.n!==null){var nm=JX[nj.n].map(function(i){return NM[i]}).join(' × ');
      bits.push('Nearest junction <b>'+nm+'</b> — '+
        (nj.d<0.19?(nj.d*5280|0)+' ft':nj.d.toFixed(2)+' mi')+' '+
        compass(bearing(ME,[NODES[nj.n][0],NODES[nj.n][1]])))}
    if(TRUCK)bits.push('Truck <b>'+mi(ME,TRUCK).toFixed(2)+' mi '+
      compass(bearing(ME,TRUCK))+'</b>');
    var ev=elevAt(ME);if(ev!==null)bits.push('Elevation <b>'+ft(ev)+' ft</b>');
    var np=nearestPavement(ME);
    if(np.p)bits.push('Nearest pavement <b>'+np.d.toFixed(2)+' mi '+
      compass(bearing(ME,np.p))+'</b>'+(np.e&&np.e.n?' — '+np.e.n:''));
    bits.push(ad?'Read the coordinates first, then the address, then the junction.'
                :'Read the coordinates first, then the junction.');
    show(out+bits.join('<br>'),'')},20)});

/* ── ride simulator ────────────────────────────────────────────────────────
   Not a product feature. A harness, so Phase 4 can be exercised without a bike
   and a tank of gas — the same reason tools/verify6.py exists. */
function edgesAt(node){return ADJ[node]||[]}
function simPath(){
  if(last&&sel!==null)return last[sel].s.path.slice();
  var a=nearestNode(ME);if(a<0)return null;
  var path=[],cur=a,prev=-1;
  for(var i=0;i<40;i++){var opts=edgesAt(cur).filter(function(e){
      return e.i!==prev&&e.c!=='closed'&&e.c!=='fsclosed'});
    if(!opts.length)break;var e=opts[(Math.random()*opts.length)|0];
    path.push(e);prev=e.i;cur=(e.a===cur?e.b:e.a)}
  return path.length?path:null}

function stopRide(){if(riding){clearInterval(riding);riding=null;
  hudShow(false);
  setChip('c-ride','play','Ride it')}}

/* ── real GPS ────────────────────────────────────────────────────────────
   One recording path, two drivers. On the phone, watchPosition feeds the same
   startRecording/record/checkOffRoute chain the simulator exercised in smoke —
   the sim is the test double, GPS is production, and they share every line
   after the fix arrives. file:// and the harness fall back to the simulator. */
var rideMode=null,gotFix=false,fixN=0;
/* posMode: 'none'  — no fix yet; ME is a planning cursor, NOT a position
            'gps'   — live fix inside this region
            'sim'   — the simulator is driving; real machinery, fabricated position
   'away'  — live fix, but hundreds of miles from this region
   The map has to know the difference. Take 20 showed Jacob 44.57072 -84.15770
   while he was in another state: a plausible, precise, wrong coordinate, on the
   same screen as the button that reads coordinates out to dispatch. */
var posMode='none',awayMi=0;
function inRegion(at){var b=BUNDLE.bbox;if(!b)return true;
  return at[0]>=b[0]-0.02&&at[0]<=b[2]+0.02&&at[1]>=b[1]-0.02&&at[1]<=b[3]+0.02}
function classifyFix(at){
  logAct('gps  fix '+at[1].toFixed(5)+','+at[0].toFixed(5));
  if(inRegion(at)){posMode='gps';awayMi=0;return}
  posMode='away';awayMi=mi(at,CTR);
  show('<b>You are about '+Math.round(awayMi)+' mi from '+
    (BUNDLE.name||'this region')+'.</b><br>Planning mode — everything except live '+
    'tracking works. <b>Tap open ground</b> to drop your planning start, or use '+
    '<b>⌂ Set home</b> to place the truck, then <b>Return Home</b> and '+
    '<b>Directions</b> route between them. Search and elevation work too.'+
    '<br><br>Live tracking and the dispatch card stay off until you are in the '+
    'region — they must never report a position you are not standing at.','')}
function gpsStart(onFix,onFail){
  var C=window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.Geolocation;
  if(C){
    /* Capacitor 7 hands back the watch id SYNCHRONOUSLY here, not a Promise.
       Calling .then() on it threw, gpsStart() threw with it, and the whole
       ▶ Ride it handler died on the device while the watch quietly ran in the
       background. The self-test caught it on its first real run. Accept both
       shapes — a plugin's return type is not something to assume (landmine 56). */
    var w;
    try{ w=C.watchPosition({enableHighAccuracy:true,timeout:12000},function(pos,err){
      if(err||!pos)return onFail&&onFail(err);
      onFix([pos.coords.longitude,pos.coords.latitude],pos.coords.accuracy,
            pos.coords.speed,pos.coords.heading);
    }) }catch(e){ onFail&&onFail(e); return null }
    if(w&&typeof w.then==='function')w.then(function(id){watchId=id})
      .catch(function(e){onFail&&onFail(e)});
    else watchId=w;
    return 'cap'}
  if(navigator.geolocation){
    watchId=navigator.geolocation.watchPosition(function(pos){
      onFix([pos.coords.longitude,pos.coords.latitude],pos.coords.accuracy,
            pos.coords.speed,pos.coords.heading)},
      function(e){onFail&&onFail(e)},
      {enableHighAccuracy:true,maximumAge:1000,timeout:12000});
    return 'web'}
  return null}
var watchId=null;
function gpsStop(){
  var C=window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.Geolocation;
  if(watchId===null)return;
  try{if(rideMode==='cap'&&C)C.clearWatch({id:watchId});
      else if(navigator.geolocation)navigator.geolocation.clearWatch(watchId)}catch(e){}
  watchId=null}
function stopReal(){gpsStop();rideMode=null;posMode=gotFix?'gps':'none';gotFix=false;
  hudShow(false);
  setChip('c-ride','play','Ride it');
  var R=rideStop();
  if(!R)return show('Recording stopped. <b>'+crumbMi.toFixed(2)+
    ' mi</b> on the track. <b>Retrace</b> follows it back.','');
  logAct('ride end '+(R.hrs*60).toFixed(0)+'min '+R.fixes+' fixes');
  var txt=rideReport(R);
  show('<b>Ride recorded — '+crumbMi.toFixed(2)+' mi</b><br>'+
    '<span class="unit">'+(R.hrs*60).toFixed(0)+' min · '+R.fixes+' fixes'+
    (R.medAcc!==null?' · median ±'+Math.round(R.medAcc)+' m':'')+
    (R.drops?' · <b>'+R.drops+' GPS dropouts</b>':' · no dropouts')+
    (R.drain!==null?' · '+(R.drain*100).toFixed(1)+'% battery':'')+'</span><br>'+
    '<b>Retrace</b> follows the track back.'+
    '<div style="margin-top:8px"><button class="chip" id="rr-copy">Copy ride report</button> '+
    '<button class="chip" id="rr-share">Share</button></div>','');
  var cp=el('rr-copy');
  if(cp)cp.addEventListener('click',function(){
    var done=function(){cp.textContent='Copied ✓'};
    if(navigator.clipboard&&navigator.clipboard.writeText)
      navigator.clipboard.writeText(txt).then(done,function(){}); else{
      var ta=document.createElement('textarea');ta.value=txt;document.body.appendChild(ta);
      ta.select();try{document.execCommand('copy');done()}catch(e){}document.body.removeChild(ta)}});
  var sh=el('rr-share');
  if(sh)sh.addEventListener('click',function(){
    var S=window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.Share;
    if(S)S.share({title:'APEX ride',text:txt}).catch(function(){});
    else if(navigator.share)navigator.share({title:'APEX ride',text:txt}).catch(function(){})})}
function onFix(at,acc,mps,deg){
  classifyFix(at);
  rideFix(acc);
  /* speed and heading arrived on every fix since take 21 and were discarded on
     both drivers. A82: the data was already flowing (take 78). */
  if(posMode==='gps')hudSet(mps,deg,at);
  if(posMode==='away'){                     /* honest, and still useful */
    gpsStop();rideMode=null;
    setChip('c-ride','play','Ride it');
    paint();return}
  if(!gotFix){gotFix=true;startRecording(at);ME=at.slice();mM.setLngLat(ME);
    map.easeTo({center:ME,zoom:14.5,duration:600});
    show('<span class="tn">Recording</span><span class="tag legal">live GPS</span><br>Truck pinned where you are. Ride.','');return}
  ME=at.slice();mM.setLngLat(ME);record(ME);checkOffRoute();
  if(++fixN%6===0)map.easeTo({center:ME,duration:280})}

el('c-ride').addEventListener('click',function(){
  if(rideMode)return stopReal();
  if(riding)return stopRide();
  rideMode=gpsStart(onFix,function(){
    if(gotFix)return;                 /* transient mid-ride errors: keep riding */
    stopReal();
    show('GPS unavailable here — browsers block it on <b>file://</b>. Running the <b>simulator</b> instead; in the APK this is your real track.','');
    startSim()});
  if(rideMode){setChip('c-ride','stop','Stop (GPS)',1);return}
  startSim()});

function startSim(){
  /* The simulator must exercise every line the GPS path does — that is what
     makes it a usable test double (take 16). It does NOT get to be a position:
     dispatch still refuses, because these coordinates are invented. */
  posMode='sim';
  var path=simPath();
  if(!path)return show('Pick a <b>Return home</b> route first, or move the ◎ pin nearer a trail.','fail');
  var pts=[];path.forEach(function(e){pts=pts.concat(decode(GR.g[e.i]))});
  /* orient the ride away from wherever we start */
  if(pts.length&&mi(ME,pts[0])>mi(ME,pts[pts.length-1]))pts.reverse();
  startRecording(pts[0]);ME=pts[0].slice();mM.setLngLat(ME);
  lost=false;var i=0;
  setChip('c-ride','stop','Stop',1);
  map.easeTo({center:ME,zoom:14.2,duration:600});
  riding=setInterval(function(){
    if(lost){
      var nn=nearestNode(ME),opts=edgesAt(nn);
      if(opts.length){var e=opts[(Math.random()*opts.length)|0],g=decode(GR.g[e.i]);
        pts=g;i=0;lost=false}
    }
    if(i>=pts.length){stopRide();
      show('Ride finished. <b>'+crumbMi.toFixed(2)+' mi</b> recorded. Tap <b>Retrace</b>, or <b>Dispatch</b> for what to read out.','pass');return}
    ME=pts[i++].slice();mM.setLngLat(ME);record(ME);checkOffRoute();
    hudSet(null,null,ME);
    if(i%6===0)map.easeTo({center:ME,duration:280})},170)}

/* ══ LAYERS PANEL (A91) ═════════════════════════════════════════════════════
   Every row reads the map's ACTUAL state when the panel opens, and writes to
   the map when tapped. It never keeps its own copy of what is on — a copy of a
   set is what let six label layers escape the Labels chip (landmine 107).
   Overlay rows are declared by the layer ids they govern, so adding a layer to
   a group is one entry here rather than a new toggle scattered in the strip. */
var LYRGROUPS=[
  {k:'places', h:'Places',      s:'campgrounds, fuel, launches, trailheads',
   ids:['poi-dot','poi-label']},
  {k:'water',  h:'Lakes & rivers', s:'water and its names',
   ids:['water','wway','lbl-lake','lbl-stream']},
  {k:'contour',h:'Contours',    s:'40 ft, labelled every 200 ft',
   ids:['cont-line','cont-index','cont-label']},
  {k:'peaks',  h:'Named hills', s:'summits with their height',
   ids:['peak-dot','peak-label']},
  {k:'paddle', h:'Rivers & paddling', s:'runs, launches, campgrounds and dams',
   ids:['pad-case','pad-line','pad-dot','pad-lbl','pad-dam','pad-damlbl']},
  {k:'relief', h:'Relief',      s:'hillshade', ids:['hillshade']},
  {k:'labels', h:'All labels',  s:'every name on the map', ids:null}
];

function lyrOn(g){
  var ids=g.ids||labelLayers();
  for(var i=0;i<ids.length;i++){
    try{if(map.getLayer(ids[i])&&
        map.getLayoutProperty(ids[i],'visibility')!=='none')return true}catch(e){}}
  return false}

function lyrSet(g,on){
  var ids=g.ids||labelLayers();
  ids.forEach(function(id){
    try{if(map.getLayer(id))map.setLayoutProperty(id,'visibility',on?'visible':'none')}catch(e){}});
  /* Relief carries an opacity that depends on the basemap; setBasemap and the
     old chip both knew this and disagreed once (see setBasemap). One place now. */
  if(on&&g.k==='relief'){
    try{map.setPaintProperty('hillshade','raster-opacity',
      BASEMAPS[bmi]==='Map'?0.42:0.16)}catch(e){}}
  var c=el('c-relief');
  if(c&&g.k==='relief')c.className='chip'+(on?' on':'');
  var l=el('c-labels');
  if(l&&g.k==='labels')l.className='chip'+(on?' on':'')}

function buildLyrPanel(){
  var p=el('lyrpanel'),h='<div class="sect">Basemap</div>';
  BASEMAPS.forEach(function(nm,i){
    var sel=(i===bmi),dis=(i>0&&!SAT_OK);
    h+='<button class="actrow'+(sel?' on':'')+'" data-bm="'+i+'"'+
       (dis?' disabled':'')+'>'+
       '<span class="sw" style="background-color:'+(i===0?'#E4D7BC':'#4E6A4A')+'"></span>'+
       '<span>'+nm+(dis?' — not in this bundle':'')+'</span></button>'});
  h+='<div class="sect">Layers</div>';
  LYRGROUPS.forEach(function(g,i){
    var on=lyrOn(g);
    h+='<button class="actrow'+(on?' on':'')+'" data-lg="'+i+'">'+
       '<span class="sw" style="background-color:'+(on?'#E2570F':'transparent')+
       ';border:1px solid rgba(255,255,255,.5)"></span>'+
       '<span>'+g.h+'</span></button>'});
  p.innerHTML=h;
  Array.prototype.forEach.call(p.querySelectorAll('[data-bm]'),function(b){
    b.addEventListener('click',function(){
      if(b.disabled)return;
      setBasemap(+b.dataset.bm);logAct('act  basemap '+BASEMAPS[bmi]);
      buildLyrPanel()})});
  Array.prototype.forEach.call(p.querySelectorAll('[data-lg]'),function(b){
    b.addEventListener('click',function(){
      var g=LYRGROUPS[+b.dataset.lg],on=!lyrOn(g);
      lyrSet(g,on);logAct('act  layer '+g.k+' '+(on?'on':'off'));
      buildLyrPanel()})})}

/* c-base stays a ONE-TAP CYCLE. Replacing it with a menu cost a rider two taps
   and a hunt to reach satellite, in gloves, and the render harness said so
   immediately — its basemap checks encode behaviour worth keeping (take 90).
   The panel is a separate chip. */
el('c-base').addEventListener('click',function(){setBasemap(bmi+1)});
/* ══ DESTINATIONS (A113) ════════════════════════════════════════════════════
   Which chips are on screen, and nothing else. Every handler, id and DOM
   position is untouched — a chip in a closed destination is `hidden`, which the
   layout self-test already skips (it measures elements with height) and which
   click() ignores, so the harness needs no changes either.

   Deliberately NOT a router: there are no separate screens to get lost between,
   and the map stays visible in every destination because on a trail the map is
   the thing you are looking at. */
var TAB='map';
function showTab(t){
  TAB=t;
  Array.prototype.forEach.call(document.querySelectorAll('.chip[data-tab]'),function(c){
    c.hidden=(c.dataset.tab!==t)});
  Array.prototype.forEach.call(document.querySelectorAll('#tabs .tab'),function(b){
    /* className, not innerHTML — the tab's icon lives in its children and a
       label rewrite would take it with them (the same trap setChip exists for). */
    b.className='tab'+(b.dataset.go===t?' on':'')});
  /* the panels belong to specific destinations; leaving one open across a
     switch is how a UI starts feeling arbitrary */
  var dp=el('diagpanel'); if(dp&&t!=='tools')dp.hidden=true;
  var cp=el('cmppanel'); if(cp&&t!=='tools'){cp.hidden=true;CMP_ON=false}
  var lp=el('lyrpanel'); if(lp&&t!=='map')lp.hidden=true;
  var ap=el('actpanel'); if(ap&&t!=='map')ap.hidden=true;
  logAct('tap  tab '+t)}

Array.prototype.forEach.call(document.querySelectorAll('#tabs .tab'),function(b){
  b.addEventListener('click',function(){showTab(b.dataset.go)})});

el('c-howto').addEventListener('click',function(){guideShow()});
el('guide-go').addEventListener('click',function(){guideClose(true)});
/* Tapping the blurred background closes it too — the same gesture as tapping
   empty map to put the drawer away. */
el('guide').addEventListener('click',function(e){
  if(e.target===el('guide'))guideClose(true)});

el('c-compass').addEventListener('click',function(){
  var p=el('cmppanel');CMP_ON=p.hidden;p.hidden=!p.hidden;
  if(CMP_ON){magStart();el('diagpanel').hidden=true;cmpPaint()}
  logAct('tap  c-compass')});

/* One tap where you are, rather than long-pressing a map you may not be able to
   see. Same store and same auto-naming as a dropped waypoint (take 92). */
el('c-markme').addEventListener('click',function(){
  if(!ME)return show('<b>No position yet.</b> Wait for a fix, or long-press the '+
    'map to mark a spot by hand.','fail');
  var nm=wpName(ME);
  if(!wpAdd({n:nm,p:ME.slice(),r:BUNDLE.region||null,ts:Date.now()}))
    return show('<b>Could not save.</b> This browser will not let the page store '+
      'anything; in the app it works normally.','fail');
  logAct('act  marked this spot '+nm);
  wpDraw();
  show('Marked <b>'+nm+'</b>.<br><span class="sub">On this phone only. '+
    'Find it again under \u2606 Saved.</span>','pass')});

el('peek').addEventListener('click',function(){
  var folded=el('rail').className==='folded';
  RAIL_MANUAL=!folded;              /* folded by hand stays folded */
  railSet(folded);
  logAct('tap  rail '+(folded?'open':'fold'))});

el('c-diag').addEventListener('click',function(){
  var p=el('diagpanel');p.hidden=!p.hidden;logAct('tap  c-diag')});

el('c-layers').addEventListener('click',function(){
  var p=el('lyrpanel');buildLyrPanel();p.hidden=!p.hidden;
  if(!p.hidden)el('actpanel').hidden=true;
  logAct('tap  c-layers')});
el('c-act').addEventListener('click',function(){
  var p=el('actpanel');buildActPanel();p.hidden=!p.hidden});
el('c-about').addEventListener('click',function(){show(ABOUT,'')});
/* Every label layer, DERIVED from the style rather than listed here.
   This was a hand-kept array of five and the comment above it claimed it was
   all of them. By take 89 the style had eleven: lake-label, lbl-trail-short,
   poi-label, lbl-ref, lbl-lake and lbl-stream all escaped the Labels chip, four
   of them added by me in takes 87-89 without a thought for the list that was
   supposed to govern them.
   A copy of a set drifts from the set (landmine 107, and this is the third
   place it has happened). Ask the map what symbol layers it has. */
function labelLayers(){
  try{
    return map.getStyle().layers.filter(function(l){return l.type==='symbol'})
              .map(function(l){return l.id})
  }catch(e){return []}}
var glErr=null;
map.on('error',function(e){var m=(e&&e.error&&e.error.message)||String(e&&e.error||'');
  if(m&&!glErr){glErr=m;try{window.__mapErr=m}catch(_){}renderHealth()}});
function renderedCount(){try{return map.queryRenderedFeatures().length}catch(e){return -1}}
var healthTries=0,healthOK=false;
function renderHealth(){
  /* Sources hold 16k+ features and the style is valid, yet nothing paints:
     that is the renderer, not the data (landmine 47).

     A single zero reading proves nothing — queryRenderedFeatures() is legitimately
     empty while tiles are still being built, so an eager check would cry RENDER
     FAIL on a healthy map. Require three zeros spread over ~7s, and let any
     non-zero reading settle it permanently. False alarms would be worse than the
     silence they replace: a rider who learns to ignore this badge has lost it. */
  if(!nf2.length||healthOK)return;
  var got=renderedCount();
  if(got>0){healthOK=true;
    var b=el('b-src');if(b){b.textContent='GRAPH '+EDGES.length;b.className='badge'}
    return}
  if(++healthTries<3){setTimeout(renderHealth,2500);return}
  var b=el('b-src');if(b){b.textContent='RENDER FAIL';b.className='badge bad'}
  show('<b>The map data loaded but nothing is drawing.</b><br>'+
    nf2.length+' trail segments and '+wf.length+' water features are in memory '+
    'with valid coordinates, and the style is valid — so this is the renderer, '+
    'not your download.<br><br>Most likely the map engine could not start its '+
    'worker thread in this WebView.'+
    (glErr?'<br><br>Engine said: <b>'+glErr.replace(/[<>]/g,'')+'</b>':'')+
    '<br><br>Tell Claude you saw <b>RENDER FAIL</b>'+(glErr?' and that message':'')+'.','fail')}
/* The state outline, drawn only below z9.6 and faded out as you approach the
   data. It answers "where am I relative to my download" and nothing else — the
   orange DOWNLOADED box that used to do this job was, correctly, called
   distracting and ugly. The detailed square speaks for itself. */
function drawCoverage(){
  if(!CTX||!CTX.rings)return;
  /* Polygons, not lines: the Census cartographic file is clipped to the
     SHORELINE, so filling it draws land and leaves the Great Lakes as ground.
     The legal state boundary used at take 32 ran far out into the lakes and
     produced a shape nobody recognised. */
  var feats=CTX.rings.map(function(r){
    var ring=r.slice();
    if(ring[0][0]!==ring[ring.length-1][0]||ring[0][1]!==ring[ring.length-1][1])ring.push(ring[0]);
    return {type:'Feature',properties:{},geometry:{type:'Polygon',coordinates:[ring]}}});
  try{map.getSource('state').setData({type:'FeatureCollection',features:feats})}catch(e){}
  var labs=(CTX.labels||[]).map(function(l){
    return {type:'Feature',properties:{n:l.n},geometry:{type:'Point',coordinates:l.at}}});
  try{map.getSource('lakes').setData({type:'FeatureCollection',features:labs})}catch(e){}}
map.on('load',drawCoverage);
/* The map must reflect the current machine from the first frame, not only after
   someone taps the chip — a rider who never touches it is exactly the one who
   needs to be told what is off limits (take 80). */
map.on('load',applyMachine);

/* Locate: fly to the real position when known, otherwise ask for one. The old
   handler delegated to the GeolocateControl, which does nothing useful when the
   rider is outside the region. */
function flyToYou(){
  if(YOU){
    var far=!inRegion(YOU);
    map.easeTo({center:YOU,zoom:far?7.2:14.5,duration:900,essential:true});
    show(far?'<b>You are here</b> — about '+Math.round(awayMi)+' mi from '+
      (BUNDLE.name||'the region')+'. The dashed box is what you have downloaded; '+
      'tap it or a chip to jump there.':
      '<b>You are here.</b> Inside the downloaded area.','');
    return true}
  return false}

/* ══ ADDRESSES ══════════════════════════════════════════════════════════════
   Census TIGER address RANGES, baked into the bundle. Each road segment carries
   the house numbers at each end per side, so a point resolves by finding the
   nearest segment, working out which side of it you are on, and interpolating.
   That is how rural geocoding works where there are no address points.

   Both directions are offline. Coverage is partial out here, and when there is
   no address the card shows nothing rather than announcing an absence. */
var ADDR_CAP=0.09;                 /* miles; inside this, it IS your address */
/* Beyond ADDR_CAP the app said nothing at all, and that threw away a true and
   useful answer: Mio sits 307 m from an addressed road and Luzerne 377 m, so
   both got silence. "A quarter mile south-west of 4951 S Branch Rd" is exactly
   what you give dispatch when there is no address where you are standing.
   Reported as a BEARING AND DISTANCE FROM a road, never as your address — the
   distinction is the whole point (take 69). */
var ADDR_NEAR=0.55;                /* miles; beyond this even that is noise */

function segNear(at,a,b){
  /* Point-to-segment in local planar space, returning distance in miles, the
     parameter t along the segment, and which side the point falls on. */
  var kx=Math.cos(at[1]*Math.PI/180)*69.172, ky=69.172;
  var ax=(a[0]-at[0])*kx, ay=(a[1]-at[1])*ky,
      bx=(b[0]-at[0])*kx, by=(b[1]-at[1])*ky;
  var dx=bx-ax, dy=by-ay, L=dx*dx+dy*dy;
  var t=L>0?Math.max(0,Math.min(1,-(ax*dx+ay*dy)/L)):0;
  var px=ax+t*dx, py=ay+t*dy;
  return {d:Math.sqrt(px*px+py*py), t:t, px:px, py:py, side:(dx*(-ay)-dy*(-ax))>0?'L':'R'}}

/* Which county a point is in. Michigan dispatch is organised by county — it
   decides who is sent — and the card could name the road, the junction and the
   elevation but not the county (take 72). Ray casting against the simplified
   cartographic rings in context.json; 9 counties, 70 points, 1.4 KB. */
function countyAt(at){
  if(!CTX||!CTX.counties)return null;
  var x=at[0],y=at[1];
  for(var c=0;c<CTX.counties.length;c++){
    var co=CTX.counties[c];
    for(var r=0;r<co.r.length;r++){
      var ring=co.r[r],inside=false;
      for(var i=0,j=ring.length-1;i<ring.length;j=i++){
        var xi=ring[i][0],yi=ring[i][1],xj=ring[j][0],yj=ring[j][1];
        if(((yi>y)!==(yj>y))&&(x<(xj-xi)*(y-yi)/((yj-yi)||1e-12)+xi))inside=!inside}
      if(inside)return co.n}}
  return null}

function addressAt(at,wide){
  if(!ADDR||!ADDR.segs)return null;
  var S=ADDR.segs,best=null,bd=wide?ADDR_NEAR:ADDR_CAP;
  for(var i=0;i<S.length;i++){var g=S[i];
    var r=segNear(at,[g[1],g[2]],[g[3],g[4]]);
    if(r.d<bd){bd=r.d;best={g:g,r:r}}}
  if(!best)return null;
  var g=best.g,r=best.r;
  var f=r.side==='L'?g[5]:g[7], t=r.side==='L'?g[6]:g[8];
  if(!f&&!t){f=r.side==='L'?g[7]:g[5];t=r.side==='L'?g[8]:g[6]}
  if(!f&&!t)return null;
  var n=Math.round(f+(t-f)*r.t);
  /* keep the parity of the side's range — odd side stays odd */
  if(f%2!==n%2)n+=(n>f?-1:1);
  var txt=n+' '+ADDR.names[g[0]]+(g[9]?', '+g[9]:'');
  var out={n:n,street:ADDR.names[g[0]],zip:g[9]||0,d:bd,txt:txt,near:false};
  if(bd>ADDR_CAP){
    /* far enough that this is NOT the address of this point — say where it is
       relative to the road instead, and say how far. */
    var c=compass((Math.atan2(-r.px,-r.py)*180/Math.PI+360)%360);
    out.near=true;
    out.txt=(bd<0.1?Math.round(bd*5280)+' ft':bd.toFixed(1)+' mi')+' '+c+' of '+txt}
  return out}

function geocode(q){
  /* "4952 S Branch Rd" -> a point, by finding a segment of that name whose
     range contains the number and interpolating along it. */
  if(!ADDR||!ADDR.segs)return null;
  var m=/^\s*(\d+)\s+(.+?)\s*$/.exec(q);
  if(!m)return null;
  var want=+m[1],nm=m[2].toLowerCase().replace(/\.$/,'');
  var S=ADDR.segs,hit=null;
  for(var i=0;i<S.length;i++){var g=S[i];
    var name=ADDR.names[g[0]].toLowerCase();
    if(name.indexOf(nm)<0)continue;
    [[g[5],g[6]],[g[7],g[8]]].forEach(function(rg){
      if(hit||!rg[0]&&!rg[1])return;
      var lo=Math.min(rg[0],rg[1]),hi=Math.max(rg[0],rg[1]);
      if(want<lo||want>hi)return;
      var t=hi>lo?(want-rg[0])/(rg[1]-rg[0]):0.5;
      t=Math.max(0,Math.min(1,t));
      hit={c:[g[1]+(g[3]-g[1])*t, g[2]+(g[4]-g[2])*t],
           t:want+' '+ADDR.names[g[0]]+(g[9]?', '+g[9]:'')}})}
  return hit}

/* ══ PLACE CARD ═════════════════════════════════════════════════════════════
   Tap a pin or open ground and get a card: where it is, how high, what trail is
   nearest, how far and which way from you — then the things you would actually
   want to do with it. This is the interaction pattern every first-party map app
   uses, and the app had none of it. */
var dropM=null,DROP=null;

function bearingTo(a,b){
  var y=Math.sin((b[0]-a[0])*Math.PI/180)*Math.cos(b[1]*Math.PI/180),
      x=Math.cos(a[1]*Math.PI/180)*Math.sin(b[1]*Math.PI/180)-
        Math.sin(a[1]*Math.PI/180)*Math.cos(b[1]*Math.PI/180)*Math.cos((b[0]-a[0])*Math.PI/180);
  var d=(Math.atan2(y,x)*180/Math.PI+360)%360;
  var C=['N','NNE','NE','ENE','E','ESE','SE','SSE','S','SSW','SW','WSW','W','WNW','NW','NNW'];
  return {deg:Math.round(d),pt:C[Math.round(d/22.5)%16]}}

function nearestEdgeTo(at){
  var best=null,bd=1e9;
  for(var i=0;i<EDGES.length;i++){var e=EDGES[i];
    var n=NODES[e.a],d=mi(at,n);
    if(d<bd){bd=d;best=e}}
  return best?{e:best,mi:bd}:null}

function placeCard(at,kind,title){
  var e=elevAt(at),ne=nearestEdgeTo(at),b=bearingTo(ME,at),d=mi(ME,at);
  var rows=[];
  rows.push('<b style="font-size:var(--t-lg)">'+title+'</b>');
  rows.push('<span class="mono" style="font-size:var(--t-lg)">'+at[1].toFixed(5)+' '+
    at[0].toFixed(5)+'</span> <span class="unit">DD'+
    (e!==null?' · '+ft(e)+' ft':'')+'</span>');
  if(kind!=='me')rows.push('<span class="unit">'+d.toFixed(2)+' mi '+b.pt+
    ' ('+b.deg+'°) from your position</span>');
  var ad=addressAt(at)||addressAt(at,true);
  if(ad)rows.push('<span style="color:#F5EFE2">'+ad.txt+'</span>');
  if(ne)rows.push('<span class="unit">nearest: '+(ne.e.n||label(ne.e.c))+
    (ne.e.id?' · '+ne.e.id:'')+' — '+ne.mi.toFixed(2)+' mi</span>');
  var acts=[];
  if(kind!=='me')acts.push('<button class="chip" id="pc-route">▸ Directions here</button>');
  if(kind!=='home')acts.push('<button class="chip" id="pc-home">⌂ Make this home</button>');
  if(kind!=='me')acts.push('<button class="chip" id="pc-start">◉ Start from here</button>');
  if(kind==='me'&&posMode==='gps')acts.push('<button class="chip" id="pc-disp">☎ Dispatch card</button>');
  acts.push('<button class="chip" id="pc-go">⤢ Centre</button>');
  if(kind==='drop'){
    acts.push('<button class="chip" id="pc-wpt">☆ Save as waypoint</button>');
    acts.push('<button class="chip" id="pc-drop">✕ Remove pin</button>')}
  show(rows.join('<br>')+'<div style="margin-top:9px">'+acts.join(' ')+'</div>','');
  var on=function(id,fn){var b=el(id);if(b)b.addEventListener('click',fn)};
  on('pc-route',function(){routeToPoint(at,title)});
  on('pc-home',function(){logAct('act  make this home');HOME=at.slice();hM.setLngLat(HOME);clearRoute();syncSafety();
    /* The pin has become the ⌂ marker. Leaving a second marker sitting on top of
       it was the whole confusion at take 35: the next long-press appeared to
       "wipe out" a pin that had in fact already done its job. */
    if(kind==='drop')clearDrop();
    show('<b>Home is here now.</b> The ⌂ pin holds this spot — '+
      'press and hold anywhere for a new pin.','')});
  on('pc-start',function(){logAct('act  start from here');
    if(posMode==='gps')return show('A live GPS fix is driving your position — '+
      'the start pin follows you and cannot be moved by hand.','');
    ME=at.slice();mM.setLngLat(ME);paint();syncSafety();clearRoute();
    if(kind==='drop')clearDrop();
    show('<b>Start is here now.</b> The ◎ pin holds this spot and routes measure '+
      'from it — press and hold anywhere for a new pin.','')});
  on('pc-disp',function(){el('btn-disp').click()});
  on('pc-go',function(){map.easeTo({center:at,zoom:Math.max(map.getZoom(),14),
    duration:600,essential:true})});
  on('pc-wpt',function(){
    var nm=wpName(at);
    if(!wpAdd({n:nm,p:at.slice(),r:BUNDLE.region||null,ts:Date.now()}))
      return show('<b>Could not save.</b> This browser will not let the page '+
        'store anything; in the app it works normally.','fail');
    logAct('act  saved waypoint '+nm);
    wpDraw();clearDrop();
    show('Saved as <b>'+nm+'</b>.<br><span class="sub">On this phone only. '+
      'Find it again under \u2606 Saved.</span>','pass')});
  on('pc-drop',function(){clearDrop();show('Pin removed.','')});
}

function wpDraw(){
  var a=wpLoad().filter(function(x){return !x.r||!BUNDLE.region||x.r===BUNDLE.region});
  try{map.getSource('wpts').setData({type:'FeatureCollection',
    features:a.map(function(x){return {type:'Feature',
      properties:{n:x.n,ts:x.ts||0},
      geometry:{type:'Point',coordinates:x.p}}})})}catch(e){}
  return a}

function clearDrop(){
  if(DROP)logAct('pin  removed');
  if(dropM){try{dropM.remove()}catch(e){}dropM=null}
  DROP=null}

function dropPin(at){
  logAct('pin  dropped at '+at[1].toFixed(5)+','+at[0].toFixed(5));
  DROP=at.slice();
  if(!dropM){dropM=new maplibregl.Marker({element:mk('drop')}).setLngLat(DROP).addTo(map);
    dropM.getElement().addEventListener('click',function(ev){ev.stopPropagation();
      placeCard(DROP,'drop','Dropped pin')})}
  else dropM.setLngLat(DROP);
  placeCard(DROP,'drop','Dropped pin')}

try{window.map=map;window.PLACES=PLACES;window.placeCard=placeCard;
    window.paddleCard=paddleCard;window.PADDLE_MPH=PADDLE_MPH;
    window.headingNow=headingNow;window.railSet=railSet;
    window.guideShow=guideShow;window.guideClose=guideClose;
    window.showQuiet=showQuiet;
    window.railState=function(){var b=el('railbody');
      return{folded:el('rail').className==='folded',
             h:b?Math.round(b.getBoundingClientRect().height):-1}};
    /* The results array itself, not the formatted report — a check that greps
       rendered text is testing the formatter as much as the result (take 109). */
    window.__st=function(){return ST};
    window.__geo={addressAt:addressAt,geocode:geocode,
                  get ADDR(){return ADDR}};
    /* A96: the dispatch card runs six full scans on one tap and has never been
       timed. Exposed so the harness can measure them individually rather than
       measuring "the card felt slow" (take 93). */
    window.__restrict={of:restrictOf,table:RESTRICT,legal:machineLegal,
                       setMachine:function(m){if(MACHINE[m])machine=m},
                       /* the region carries none, so the only way to test the
                          refusal is to make one (landmine 45) */
                       inject:function(e,txt){
                         var b=B[e.bi>=0?e.bi:0];
                         if(e.bi<0){B.push(new Array(BK.length).fill(null));e.bi=B.length-1;b=B[e.bi]}
                         else{b=B[e.bi]=b.slice()}
                         b[BK.indexOf('rst')]=txt;return e}};
    window.__disp={nearestEdge:nearestEdge,nearestJunction:nearestJunction,
                   nearestPavement:nearestPavement,countyAt:countyAt,
                   addressAt:addressAt,get ME(){return ME}};
    window.__route={buildLoops:buildLoops,nearestNode:nearestNode,
                    machineLegal:machineLegal,EDGES:EDGES,ADJ:ADJ,attrs:attrs,
                    setMachine:function(m){if(MACHINE[m])machine=m},
                    get ME(){return ME}};
    window.__ride={start:startRecording,fix:rideFix,stop:rideStop,report:rideReport,
                   get R(){return RIDE},get last(){return LASTRIDE}};
    /* the layout matrix must be able to put the HUD on screen at four device
       sizes; measuring it hidden would measure nothing (landmine 85) */
    window.hudShow=hudShow;window.hudSet=hudSet;window.hudPaint=hudPaint;
    window.__mach={set:function(m){if(!MACHINE[m])return;machine=m;
                     var i=ORDER.indexOf(m);if(i>=0)machIdx=i;applyMachine()},
                   ok:function(){return (MACHINE[machine]||{}).ok||[]},
                   illegal:machineIllegal};
    window.PAL=PAL}catch(e){}

/* ══ SELF-TEST ══════════════════════════════════════════════════════════════
   The same battery of checks runs here, on the device, that render.mjs runs in
   headless Chrome. That is the whole point: Chrome cannot tell me how Android's
   WebView behaves, and Jacob should not have to tap through thirty features to
   find out. He taps once and sends the report; anything that differs between
   the two runs is device-specific by construction.

   Every check records what it OBSERVED, not just pass/fail — a bare "FAIL
   routing" is nearly useless to debug from, whereas "FAIL routing · 0 profiles,
   nearestNode returned -1" names the layer that broke. */
var ST=[],ACT=[],T0=Date.now();
/* A ring buffer of what was actually done. Jacob reports symptoms in prose —
   "I clicked start from here, then tried to drop another pin" — and prose loses
   the order and the state. Forty entries is enough to cover any confusion and
   small enough to paste. Nothing here leaves the phone unless he shares it. */
function logAct(s){
  ACT.push(((Date.now()-T0)/1000).toFixed(1)+'s  '+s);
  if(ACT.length>40)ACT.shift()}
try{document.addEventListener('click',function(e){
  var t=e.target;if(!t)return;
  var c=String(t.className||'');
  if(c.indexOf('chip')<0&&c.indexOf('act')<0&&c.indexOf('rc')<0&&c.indexOf('hit')<0)return;
  logAct('tap  '+((t.id||t.textContent||'').replace(/\s+/g,' ').trim().slice(0,26)))
},true)}catch(e){}
function stAdd(g,id,ok,detail){ST.push({g:g,id:id,ok:ok,d:detail===undefined?'':String(detail)})}
function stInfo(g,id,detail){ST.push({g:g,id:id,ok:null,d:String(detail)})}
function stTry(g,id,fn,check){
  try{var v=fn();var r=check?check(v):{ok:!!v,d:v};
    stAdd(g,id,r.ok,r.d)}
  catch(e){stAdd(g,id,false,'threw: '+(e&&e.message||e))}}

function glInfo(){
  try{var c=map.getCanvas(),gl=c.getContext('webgl2')||c.getContext('webgl');
    if(!gl)return{r:'no gl context',v:''};
    var d=gl.getExtension('WEBGL_debug_renderer_info');
    return{r:d?gl.getParameter(d.UNMASKED_RENDERER_WEBGL):'masked',
           v:d?gl.getParameter(d.UNMASKED_VENDOR_WEBGL):'masked',
           mt:gl.getParameter(gl.MAX_TEXTURE_SIZE)}}
  catch(e){return{r:'err '+e.message,v:''}}}

function stEnv(){
  var ua=navigator.userAgent||'';
  var wv=(ua.match(/Chrome\/([\d.]+)/)||[])[1]||'n/a';
  var C=window.Capacitor||{};
  var g=glInfo();
  stInfo('ENV','take',(el('title')&&el('title').textContent||'').replace(/\s+/g,' ').trim());
  stInfo('ENV','region',(BUNDLE.region||'?')+' "'+(BUNDLE.name||'?')+'"');
  stInfo('ENV','bundle',(BUNDLE.hash?String(BUNDLE.hash).slice(0,16)+' ':'')+
    (BUNDLE.built||'?'));
  stInfo('ENV','ua',ua.slice(0,150));
  stInfo('ENV','webview','Chrome/'+wv);
  stInfo('ENV','native',(C.isNativePlatform?C.isNativePlatform():false)+
    ' plugins='+Object.keys((C.Plugins)||{}).join(','));
  stInfo('ENV','gl',g.r+' | '+g.v+' | maxTex='+g.mt);
  stInfo('ENV','screen',innerWidth+'x'+innerHeight+' dpr='+devicePixelRatio+
    ' scr='+screen.width+'x'+screen.height);
  stInfo('ENV','cores',(navigator.hardwareConcurrency||'?')+
    ' mem='+(navigator.deviceMemory||'?')+'GB online='+navigator.onLine);
}

function stLoad(){
  /* Was 'bundle-complete', asserting state==='complete'. PARTIAL is a DESIGNED
     state — a region built while Overpass is down legitimately has no water and
     the app is supposed to SAY so (landmine 34). Asserting completeness scored
     correct behaviour as a failure, which is landmine 56's corollary: assert the
     system's RESPONSE to a condition, never the condition itself.
     What matters is that the state and the named layers agree — that the app is
     telling the truth about what it has, whichever answer that is (take 76). */
  var _hon=(BUNDLE.state==='partial')===!!(BUNDLE.absent&&BUNDLE.absent.length);
  stAdd('LOAD','bundle-honest',_hon,
    BUNDLE.state+(BUNDLE.absent&&BUNDLE.absent.length?
      ' — names absent: '+BUNDLE.absent.join(','):' — nothing absent'));
  stAdd('LOAD','offline-clean',remoteHits===0,remoteHits+' remote requests');
  /* Saved routes are on-device state, not a network surface — PROTOCOL §8 draws
     the line at requests leaving the phone. Report what storage holds so a
     rider can see it is local and finite (take 79). */
  var _sv=svLoad();
  stAdd('LOAD','saved-routes',true,
    svAvailable()?_sv.length+' saved on this phone, nothing sent anywhere':
      'storage unavailable in this browser — saving is disabled, not silent');
  stAdd('LOAD','glyph-pack',GLYPH_BUF&&GLYPH_BUF.length>1000,
    (GLYPH_BUF?GLYPH_BUF.length:0)+' bytes');
  stAdd('LOAD','graph',EDGES.length>1000&&NODES.length>500,
    EDGES.length+' edges / '+NODES.length+' nodes');
  stAdd('LOAD','terrain',!!(TR&&TR.ne&&TR.ne.length===NODES.length),
    TR&&TR.ne?TR.ne.length+' node elevations':'absent');
  /* IDX is built lazily on first search, so reading it cold always says 0 —
     a number that looks like a failure and is actually just "not built yet". */
  var idx=buildIndex();
  stAdd('LOAD','search-index',idx&&idx.length>100,(idx?idx.length:0)+' entries');
}

function stRender(){
  stAdd('RENDER','style-loaded',map.isStyleLoaded(),String(map.isStyleLoaded()));
  stAdd('RENDER','no-map-errors',!glErr,glErr||'none');
  var q=function(ids){try{return map.queryRenderedFeatures({layers:ids}).length}
    catch(e){return -1}};
  var all=renderedCount();
  stAdd('RENDER','features-drawn',all>0,all+' in viewport');
  /* Viewport-dependent, so it cannot be a pass/fail: Jacob's map was parked over
     Brainard Springs, where there is genuinely no designated trail, and this
     reported FAIL on a perfectly good map. The trail-names check below jumps to
     a known site and IS a real assertion (take 64). */
  stInfo('RENDER','trails',q(['trail50','route72','moto24','fstrail','mccct'])+
    ' designated · '+q(['track'])+' two-track in the view you left it on');
  stAdd('RENDER','roads',q(['fsroad','minor','paved','track'])>0,
    q(['fsroad','minor','paved','track'])+' features');
  /* Counted at the CURRENT viewport, this reported 0 on a device whose screen
     was visibly showing "The Pink Store" — the map was simply zoomed somewhere
     with no label in frame. Jump to a known anchor, count, restore. Landmine 54
     for the fifth time: a check must control where it looks. */
  var was={c:map.getCenter(),z:map.getZoom()};
  var site=anchorOf('site');
  map.jumpTo({center:site,zoom:14.5});
  /* Knowing WHICH trail you are on is the point of a trail map. text-max-angle
     was 32 degrees, which on a network this twisty placed zero names — the data
     had a label on 100% of trail edges and almost none were shown (take 44). */
  /* Symbols are placed ASYNCHRONOUSLY: querying in the same tick as the jump
     returns 0 on a map that shows several a moment later — which is exactly what
     it reported for Jacob while trail-names, which waits, found 4. stLabels()
     already asserts this properly, so here it is only information. */
  var lb=q(['lbl-place','lbl-trail']);
  stInfo('RENDER','labels',lb+' at '+site[1].toFixed(3)+','+site[0].toFixed(3)+
    ' z13.6 — placed asynchronously, see trail-names for the real check');
  stInfo('RENDER','labels-here',q(['lbl-place','lbl-trail'])+' at the view you left it on');
  map.jumpTo({center:[was.c.lng,was.c.lat],zoom:was.z});
  var vis;try{vis=map.getLayoutProperty('sat','visibility')}catch(e){vis='err'}
  stInfo('RENDER','basemap','sat visibility='+vis+' SAT_OK='+SAT_OK);
  /* Ground resolution is the whole complaint: at 22 m/px a two-track is a
     twentieth of a pixel. Report it so the improvement is visible in the
     report, not just in an opinion. */
  if(TILES){
    var mpp=156543.03*Math.cos(CTR[1]*Math.PI/180)/Math.pow(2,TILES.zmax);
    stAdd('RENDER','imagery',mpp<6,
      'tiles z'+TILES.zmin+'-z'+TILES.zmax+' · '+mpp.toFixed(2)+' m/px · '+
      TILES.count+' tiles, '+(TILES.bytes/1048576).toFixed(0)+' MB')}
  else if(SAT_OK){
    var b=SATBOX,px=1500;
    var km=(b[2]-b[0])*111.32*Math.cos(CTR[1]*Math.PI/180);
    stInfo('RENDER','imagery','single mosaic · about '+(km*1000/px).toFixed(0)+
      ' m/px — no tiles in this bundle')}
}

function stLayout(){
  /* Every UI bug Jacob has reported was invisible to this self-test: a strip
     that could not scroll, options unreachable off-screen, a map that jumped.
     None of them are data or logic — they are LAYOUT, and layout only exists on
     a real device at a real viewport. These checks run there. */
  var vw=document.documentElement.clientWidth;

  /* A96. The dispatch card runs six full scans on one tap — nearestEdge alone
     decodes every edge polyline in the region. It is the highest-stakes screen
     in the app and had never been timed on a phone, only reasoned about. This
     puts the real number in Jacob's next report instead of my extrapolation
     from a desktop, which is the same mistake as measuring a 900x1400 viewport
     (landmine 87). */
  (function(){
    try{
      /* ME is only set when you are INSIDE the region (see classifyFix), so
         this returned silently on Jacob's take-108 report — he tested from home,
         135 mi away — and in the headless harness, which has no GPS at all.
         A check added at take 93 had therefore never once run, anywhere.
         The point is to measure the SCAN, not to require a live fix, so it now
         times against a point that always exists (take 109, landmine 85). */
      var at=(ME&&ME.slice)?ME.slice():
             (CTR&&CTR.slice)?CTR.slice():null;
      if(!at)return;
      var t0=performance.now();
      nearestEdge(at);nearestJunction(at);nearestPavement(at);
      countyAt(at);addressAt(at);addressAt(at,true);
      var ms=performance.now()-t0;
      stAdd('PERF','dispatch-scan',ms<600,
        Math.round(ms)+' ms to assemble the dispatch card ('+EDGES.length+
        ' edges scanned from '+((ME&&ME.slice)?'your position':'the region centre')+
        ') — this is what you wait for after tapping Dispatch');
    }catch(e){stInfo('PERF','dispatch-scan','could not time: '+e)}
  })();
  stInfo('UI','viewport',vw+'x'+document.documentElement.clientHeight+
    ' css px · dpr '+devicePixelRatio);

  /* Anything wider than the screen is a layout bug. This is exactly what the
     route strip did at take 35 — 788 px inside a 411 px phone — and nothing
     caught it but a person squinting at a screenshot. */
  var wide=[];
  Array.prototype.forEach.call(document.querySelectorAll('#shell *'),function(e){
    var r=e.getBoundingClientRect();
    if(r.width>vw+1)wide.push((e.id||e.className||e.tagName)+' '+Math.round(r.width)+'px')});
  stAdd('UI','nothing-overflows',wide.length===0,
    wide.length?wide.slice(0,3).join(' · '):'no element exceeds '+vw+' px');

  /* A scrollable strip that cannot scroll hides its later options entirely. */
  var strips=[],bad=[];
  Array.prototype.forEach.call(document.querySelectorAll('#shell *'),function(e){
    var ov=getComputedStyle(e).overflowX;
    if(ov!=='auto'&&ov!=='scroll')return;
    if(!e.children.length)return;
    strips.push(e.id||e.className);
    /* content wider than the box is fine — that IS scrolling. Content that
       overflows the SCREEN while the box does not scroll is the bug. */
    var last=e.children[e.children.length-1].getBoundingClientRect();
    var box=e.getBoundingClientRect();
    if(last.right>box.right+1&&e.scrollWidth<=e.clientWidth+1)
      bad.push((e.id||e.className)+' clips its last child')});
  stAdd('UI','strips-scroll',bad.length===0,
    bad.length?bad.join(' · '):strips.length+' scrollable strip(s), all reachable');

  /* Gloved thumbs on a bouncing bike. 38 css px is the floor. */
  var small=[];
  Array.prototype.forEach.call(document.querySelectorAll('.chip,.act,.rc,.hit'),function(e){
    var r=e.getBoundingClientRect();
    if(r.height>0&&r.height<38)small.push((e.id||e.textContent||'?').slice(0,14)+
      ' '+Math.round(r.height)+'px')});
  stAdd('UI','tap-targets',small.length===0,
    small.length?small.slice(0,3).join(' · '):'all ≥38 px tall');

  /* Controls that have slid off the bottom cannot be pressed. */
  var vh=document.documentElement.clientHeight,off=[];
  /* A folded rail clips its children while they keep their natural positions,
     so Return home measures as off-screen when it is simply put away. Measure
     with the drawer OPEN — that is the state where these controls matter — and
     put it back. Forcing the conditional state is part of the check
     (landmine 111, take 109). */
  /* The rail is a drawer now (A127). When it is folded its children keep their
     natural positions inside a clipped box, so they measure as off-screen while
     being exactly where they belong — put away, one tap from the handle.
     Forcing it open to measure was tried and it fought the fold transition; the
     honest check is simpler. A folded drawer is REPORTED, not failed, and the
     handle itself is what must be on screen — that is the thing that would
     actually strand a rider (landmine 173: reachable, not merely wired). */
  /* Ask the GEOMETRY, not the class name. The check runs in the same tick as
     the show() that opened the drawer, so the class already reads open while
     the 260 ms max-height transition has not moved — `rail="" folded=false
     railbody=0` was the exact state, with Return home at y=1015 inside a
     zero-height clipped box. A class is an intention; a rect is a fact, and
     mid-transition they disagree (take 109). */
  var _r=el('rail'),_rb=el('railbody');
  var _folded=!_rb||_rb.getBoundingClientRect().height<8;
  var LIST=_folded?['peek','c-ride','c-locate']
                  :['btn-home','btn-disp','btn-steps','btn-retrace','c-ride','c-locate'];
  LIST.forEach(function(id){
    var e=el(id);if(!e)return;var r=e.getBoundingClientRect();
    if(r.height===0)return;
    if(r.bottom>vh+2||r.top<0)off.push(id)});
  stAdd('UI','controls-on-screen',off.length===0,
    off.length?off.join(', ')+' outside the viewport'
      :(_folded?'primary controls reachable — the details drawer is folded, '+
                'its handle is on screen'
              :'primary controls all reachable'));


  /* ── LIFTED FROM A DEAD TWIN (take 111) ──────────────────────────────
     These three checks lived in a SECOND `function stLayout(){}` further
     up the file. JavaScript keeps the last declaration and discards the
     first without a word, so they had never run — the same trap that hid
     dispatch-scan for sixteen takes (landmine 175). The dead twin is gone
     and a gate check now refuses a duplicate function name. */
  /* The map must agree with the router about what this machine may use. Both
     read MACHINE[machine].ok, so this asserts they are actually WIRED, not that
     two lists happen to match (take 80). */
  var _no=machineIllegal(),_okc=(MACHINE[machine]||{}).ok||[];
  var _wired=true;
  try{['trail50','moto24','track'].forEach(function(id){
    var e=map.getPaintProperty(id,'line-opacity');
    if(!e||!e.length||e[0]!=='case')_wired=false})}catch(e){_wired=false}
  stAdd('UI','machine-on-map',_wired,
    MACHINE[machine].lbl.replace(/^\S+\s/,'')+' — '+_okc.length+' classes legal, '+
    _no.length+' faded'+(_no.length?' ('+_no.join(', ')+')':''));
  /* `_hb`, `_hs` and `_rid` were defined earlier in the dead twin's body and
     came across as undefined references — which threw, and killed every check
     after this one. Defined here (take 111). */
  var _hb=el('hudbar'),_hs=el('hudstats'),_rid=!!rideMode;
  stAdd('UI','hud-matches-ride',
    !!_hb&&!!_hs&&_hb.hidden===!_rid&&_hs.hidden===!_rid,
    _rid?'riding — ribbon and stats on screen':'not riding — HUD off screen');
  var off=[];
  Array.prototype.forEach.call(document.querySelectorAll('#actions .act'),function(e){
    var r=e.getBoundingClientRect();
    if(r.right<0||r.left>vw+1)off.push(e.textContent.slice(0,12))});
  stAdd('UI','actions-reachable',off.length===0,
    off.length?'off-screen: '+off.join(', '):'all primary actions on screen');
  /* vh is already in scope from the live function; only the map height is new.
     The threshold is the ONE number that matters after the take-109 drawer: the
     map is the product, and if it ever drops below a third of the screen
     something has gone wrong with the chrome. */
  var mh=map.getContainer().getBoundingClientRect().height;
  stAdd('UI','map-has-room',mh>vh*0.35,
    Math.round(mh)+' of '+vh+' px ('+Math.round(100*mh/vh)+'% of the screen)');

}

function stData(){
  /* Elevation against surveyed landmarks — catches a DEM that loaded but is
     georeferenced wrong, which no structural check would notice. */
  var known=[['Mio',-84.1330,44.6597,965],['Bull Gap',-84.0274,44.6166,1070],
             ['The Pink Store',-84.1279,44.5219,1240]];
  known.forEach(function(k){
    var e=elevAt([k[1],k[2]]);
    if(e===null)return stAdd('DATA','elev-'+k[0],false,'no elevation');
    var f=Math.round(e*3.28084),d=Math.abs(f-k[3]);
    stAdd('DATA','elev-'+k[0],d<=90,f+' ft vs '+k[3]+' surveyed (Δ'+d+')')});
  /* Addresses: coverage out here is partial by nature, so the check is that the
     geocoder WORKS where data exists and round-trips, not that every point has
     an address. A point with no address must yield null, never a guess. */
  if(!ADDR||!ADDR.segs)stInfo('DATA','address','no address index in this bundle');
  else{
    stInfo('DATA','address-index',ADDR.segs.length+' segments, '+
      ADDR.names.length+' street names');
    var hits=0,near=0,shown=[];
    PLACES.forEach(function(pl){
      var at=[pl[1],pl[2]],a=addressAt(at),n=a?null:addressAt(at,true);
      if(a){hits++;if(shown.length<2)shown.push(pl[0]+': '+a.txt)}
      else if(n){near++;if(shown.length<3)shown.push(pl[0]+': '+n.txt)}});
    stInfo('DATA','address-at-anchors',hits+' exact, '+near+' near, of '+
      PLACES.length+' · '+
      (shown.join(' · ')||'none near an anchor, which is normal out here'));
    var g0=ADDR.segs[0],mid=[(g0[1]+g0[3])/2,(g0[2]+g0[4])/2];
    var a0=addressAt(mid);
    if(!a0)stAdd('DATA','address-roundtrip',false,'a segment midpoint resolved to nothing');
    else{var f=geocode(a0.n+' '+a0.street);
      if(!f)stAdd('DATA','address-roundtrip',false,'"'+a0.txt+'" did not geocode back');
      else{var m2=mi(mid,f.c);
        stAdd('DATA','address-roundtrip',m2<0.6,
          '"'+a0.txt+'" -> back within '+Math.round(m2*5280)+' ft')}}
    var far=addressAt([CTR[0]+0.9,CTR[1]+0.9]);
    stAdd('DATA','address-honest',far===null,
      far?'invented an address 60+ mi away: '+far.txt:'no address far outside the data — omitted, not guessed');
  }
  stTry('DATA','search-town',function(){return search('mio')},
    function(v){return{ok:v&&v.length>0,d:(v?v.length:0)+' hits'}});
  stTry('DATA','search-trail',function(){return search('bull')},
    function(v){return{ok:v&&v.length>0,d:(v?v.length:0)+' hits'}});
}

function stRouting(){
  var a=anchorOf('site'),b=anchorOf('town');
  var na=nearestNode(a),nb=nearestNode(b);
  stAdd('ROUTE','snap',na>=0&&nb>=0,'nodes '+na+' -> '+nb);
  if(na<0||nb<0)return;
  var got=0,detail=[];
  PROFILES.forEach(function(pf){
    try{var path=route(na,nb,pf.f);
      if(path&&path.length){got++;var s=summarise(path);
        detail.push(pf.h+' '+s.mi.toFixed(1)+'mi')}}
    catch(e){detail.push(pf.h+' threw: '+(e&&e.message||e))}});
  stAdd('ROUTE','profiles',got>=2,got+'/'+PROFILES.length+' · '+detail.join(', '));
  stTry('ROUTE','directions',function(){
      var path=route(na,nb,PROFILES[0].f);return directions(path,na)},
    function(v){return{ok:v&&v.length>0,d:(v?v.length:0)+' steps'}});
  /* legality must actually change what is routable */
  var before=machine;
  try{
    machine='bike';var pb=route(na,nb,PROFILES[0].f);
    machine='sxs';var ns=nearestNode(ME),ps=ns>=0?route(ns,nearestNode(HOME),PROFILES[0].f):null;
    /* An SxS finding no route between two points is usually correct — 72"
       machines are barred from most of this network. The filter is only broken
       if a 72" machine cannot snap to ANY node at all. */
    var sxsCanSnap=ns>=0;
    stAdd('ROUTE','machine-filter',!!pb&&sxsCanSnap,
      'bike '+(pb?pb.length:0)+' edges · sxs snaps='+sxsCanSnap+
      ' route='+(ps?ps.length+' edges':'none legal (expected on bike-only trail)'));
    var closedUsed=(pb||[]).filter(function(e){return e.c==='closed'||e.c==='fsclosed'}).length;
    stAdd('ROUTE','closures-avoided',closedUsed===0,closedUsed+' closed edges in route');
  /* Loops are the impromptu-ride feature. Two things make one useful: it lands
     near the distance asked for, and it does not simply ride out and back. */
  try{
    var la=nearestNode(anchorOf('site'));
    if(la<0)stInfo('ROUTE','loop','no legal node near the site anchor');
    else{
      var L=buildLoops(la,15);
      if(!L.length)stAdd('ROUTE','loop',false,'no 15 mi loop found from the site anchor');
      else{
        var worst=0,rep=0,txt=[];
        L.forEach(function(o){
          var e=Math.abs(o.s.mi-15)/15;if(e>worst)worst=e;
          if(o.repeat>rep)rep=o.repeat;
          txt.push(o.h.replace('Loop · ','')+' '+o.s.mi.toFixed(1)+'mi '+
            o.s.off.toFixed(1)+'mi trail '+Math.round(o.repeat*100)+'% twice')});
        stAdd('ROUTE','loop',worst<0.30&&rep<0.40,
          txt.join(' · ')+' (target 15)')}}
  }catch(e){stAdd('ROUTE','loop',false,'threw: '+(e&&e.message||e))}
  }catch(e){stAdd('ROUTE','machine-filter',false,'threw: '+e.message)}
  machine=before;
}

function stSafety(){
  /* The drill calls startRecording, which since take 41 also starts ride
     telemetry and a 20 s interval. A self-test that leaves a live ride running
     is worse than one that skips the check — it would report the DRILL as the
     rider's last ride, and leak a timer for the life of the app. */
  /* The drill calls startRecording(), which turns the ride HUD on. It restored
     TRUCK, crumbs, RIDE and posMode and left the compass ribbon showing —
     over the place chips, with no heading, forever. Jacob ran the self-test in
     the field and got exactly that: "the compass popped up at the top… it
     doesn't work whatever it is." A drill must put back EVERYTHING it moved,
     not just the state it was written to think about (take 84). */
  var save={T:TRUCK,c:crumbs.slice(),m:crumbMi,p:posMode,me:ME.slice(),
            ride:RIDE,lastride:LASTRIDE,
            hud:!!(el('hudbar')&&el('hudbar').hidden),
            chips:!!(el('chips')&&el('chips').hidden)};
  try{
    var c=CTR,pts=[];
    for(var i=0;i<25;i++)pts.push([c[0]+i*0.0008,c[1]+i*0.0005]);
    startRecording(pts[0]);
    for(var j=1;j<pts.length;j++)record(pts[j]);
    stAdd('SAFETY','breadcrumb',crumbMi>0.5,crumbMi.toFixed(2)+' mi from 25 fixes');
    var straight=mi(pts[0],pts[pts.length-1]);
    stAdd('SAFETY','distance-sane',Math.abs(crumbMi-straight)<straight*0.35,
      'track '+crumbMi.toFixed(2)+' vs straight '+straight.toFixed(2)+' mi');
    stAdd('SAFETY','truck-pinned',!!TRUCK&&mi(TRUCK,pts[0])<0.02,
      TRUCK?'at '+TRUCK[1].toFixed(4)+','+TRUCK[0].toFixed(4):'none');
    var back=crumbs.slice().reverse();
    stAdd('SAFETY','retrace-lossless',
      back.length===crumbs.length&&back[0][0]===crumbs[crumbs.length-1][0],
      back.length+' points reversed');
    posMode='away';
    stAdd('SAFETY','dispatch-refuses-fake',posMode!=='gps',
      'posMode='+posMode+' (dispatch prints no coordinate)');
  }catch(e){stAdd('SAFETY','harness',false,'threw: '+e.message)}
  if(RIDE&&RIDE!==save.ride){try{clearInterval(RIDE.pulse)}catch(e){}}
  RIDE=save.ride;LASTRIDE=save.lastride;
  TRUCK=save.T;crumbs=save.c;crumbMi=save.m;posMode=save.p;ME=save.me;
  hudShow(!save.hud);
  if(el('chips'))el('chips').hidden=save.chips;
  try{syncSafety()}catch(e){}
}

function stPerf(cb){
  var n=0,t0=performance.now(),d=[],last=t0,bgSeen=false;
  function _vis(){if(document.hidden)bgSeen=true}
  try{document.addEventListener('visibilitychange',_vis)}catch(e){}
  var c=CTR;
  map.jumpTo({center:c,zoom:12.6});
  function step(){
    var t=performance.now();d.push(t-last);last=t;
    map.setBearing((n*7)%360);
    if(++n<70)requestAnimationFrame(step);
    else{
      d.sort(function(a,b){return a-b});
      var avg=Math.round(1000/(d.reduce(function(a,b){return a+b},0)/d.length));
      var p99=Math.round(1000/d[Math.floor(d.length*0.99)]);
      map.setBearing(0);map.jumpTo({center:c,zoom:11.4});
      var drew=renderedCount();
      /* Headless Chrome rasterises in software at single-digit fps, which says
         nothing about a phone. Judge the frame rate only on real hardware;
         everywhere else record it and judge that something DREW. */
      /* A single hitch and a sustained stutter give the same p99 but need very
         different answers. Count the slow frames and name the worst one, so the
         next report distinguishes "one GC pause" from "this device struggles". */
      var slow=0,worst=0;
      for(var q=0;q<d.length;q++){if(d[q]>33.4)slow++;if(d[q]>worst)worst=d[q]}
      var detail='avg '+avg+' · p99 min '+p99+' · '+slow+'/'+d.length+
        ' frames over 33ms · worst '+Math.round(worst)+'ms · '+drew+' features';
      var soft=/swiftshader|llvmpipe|software/i.test(glInfo().r||'');
      /* requestAnimationFrame STOPS when the app leaves the foreground, so the
         first frame after you come back is the length of your absence. Jacob's
         take-82 report read "avg 2 fps · worst 39402ms" — a 39-SECOND frame —
         which is a screenshot being taken, not a device struggling. Scoring
         that as a performance failure is landmine 56's corollary: correct
         behaviour must not be scored as failure. Report it, do not judge it. */
      if(bgSeen||worst>2000)
        stInfo('PERF','fps',detail+' · APP LEFT THE FOREGROUND during the '+
          'sample (rAF pauses; the worst frame is your absence), not a verdict');
      else if(soft)stInfo('PERF','fps',detail+' · SOFTWARE RASTERISER, not a verdict');
      else stAdd('PERF','fps',avg>=30&&drew>0&&slow<=d.length*0.1,detail);
      try{document.removeEventListener('visibilitychange',_vis)}catch(e){}
      cb()}}
  requestAnimationFrame(step);
}

function stGps(cb){
  var t0=Date.now(),got=false,fixes=[];
  var C=window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.Geolocation;
  stInfo('GPS','plugin',C?'Capacitor Geolocation':(navigator.geolocation?'web':'NONE'));
  if(!C&&!navigator.geolocation){
    stAdd('GPS','fix',false,'no geolocation api at all');return cb()}
  var stop=function(){
    if(fixes.length){
      var f=fixes[0];
      stAdd('GPS','first-fix',true,((f.t-t0)/1000).toFixed(1)+'s · ±'+
        Math.round(f.acc)+'m · '+f.at[1].toFixed(5)+','+f.at[0].toFixed(5));
      /* Marking "away" as FAIL was wrong — the detail line even said so. What
         matters is that the app REACTED correctly, not where the rider stands. */
      var away=!inRegion(f.at);
      stInfo('GPS','position',away?Math.round(mi(f.at,CTR))+' mi outside '+
        (BUNDLE.name||'the region'):'inside '+(BUNDLE.name||''));
      classifyFix(f.at);
      stInfo('GPS','fixes',fixes.length+' in 20s');
    }else{
      /* A watch that times out indoors is not the same as "the app has no
         position" — at take 38 the log showed a startup fix at 2.7 s while this
         section reported nothing at all, dropping startup-locate and
         mode-correct precisely when they mattered most. Report state either way. */
      stAdd('GPS','first-fix',!!YOU,YOU?
        'this watch saw nothing in 20s, but the app already has a fix from startup':
        'no fix in 20s and no startup fix (indoors? permission denied?)');
    }
    stAdd('GPS','startup-locate',!!YOU,
      YOU?'app knew its position before the self-test ran ('+
          YOU[1].toFixed(5)+','+YOU[0].toFixed(5)+')':
          'app had NO position at startup — locateOnce failed');
    if(YOU){
      var away2=!inRegion(YOU);
      stInfo('GPS','position',away2?Math.round(mi(YOU,CTR))+' mi outside '+
        (BUNDLE.name||'the region'):'inside '+(BUNDLE.name||''));
      stAdd('GPS','mode-correct',away2?(posMode==='away'):(posMode==='gps'),
        'posMode='+posMode+(away2?' (planning mode expected)':' (in region)'));
    }
    cb()};
  var onF=function(at,acc){fixes.push({t:Date.now(),at:at,acc:acc||0});got=true};
  var id=null;
  try{
    if(C){var w=C.watchPosition({enableHighAccuracy:true,timeout:15000},function(pos,err){
        if(pos&&pos.coords)onF([pos.coords.longitude,pos.coords.latitude],pos.coords.accuracy)});
      if(w&&typeof w.then==='function')w.then(function(x){id=x})
        .catch(function(e){stAdd('GPS','watch',false,String(e.message||e))});
      else id=w;
      stAdd('GPS','watch',true,'watch id '+(id===null?'pending':String(id).slice(0,12)))}
    else id=navigator.geolocation.watchPosition(function(pos){
        onF([pos.coords.longitude,pos.coords.latitude],pos.coords.accuracy)},
      function(e){stAdd('GPS','watch',false,'code '+e.code+' '+e.message)},
      {enableHighAccuracy:true,timeout:15000});
  }catch(e){stAdd('GPS','watch',false,'threw: '+e.message)}
  setTimeout(function(){
    try{if(C&&id!==null)C.clearWatch({id:id});
        else if(id!==null)navigator.geolocation.clearWatch(id)}catch(e){}
    stop()},20000);
}

function stRide(){
  if(!LASTRIDE&&!RIDE)return stInfo('RIDE','none',
    'no ride recorded yet — tap ▶ Ride it and go for one; that is what closes A18');
  var R=LASTRIDE||RIDE;
  stInfo('RIDE','duration',((R.hrs||((Date.now()-R.t0)/3600000))*60).toFixed(0)+' min · '+
    R.fixes+' fixes'+(R.drops?' · '+R.drops+' dropouts':''));
  if(R.medAcc!==null&&R.medAcc!==undefined)
    stInfo('RIDE','accuracy','median ±'+Math.round(R.medAcc)+' m under canopy');
  if(R.drain!==null&&R.drain!==undefined){
    if(R.chg)stInfo('RIDE','battery','was charging — drain is meaningless');
    else if(!R.longEnough)stInfo('RIDE','battery',
      (R.drain*100).toFixed(1)+'% used — ride too short to quote a rate');
    else stAdd('RIDE','battery',R.perHr<0.35,
      (R.drain*100).toFixed(1)+'% used · '+(R.perHr*100).toFixed(1)+'%/hour · '+
      (1/R.perHr).toFixed(1)+'h from full')}
  else stInfo('RIDE','battery','not reported by this device');
}

function stHaptics(){
  var C=window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.Haptics;
  stAdd('HAPTICS','available',!!(C||navigator.vibrate),
    C?'Capacitor Haptics':(navigator.vibrate?'navigator.vibrate':'NONE — off-route alert is silent'));
  try{buzz(30);stAdd('HAPTICS','fired',true,'buzz(30) did not throw')}
  catch(e){stAdd('HAPTICS','fired',false,'threw: '+e.message)}
}

function stReport(){
  var pass=0,fail=0,info=0;
  ST.forEach(function(r){if(r.ok===null)info++;else if(r.ok)pass++;else fail++});
  var L=[];
  L.push('APEX SELF-TEST · '+(el('title').textContent||'').replace(/\s+/g,' ').trim());
  L.push(new Date().toISOString()+' · PASS '+pass+' · FAIL '+fail+' · info '+info);
  L.push('');
  var g=null;
  ST.forEach(function(r){
    if(r.g!==g){g=r.g;L.push('['+g+']')}
    var mark=r.ok===null?'  · ':(r.ok?'  ok ':'  XX ');
    L.push(mark+pad(r.id)+' '+r.d)});
  L.push('');
  if(ACT.length){
    L.push('[LAST ACTIONS]');
    ACT.slice(-25).forEach(function(a){L.push('  '+a)});
    L.push('');}
  L.push('--- end ---');
  /* structured too: a caller needs to tell a data failure from a render one,
     and only a real engine can judge the render group. */
  return {text:L.join('\n'),pass:pass,fail:fail,results:ST.slice()};
}
function pad(s){s=String(s);while(s.length<18)s+=' ';return s}

function stRenderPanel(rep){
  var rows=ST.map(function(r){
    var col=r.ok===null?'#9A9184':(r.ok?'#8FAE63':'#C1121F');
    var mk=r.ok===null?'·':(r.ok?'✓':'✕');
    return '<div style="display:flex;gap:8px;padding:3px 0;border-bottom:1px solid #241F1A">'+
      '<span style="color:'+col+';font-weight:700;width:12px">'+mk+'</span>'+
      '<span style="color:#F5EFE2;min-width:112px;font:600 var(--t-sm) ui-monospace,monospace">'+
      r.g+'·'+r.id+'</span>'+
      '<span style="color:#C9C0B2;font-size:var(--t-sm);flex:1">'+
      String(r.d).replace(/[<>]/g,'')+'</span></div>'}).join('');
  var bad=rep.fail>0;
  show('<b style="font-size:var(--t-lg)">Self-test · '+
    '<span style="color:'+(bad?'#C1121F':'#8FAE63')+'">'+rep.pass+' passed, '+
    rep.fail+' failed</span></b><br>'+
    '<div style="max-height:46vh;overflow:auto;margin:8px 0">'+rows+'</div>'+
    '<button id="st-copy" class="chip">Copy report</button> '+
    '<button id="st-share" class="chip">Share report</button>',bad?'fail':'');
  var t=rep.text;
  var cp=el('st-copy');
  if(cp)cp.addEventListener('click',function(){
    var done=function(){cp.textContent='Copied ✓';setTimeout(function(){cp.textContent='Copy report'},1600)};
    if(navigator.clipboard&&navigator.clipboard.writeText)
      navigator.clipboard.writeText(t).then(done,legacy); else legacy();
    function legacy(){var ta=document.createElement('textarea');ta.value=t;
      document.body.appendChild(ta);ta.select();
      try{document.execCommand('copy');done()}catch(e){}
      document.body.removeChild(ta)}});
  var sh=el('st-share');
  if(sh)sh.addEventListener('click',function(){
    var S=window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.Share;
    if(S)S.share({title:'APEX self-test',text:t}).catch(function(){});
    else if(navigator.share)navigator.share({title:'APEX self-test',text:t}).catch(function(){});
    else sh.textContent='No share sheet — use Copy'});
}

/* Labels are placed asynchronously: jumping and querying in the same tick
   returns zero on a map that will show eight a moment later. The synchronous
   sections cannot see placement at all, so this waits (take 44 — my check was
   wrong, not the map). */
function stLabels(cb){
  var was={c:map.getCenter(),z:map.getZoom()};
  var site=anchorOf('site');
  map.jumpTo({center:site,zoom:14.5});
  setTimeout(function(){
    var q=function(ids){try{return map.queryRenderedFeatures({layers:ids}).length}
      catch(e){return -1}};
    var segs=q(['trail50','route72','moto24','fstrail','mccct']);
    var tl=q(['lbl-trail']);
    stAdd('RENDER','trail-names',segs===0||tl>0,
      tl+' names for '+segs+' trail segments at z14.5 — knowing WHICH trail '+
      'you are on is the point');
    map.jumpTo({center:[was.c.lng,was.c.lat],zoom:was.z});
    cb()},1800)}

/* opts.gps=false skips the 20s live-fix phase (used by the headless harness) */
function selfTest(opts,done){
  opts=opts||{};ST=[];
  stEnv();stLoad();stRender();stLayout();stData();stRouting();stSafety();stRide();stHaptics();
  var finish=function(){var rep=stReport();
    try{window.__selfTestReport=rep}catch(e){}
    if(done)done(rep);return rep};
  stLabels(function(){
  stPerf(function(){
    if(opts.gps===false)return finish();
    show('<b>Self-test running…</b><br>Waiting up to 20s for a GPS fix. '+
      'Step outside for a real one, or wait it out.','');
    stGps(function(){finish()})})});
}
try{window.__selfTest=selfTest}catch(e){}
el('c-loop').addEventListener('click',function(){
  show('<b>Loop from here</b> — a ride that ends where it starts, on legal line '+
    'for a '+MACHINE[machine].lbl.replace(/^\S+\s/,'')+'.<br>'+
    '<div style="margin-top:8px">'+LOOP_CHOICES.map(function(m){
      return '<button class="chip" data-loop="'+m+'">'+m+' mi</button>'}).join(' ')+
    '</div>','');
  Array.prototype.forEach.call(document.querySelectorAll('[data-loop]'),function(b){
    b.addEventListener('click',function(){
      var want=+b.dataset.loop;LOOP_MI=want;
      logAct('act  loop '+want+' mi');
      show('Building a '+want+' mi loop…','');
      setTimeout(function(){
        var a=nearestNode(ME);
        if(a<0)return show('<b>Nothing legal nearby</b> for a '+
          MACHINE[machine].lbl.replace(/^\S+\s/,'')+'. Move the ◎ pin closer to a trail.','fail');
        RFROM=ME.slice();RTO=ME.slice();
        var out=buildLoops(a,want);
        if(!out.length)return show('<b>No loop found</b> at '+want+
          ' mi from here. The legal network within reach may not connect back — '+
          'try a different distance, or a narrower machine.','fail');
        out.forEach(function(o){
          o.h+=' · '+o.s.mi.toFixed(1)+' mi';
          if(o.repeat>0.25)o.h+=' ⟲'});
        logAct('loop '+out.length+' options, '+out[0].s.mi.toFixed(1)+' mi');
        presentRoutes(out)},30)})})});

el('c-selftest').addEventListener('click',function(){
  setChip('c-selftest','shield','Running…');
  show('<b>Self-test running…</b><br>Exercising load, render, data, routing, '+
    'safety, haptics and performance, then waiting up to 20s for a GPS fix.','');
  setTimeout(function(){selfTest({},function(rep){
    setChip('c-selftest','shield','Self-test');
    stRenderPanel(rep)})},60)});

[[hM,'home',function(){return HOME},function(){return 'Home / truck'}],
 [mM,'me',function(){return ME},function(){
    return posMode==='gps'?'You are here':posMode==='sim'?'Simulated position':
           posMode==='away'?'Planning start':'Start pin'}]
].forEach(function(t){
  try{t[0].getElement().addEventListener('click',function(ev){
    ev.stopPropagation();placeCard(t[2](),t[1],t[3]())})}catch(e){}});
/* ══ LONG PRESS ═════════════════════════════════════════════════════════════
   Own implementation rather than relying on the browser's contextmenu, which is
   inconsistent in a WebView and cannot be tuned. 450 ms with a 12 px tolerance:
   long enough not to fire while panning, short enough to feel deliberate with
   gloves on. A buzz confirms it, because a gesture with no feedback feels
   broken. */
var LP_MS=450,LP_TOL=12,lp={t:null,x:0,y:0,fired:false};
function lpCancel(){if(lp.t){clearTimeout(lp.t);lp.t=null}}
function lpAt(cx,cy){
  /* getContainer(), not getCanvasContainer(): the latter is a zero-height
     wrapper around absolutely-positioned children, and unproject() is defined
     against the map CONTAINER's top-left anyway. Same origin today, but relying
     on a rect whose height is 0 is asking for it. */
  var box=map.getContainer().getBoundingClientRect();
  var ll=map.unproject([cx-box.left,cy-box.top]);
  buzz(18);dropPin([ll.lng,ll.lat])}
(function(){
  var cv=map.getCanvasContainer();
  cv.addEventListener('touchstart',function(e){
    lpCancel();
    if(!e.touches||e.touches.length!==1)return;
    var t=e.touches[0];lp.x=t.clientX;lp.y=t.clientY;lp.fired=false;
    lp.t=setTimeout(function(){lp.t=null;lp.fired=true;lpAt(lp.x,lp.y)},LP_MS)},{passive:true});
  cv.addEventListener('touchmove',function(e){
    var t=e.touches&&e.touches[0];if(!t)return;
    if(Math.abs(t.clientX-lp.x)>LP_TOL||Math.abs(t.clientY-lp.y)>LP_TOL)lpCancel()},{passive:true});
  cv.addEventListener('touchend',lpCancel,{passive:true});
  cv.addEventListener('touchcancel',lpCancel,{passive:true});
})();
/* desktop / stylus right-click, and the path the harness drives */
map.on('contextmenu',function(e){buzz(18);dropPin([e.lngLat.lng,e.lngLat.lat])});
/* MapLibre's compact attribution renders EXPANDED on first paint, and on a
   411 px screen that bar sits across the chip strip and hides a button. Collapse
   it; the (i) still opens it, and the credits are also in About (take 61). */
function collapseAttrib(){
  try{Array.prototype.forEach.call(
    document.querySelectorAll('.maplibregl-ctrl-attrib.maplibregl-compact-show'),
    function(el){el.classList.remove('maplibregl-compact-show')})}catch(e){}}
map.on('load',collapseAttrib);map.on('idle',collapseAttrib);

map.on('idle',function(){if(!healthOK)renderHealth()});
map.on('move',refreshReadout);map.on('load',refreshReadout);
map.on('moveend',railFoldIfAway);
map.on('load',function(){makeBadges();setBasemap(0);wpDraw();showTab('map');
  /* Relief starts OFF. The style ships hillshade visible, and over the flat
     vector basemap it reads as dark blotches — Jacob: "it looks really bad".
     On Hybrid it earns its place at low opacity, so it stays one tap away under
     Layers rather than being removed (take 112, field report). */
  try{map.setLayoutProperty('hillshade','visibility','none')}catch(e){}
  /* First open only. Waits for the map so the blur has something behind it. */
  if(!guideSeen())setTimeout(guideShow,450);
  /* The map is the product; the rail is a drawer. Opens the moment you touch
     something (A127). */
  railSet(false);buildActPanel();actLabel();
  setTimeout(renderHealth,1800);
  var C=window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.Geolocation;
  if(C){try{C.requestPermissions().then(locateOnce).catch(locateOnce)}catch(e){locateOnce()}}
  else locateOnce()});

/* One fix at startup. The app used to learn where you were only when you tapped
   ▶ Ride it, so it happily showed a region you were 135 miles from and said
   nothing (take 27 field report). Knowing early costs one fix and changes the
   whole first screen. */
var YOU=null,youM=null;
function locateOnce(){
  /* Take 30 used getCurrentPosition with enableHighAccuracy:false and a 10s
     timeout. On the Fold it never produced a fix — the self-test reported
     posMode=none while its OWN watch got one in 1.0s at +/-17m. So: use the same
     watch machinery that demonstrably works, take the first fix, stop. One
     proven path beats two plausible ones (landmine 56 again). */
  var handle=function(at,acc){
    YOU=at.slice();
    if(!youM){var d=mk('you');youM=new maplibregl.Marker({element:d}).setLngLat(YOU).addTo(map)}
    else youM.setLngLat(YOU);
    classifyFix(at);
    if(posMode==='away')showAway(acc); else{posMode='gps';ME=at.slice();mM.setLngLat(ME);paint();syncSafety()}
    drawCoverage()};
  var done=false,saveWatch=watchId;
  var mode=gpsStart(function(at){
    if(done)return; done=true;
    handle(at,null);
    gpsStop(); watchId=saveWatch;          /* leave a ride's own watch alone */
  },function(){ if(!done){done=true; gpsStop(); watchId=saveWatch} });
  if(!mode)return;
  /* Give up quietly after 25s rather than holding the receiver open. */
  setTimeout(function(){ if(!done){done=true; gpsStop(); watchId=saveWatch;
    stInfo&&0; } },25000);}

function showAway(acc){
  showQuiet('<b>You are about '+Math.round(awayMi)+' mi from '+(BUNDLE.name||'this region')+
    '.</b><br>This download only covers the boxed area — everywhere else is '+
    'deliberately blank, not broken. <b>Planning mode</b> is on: browse, search, '+
    'tap open ground to set a start, then <b>Return Home</b> or <b>Directions</b>.'+
    '<br><br>Tap <b>◉ Locate</b> to jump to your real position, or a chip above to '+
    'jump to the riding area.',
    Math.round(awayMi)+' mi away \u00b7 planning mode')}

/* Relief and Labels moved into the layers panel at take 90; the strip was at
   sixteen chips with layer toggles scattered among ride actions. lyrSet() still
   updates these elements if they exist, so re-adding a chip needs no new code. */
el('c-lost').addEventListener('click',function(){
  if(rideMode)return show('Live GPS is driving — the alert fires from your actual track, not a button.','');
  if(!riding)return show('Start <b>▶ Ride it</b> first, then take a wrong turn and watch the alert fire.','');
  lost=true;buzz(40);
  show('Veering off at the next junction — this is the failure the whole app exists to catch.','')});

/* ── inspect / place ───────────────────────────────────────────────────── */
var HIT=['route72','trail50','moto24','mccct','fstrail','fsroad','closed','fsclosed','track','paved','minor'];
/* Tapping a dashed line has to answer "what is that and may I ride it".
   Show-only features are not in EDGES, so the identify branch below cannot
   describe them — they get their own branch that says plainly what they are. */
var HIT_SHOW=['show-line'];
map.on('click',function(e){
  if(lp.fired){lp.fired=false;return}   /* the long press already acted */
  if(arm){var ll=[e.lngLat.lng,e.lngLat.lat];
    if(arm==='home'){HOME=ll;hM.setLngLat(ll)}else{ME=ll;mM.setLngLat(ll);syncSafety()}
    arm=null;syncArm();clearRoute();
    return show('Placed. Tap <b>Return home</b> to route.','')}
  /* A115 · a paddle pin is checked before anything else it may be sitting on.
     A dam is checked before a launch, because if both are under the finger the
     hazard is the answer. */
  /* Remember what this card is about, so panning away can take it with it. */
  RAIL_AT=[e.lngLat.lng,e.lngLat.lat];
  var box=[[e.point.x-13,e.point.y-13],[e.point.x+13,e.point.y+13]];
  var dam=map.queryRenderedFeatures(box,{layers:['pad-dam']});
  var padf2=dam.length?dam:map.queryRenderedFeatures(box,{layers:['pad-dot']});
  if(padf2.length&&padf2[0].geometry&&padf2[0].geometry.coordinates)
    return paddleCard(padf2[0]);

  /* A110 · a place is checked FIRST. A pin sits on top of the line it is beside,
     so tapping it and getting the road underneath would be the wrong answer to
     an unambiguous gesture. */
  var pf=map.queryRenderedFeatures([[e.point.x-11,e.point.y-11],[e.point.x+11,e.point.y+11]],
    {layers:['poi-dot']});
  /* A feature with no geometry crashes the whole click handler, and a click
     handler that throws takes every other tap with it — the trail identify, the
     pin drop, everything. MapLibre always supplies geometry; a harness might
     not, and neither is a reason to be one bad object away from a dead map. */
  if(pf.length&&pf[0].geometry&&pf[0].geometry.coordinates){
    /* There is no fmt() — I called one that does not exist. Coordinates are
       printed lat-then-lon at five places everywhere else in this file, and
       dispatch reads them aloud in that order (landmine 102: read the code,
       not your memory of it). */
    var pr=pf[0].properties,pp=pf[0].geometry.coordinates,
        pc='<span class="tn">'+pp[1].toFixed(5)+'  '+pp[0].toFixed(5)+'</span>';
    logAct('tap  place '+(pr.n||pr.k));
    return show('<b>'+(pr.named?pr.n:pr.h)+'</b>'+
      (pr.named?'<div class="sub">'+pr.h+'</div>':
                '<div class="sub">Unnamed in the source \u2014 shown by what it is</div>')+
      '<div class="k">WHERE</div>'+pc+
      '<div class="sub">'+placeDist(pf[0].geometry.coordinates)+'</div>','');
  }
  var f=map.queryRenderedFeatures([[e.point.x-9,e.point.y-9],[e.point.x+9,e.point.y+9]],
    {layers:HIT.concat(HIT_SHOW)});
  if(!f.length){
    /* Empty ground. With a live in-region fix, ME means "where I am" and must
       not be draggable. Otherwise this is planning: put the start here.
       Take 21 added a second click handler for this and it clobbered the
       identify branch above — one handler, one meaning per tap. */
    /* Tap does ONE job: identify. Pinning moved to long-press at take 36 so a
       pin can be dropped ON a road or trail — tapping one has to keep selecting
       it. Google Maps' convention, and the only way both gestures fit. */
    { /* Tapping empty ground is how a rider says "get out of the way". The
         rail folds instead of opening a card that says nothing — and the
         message goes on the peek strip, still readable without costing the map
         half the screen (A127). */
      railSet(false);RAIL_MANUAL=false;
      var pt=el('peek-txt');
      if(pt)pt.textContent='Nothing there \u2014 press and hold to drop a pin';
      return}}
  if(f[0].properties.i===undefined){
    /* a show-only route: exists, but not ridable on this machine */
    var pr=f[0].properties;
    return show('<span class="tn">'+(pr.n||pr.u||'Route')+'</span>'+
      '<span class="tag adv">'+(pr.u||SHOWN[pr.c]||pr.c)+'</span><br>'+
      '<b>Not an ORV route.</b> It is on the map because it exists and can help '+
      'you place yourself — routing will never use it.','')}
  var ed=EDGES[f[0].properties.i],a=attrs(ed);
  var out='<span class="tn">'+(ed.n||label(ed.c))+'</span><br>';
  out+='<span class="tag '+(a.auth==='legal'?'legal':'adv')+'">'+
    (a.src==='dnr'?'DNR · legal':a.src==='usfs'?'USFS · legal':'OSM · advisory')+'</span>';
  if(a.st&&a.st.toLowerCase().indexOf('temporarily')===0)out+='<span class="tag shut">closed</span>';
  if(MACHINE[machine].ok.indexOf(ed.c)<0)
    out+='<span class="tag shut">illegal for your machine</span>';
  out+='<br>';
  var bits=[];
  if(ed.id)bits.push('Trail <b>'+ed.id+'</b>');
  if(a.w)bits.push('Width <b>'+a.w+'</b>');
  if(a.sym)bits.push(a.sym);
  if(a.moto)bits.push('Moto <b>'+a.moto+'</b>');
  if(a.atv)bits.push('ATV <b>'+a.atv+'</b>');
  if(a.lic)bits.push(a.lic);
  bits.push((ed.L/1609.34).toFixed(2)+' mi segment');
  /* A101 · a published restriction goes LAST and on its own line, because it is
     the thing that decides whether you may be here at all. If we recognise it we
     say it plainly; if we do not, the source's own words are printed unedited —
     telling a rider what the sign says is honest, inventing a reading is not. */
  var _rs=restrictOf(ed);
  if(_rs){
    var banned=_rs.ban&&_rs.ban.indexOf(machine)>=0;
    bits.push('<br><b'+(banned?' style="color:#C1121F"':'')+'>'+
      (banned?'NOT for your machine — ':'Restriction: ')+'</b>'+_rs.say+
      (_rs.unknown?' <span class="sub">(as published; not interpreted)</span>':''));}
  if(UP[ed.i]||DN[ed.i])bits.push('+'+ft(UP[ed.i])+' / -'+ft(DN[ed.i])+' ft');
  show(out+bits.join(' · '),'')});

/* ══ THE RAIL, FOLDED (A127) ════════════════════════════════════════════════
   The rule: THE CARD BELONGS TO A PLACE. It opens when you touch something and
   it leaves when that thing does.

     opens   tapping a pin, road or trail · a route being planned · any chip
             that produces a card — all of which go through show(), so there is
             ONE place that opens it rather than a call at every site
     folds   tapping empty map · panning until the subject is off screen ·
             the handle
     peeks   always. The strip carries distance to the truck while riding and
             the handle to bring the rest back, so nothing is unreachable —
             only folded (landmine 173: reachable is not the same as wired).

   A ride keeps it peeked rather than open: mid-trail you want the map, and the
   one number that matters is already on the strip. */
var RAIL_AT=null;          /* what the open card is about, in lon/lat */
var RAIL_MANUAL=false;     /* did the rider fold it by hand? then leave it alone */

function railPeekText(){
  if(TRUCK&&ME){
    var d=mi(ME,TRUCK);
    return 'Truck '+(d<10?d.toFixed(1):Math.round(d))+' mi '+compass(bearing(ME,TRUCK))}
  if(RAIL_AT)return 'Details';
  return ''}

function railSet(open,at){
  var r=el('rail');
  if(!r)return;
  if(open){
    RAIL_AT=at||RAIL_AT||null;
    r.className='';
  }else{
    RAIL_AT=null;
    r.className='folded';
  }
  var t=el('peek-txt');
  if(t)t.textContent=open?railPeekText():
    (RAIL_AT?'Details':railPeekText());}

function railFoldIfAway(){
  /* Pan far enough that the thing the card is about has left the screen and the
     card goes with it. Not a timer and not a scroll threshold — the subject
     either is on screen or it is not. */
  if(RAIL_MANUAL||!RAIL_AT)return;
  try{
    var p=map.project(RAIL_AT),b=map.getContainer().getBoundingClientRect();
    if(p.x<-40||p.y<-40||p.x>b.width+40||p.y>b.height+40)railSet(false);
  }catch(e){}}

/* Three places wrote the panel directly — saved routes, route options, the step
   list — so they got no motion and did not open the drawer. Everything goes
   through one function now; a card written any other way is a card that behaves
   differently for no reason a rider could name (take 110). */
function cardHTML(h,s){show(h,s)}

/* Status messages — "you are 135 mi away", startup notes — are not CARDS about
   a place the rider touched, so they must not unfold the drawer. Jacob closed
   the first-run guide and found the drawer standing open under it: the first
   GPS fix had arrived mid-guide and showAway() opened it (take 112).
   quiet=true sets the content and a peek summary and leaves the fold alone —
   the full text is one handle-tap away. */
function showQuiet(h,peekLine){
  var p=el('panel');p.innerHTML=h;p.className='';
  var t=el('peek-txt');
  if(t&&peekLine)t.textContent=peekLine;}

function show(h,s){
  var p=el('panel');p.innerHTML=h;
  /* Restart the animation on every card. Setting the class alone does nothing
     when it is already there — the browser will not replay an animation for an
     unchanged class — so it comes off, the layout is read to force the change
     to land, and it goes back on. */
  p.className=s||'';
  void p.offsetWidth;
  p.className=(s?s+' ':'')+'swap';
  /* Every card in the app goes through here — place cards, route options,
     search hits, the self-test, dispatch. One hook, so a new card cannot forget
     to open the rail (landmine 107's shape applied to behaviour). */
  RAIL_MANUAL=false;railSet(true);}

var geo=new maplibregl.GeolocateControl({positionOptions:{enableHighAccuracy:true},
  trackUserLocation:true,showAccuracyCircle:true});
map.addControl(geo,'top-right');
/* A scale bar is the one piece of map furniture every off-road app has and this
   did not: without it a rider cannot judge whether a gap is 200 yards or two
   miles, which is exactly the judgement that decides whether to push through. */
try{map.addControl(new maplibregl.ScaleControl({maxWidth:96,unit:'imperial'}),'bottom-left')}catch(e){}
el('c-locate').addEventListener('click',function(){
  if(flyToYou())return;
  locateOnce();
  setTimeout(function(){if(!flyToYou())geo.trigger()},1200)});
geo.on('error',function(){show('Location unavailable — browsers block GPS on <b>file://</b> and in embedded frames. Expected here; works in the APK. Use <b>&#39;I am here&#39;</b> to place yourself manually.','fail')});

/* ── THE PLACE STRIP FOLDS INTO SEARCH (take 113) ─────────────────────────
   Neither reference keeps a permanent row of place pills eating the top of the
   map — the quick-jumps now live where you would look for a place: under
   Search, shown when the query is empty. The #chips element stays in the DOM
   (the ride HUD swaps with it and the self-test restores it) but it renders
   nothing and takes no space. */
el('chips').innerHTML='';
el('chips').style.display='none';
function jumpChipsHTML(){
  return '<div class="sub" style="margin:2px 0 7px">Jump to</div>'+
    PLACES.map(function(p,i){
      return '<button class="chip" data-jump="'+i+'" style="margin:0 6px 6px 0">'+
        p[0]+'</button>'}).join('')}
function wireJumpChips(root){
  Array.prototype.forEach.call(root.querySelectorAll('[data-jump]'),function(c){
    c.addEventListener('click',function(){var p=PLACES[+c.dataset.jump];
      map.easeTo({center:[p[1],p[2]],zoom:p[3]==='town'?13.2:13.8,
        duration:700,essential:true});railSet(false)})})}

function refreshReadout(){
  var c=map.getCenter(),e=elevAt([c.lng,c.lat]);
  var r=el('ro-elev');
  /* Was a bare "1194 ft" sitting under a scale bar reading "3000 ft" — two
     numbers in the same unit with nothing to tell them apart. Say which is
     which (take 65). */
  if(r)r.textContent=(e===null?'':ft(e)+' ft elevation');
  var v=el('v-elev');
  if(v)v.textContent=(e===null?'—':ft(e)+' ft')}

function paint(){var c=map.getCenter();
  var e=elevAt([c.lng,c.lat]);
  var tag=posMode==='gps'?'DD':posMode==='sim'?'DD · SIMULATED TRACK':
    posMode==='away'?
      'DD · MAP CENTRE · you are '+Math.round(awayMi)+' mi away':
      'DD · MAP CENTRE · no GPS fix yet';
  el('coords').innerHTML=c.lat.toFixed(5)+' '+c.lng.toFixed(5)+
    ' <span class="unit">'+tag+(e!==null?' · '+ft(e)+' ft':'')+'</span>';
  }
map.on('move',paint);map.on('load',paint);paint();syncSafety();

var lastT=performance.now(),win=[],cap=null;
(function tick(n){var d=n-lastT;lastT=n;
  if(d>0&&d<1000){win.push(d);if(win.length>60)win.shift();if(cap)cap.push(d)}
  if(win.length>10){var a=win.reduce(function(x,y){return x+y},0)/win.length,
    f=Math.round(1000/a),e=el('v-fps');e.textContent=f;
    e.className=f>=50?'v good':f>=30?'v':'v warn'}
  requestAnimationFrame(tick)})(performance.now());

/* A fixed loop over this region's anchors, so two builds stay comparable and any
   region can be perf-tested the same way. */
var LEGS=(function(){
  var z=[15.5,13,15,16],b=[0,40,0,0],out=[];
  for(var i=0;i<Math.min(4,PLACES.length);i++)
    out.push({center:[PLACES[i][1],PLACES[i][2]],zoom:z[i],bearing:b[i],duration:1600});
  out.push({center:BUNDLE.centre||[PLACES[0][1],PLACES[0][2]],zoom:11.4,
    bearing:0,duration:1500});
  return out})();
el('c-pan').addEventListener('click',function(){
  el('c-pan').disabled=true;cap=[];show('Running…','');var i=0;
  (function step(){if(i>=LEGS.length)return done();map.once('moveend',step);
    var L=LEGS[i++];map.easeTo({center:L.center,zoom:L.zoom,bearing:L.bearing,
      duration:L.duration,essential:true})})()});
function done(){var d=cap.slice().sort(function(a,b){return a-b});cap=null;
  el('c-pan').disabled=false;
  if(d.length<30)return show('Not enough frames. Run it again.','fail');
  var avg=Math.round(1000/(d.reduce(function(a,b){return a+b},0)/d.length)),
      mn=Math.round(1000/d[Math.floor(d.length*0.99)]),
      /* A frame rate measured over an empty canvas is meaningless. Take 20
         reported "PASS 121 fps · 16352 edges rendered" while the map was blank
         sand — the test asserted its own hope. It counts pixels now. */
      drew=renderedCount(),
      pass=avg>=50&&mn>=30&&remoteHits===0&&drew>0;
  show('<b>'+(pass?'PASS':'FAIL')+'</b> · avg <b>'+avg+'</b> fps · p99 min <b>'+mn+
   '</b> fps · remote <b>'+remoteHits+'</b><br>'+drew+' of '+EDGES.length+
   ' edges actually rendered. '+(drew===0?
     'ZERO drew — the high frame rate is an idle renderer, not speed. Tap ⓘ.':
     pass?'Holds up with the full routable network loaded.'
   :'Below threshold — note both numbers before comparing to the APK.'),
   pass?'pass':'fail')}
/* Say plainly which layers this region does not have. Silently dropping one is
   how you end up trusting a map that is lying by omission. */
if(BUNDLE.state==='partial'){
  var names={imagery:'satellite imagery',relief:'hillshade',hydro:'water'};
  el('b-src').textContent='PARTIAL';
  el('b-src').className='badge bad';
  show('<span class="tn">Region is partial</span><span class="tag shut">'+
    BUNDLE.absent.length+' layer missing</span><br>Navigation works. Not downloaded: <b>'+
    BUNDLE.absent.map(function(k){return names[k]||k}).join(', ')+
    '</b>. Re-download on wifi to complete it.','fail');
}
}
})();
