**Take 118 — Michigan WITH its Great Lakes, and the fix for why 117 never
reached your phone.**

### DO THIS FIRST — one manual edit in your GitHub repo

Your take-117 build shipped the old test square because
`.github/workflows/build.yml` (which the seed cannot update) still contained
`APEX_REGION: neml-bullgap` — an override that outranks everything the seed
declares. **Copy `ci/build.yml` from this seed over
`.github/workflows/build.yml`, commit, then upload the seed as usual.** The
file's header explains every change. Expect the first Michigan build to run
40–60 minutes (later builds ~10–15 with warm caches) and the workflow summary
to print: `verified: region michigan, bundle ~127 MB`.

If it instead fails with a "stale cache / stamped for another region"
message — that is the new guard working; it names its remedy (bump DATA_V in
the workflow and re-run).

### Then confirm on the phone

About says **118**, and the map shows the whole state — pan out: both
peninsulas, Lake Superior, Lake Michigan, Lake Huron, Drummond Island. If you
can see the Mitten, you are holding the real thing.

### New since 117

- **The Great Lakes and every island-holding lake** — 738 relation-assembled
  water bodies the old reader could never see.
- Full audit of the statewide arc: 17/17 mechanisms verified, plus three
  layers of protection so CI can never silently build the wrong region again.

### Field script

Airplane mode. Pan the state. Set a home, Return Home from real trail country.
Dispatch timing at 473k edges. A river far from Bull Gap. Then your tuning
verdicts drive the next arc: Silver Lake riding-area polygon, statewide
summits, address size, dispatch speed — and your onX Backcountry + Hunt/Fish
screenshots open the modes era.
